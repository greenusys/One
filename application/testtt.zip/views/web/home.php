<script>
$(document).ready(function() {
  $('.home').addClass('active');

});
</script>
<style type="text/css">
  .fa-address-card
  {
    border: 1px solid black;
    border-radius: 50%;
    padding: 10px;
  }
</style>
<link href="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/js/select2.min.js"></script>
 <!-- <script type="text/javascript" src="https://html2canvas.hertzen.com/dist/html2canvas.js"></script> -->
    <script type="text/javascript" src="https://html2canvas.hertzen.com/dist/html2canvas.min.js"></script>
    <script src="https://files.codepedia.info/files/uploads/iScripts/html2canvas.js"></script>
  <style type="text/css">
    .MultiCarousel 
    { 
      overflow: hidden;
       width: 100%; 
    }
    .MultiCarousel .MultiCarousel-inner 
    { 
      transition: 1s ease all;
    }
    .MultiCarousel .MultiCarousel-inner .item 
    { 
      float: left;
    }
    .MultiCarousel .MultiCarousel-inner .item > div 
    { 
      text-align: center; 
    }
    .MultiCarousel .leftLst, .MultiCarousel .rightLst {
      position:absolute;
      border-radius:50%;
      top:calc(50% - 20px); 
   }
    .MultiCarousel .leftLst 
    {
      left:0; 
    }
    .MultiCarousel .rightLst 
    {
     right:0; 
    }
    .MultiCarousel .leftLst.over, .MultiCarousel .rightLst.over 
    { 
      pointer-events: none;
       background:#ccc; 
    }
    .fy
    {
      font-size: 14px;
    }
    .border-2 
    {
      border-width:2px !important;
    }
    textarea 
    {
      resize: none;
    }
  
    .manage:hover
    {
      background-color: rgba(0, 0, 0, .05) !important;
    }
    .history
    {
      height: 15% !important;
    }
    .toggle,.toggle-handle
    {
      margin-left: auto;
    }
    .fa-circle
    {
      color:#28a745;
    }
    .bgdefault
    {
      background-color: #e2e2e2;
    }

    .emojionearea-button {
      right: 13px !important;
      top: 100% !important;
    }
    .emojionearea-picker
    {
      top: 100% !important;
    }
    .posttab:hover
    {
      background: #e2e2e2;
    }
    .w-st
    {
      padding: 0px 3px;
      width: 30px;
    } 
    .bgimgs.expanded
     {
        display:none !important;
    }
     .withs.expanded
     {
        display:flex !important;
    }
    .icontheme {
      border: 1px solid #e2e2e2;
      background-color: #e2e2e2;
      padding: 4px;
      height: 25px;
    }
    .select2
    {
      width: 100% !important;
    }
    .select2-selection
    {
      border: 1px solid #e2e2e2 !important;
    }
    .ranUse{
      font-size: 12px;
    }

.like_img{
width: 32px;
    height: 32px;
}
.like_img_marg25{
  margin-left: -25px;
}
.like_cont{
       color: white;
    width: 31px;
    height: 31px;
    padding: 4px;
    background: #ff5e3a;
   
  }

.menu_botttom{
      border-bottom: 1px solid rgba(0,0,0,.1);
     padding: 9px 7px;
}
.mt-80{
  margin-top: 80px;
}
.usr_pro{
      position: absolute;
    width: 90%;
    margin-top: -54px;
}
.usr_back{
  height: 100px;
}
.back_col{
  background-image:url('<?=base_url()?>assets/img/Cover_Photo/<?=$MyDetails[0]->cover_photo?>');
  /* background: #ff441a !important;  */
}

.btn-like a{
  font-size: 13px;
  margin-top: 7px;
}
.btn-like a:hover{
  text-decoration: none;
}



.post-btns{
   margin-top: 4px;
  color: #807e7e !important;      
}
.post-btns a{
  font-size: 13px;
  text-decoration: none;
  color: #807e7e !important; 
}
.comnt_inp{
      width: 100%;
    border-radius: 10px;
    border: 1px solid #807e7e;
    height: 32px;
    padding: 12px;
}
.cmnt_icons{
      position: absolute;
    right: 17px;
    margin-top: 1px;
    font-size: 20px;
    color:#807e7e !important;
}
._input{
  outline:none;
}
#input12 {
    -moz-appearance: textfield;
    -webkit-appearance: textfield;
    background-color: white;
    background-color: -moz-field;
  
    box-shadow: 1px 1px 1px 0 lightgray inset;  
   outline:none;
     width: 100%;
    border-radius: 10px;
    border: 1px solid #807e7e;
    height:auto;
   padding: 4px 56px 4px 8px;
   color:#807e7e !important;
}
#w_t_follow{
  top:630px;
    bottom: auto;
    width: 16%;
    position: fixed;
}

[contentEditable]:empty:not(:focus):before{
        content:attr(data-text)
    }
  </style>


<div class="container mt-5">
  <div class="row">
    <!-- left sidepanel -->
    <div class="col-md-3 text-center border-right pt-4 bgdefault">
      <div class="head bg-white ">
        <div class="usr_back back_col"></div>
        <div class="usr_pro"><img class="img img-fluid w-50" src="<?=base_url()?>assets/img/Profile_Pic/<?=$MyDetails[0]->profile_picture?>" onerror="this.src='<?=base_url()?>assets/img/Profile_Pic/default.png';" style="border-radius: 50%;height: 124px;width: 124px !important;"></div>
        <h5 class="mt-80"> <?=$MyDetails[0]->full_name?></h5>
        <hr>
        <ul class="ml-4 mt-4 list-unstyled text-left colblack">
          <li class="row">
             <i class="fa fa-users ranUse  mt-3 col-md-1" aria-hidden="true"></i><a class=" menu_botttom col-md-9" href="<?=base_url('Friends/getFrnd/')?>">Friends</a>
          </li>
          <li class="row">
            <i class="fa fa-user-plus ranUse mt-3 col-md-1" aria-hidden="true"></i><a class=" menu_botttom col-md-9" href="#">Find Friend</a>
          </li>
          <li class="row">
            <i class="fa fa-star ranUse mt-3 col-md-1" aria-hidden="true"></i><a class=" menu_botttom col-md-9" href="#">Favourites</a>
          </li>
          <li class="row">
             <i class="fa fa-bookmark ranUse mt-3 col-md-1" aria-hidden="true"></i><a class=" menu_botttom col-md-9" href="#">Bookmark</a>
          </li>
          <li class="row">
             <i class="fa fa-users ranUse mt-3 col-md-1" aria-hidden="true"></i><a class=" menu_botttom col-md-9" href="#">Group</a>
          </li>
          <li class="row">
             <i class="fa fa-file-text ranUse mt-3 col-md-1" aria-hidden="true"></i><a class=" menu_botttom col-md-9" href="#">Page</a>
          </li>
        <!--     <li class="row">
             <i class="fa fa-calendar ranUse mt-3 col-md-1" aria-hidden="true"></i><a class=" menu_botttom col-md-9" href="#">Events</a>
          </li>
          <li class="row">
             <i class="fa fa-sun ranUse mt-3 col-md-1" aria-hidden="true"></i><a class=" menu_botttom col-md-9" href="#">Weather</a>
          </li> -->
        </ul>
      </div>
      <div class="card" id="w_t_follow">
        <div class="card-header text-center">
          <h4>Who to follow?</h4>
        </div>
        <div class="card-body">
          <ul class="list-unstyled d-flex">
             <?php
              // print_r($RandomPeople);
             
              foreach ($RandomPeople as $user) {
                $nameArrI=explode(" ",$user->full_name);
                ?>
                  <li class="text-center">
                    <a href="<?=base_url('Profile/').$user->user_id?>">
                    <img class="rounded-circle " src="<?=base_url()?>assets/img/Profile_Pic/<?=$user->profile_picture?>" onerror="this.src='<?=base_url()?>assets/img/Profile_Pic/default.png';" width="60px" height="60px">
                    <span class="ranUse"><?=$nameArrI[0]?></span></a>
                  </li>
                <?php
              }
            ?>
          </ul>
        </div>
      </div>
    </div>
    <!-- End left sidepanel -->
    <!-- center panel -->
    <div class="col-md-6">
       <div class="card rounded mt-4">
        <div class="card-body">
          <div class="MultiCarousel float-left px-2" data-items="1,3,5,6" data-slide="1" id="MultiCarousel"  data-interval="1000">
            <div class="MultiCarousel-inner float-left">
              <a href="javascript:void(0)" id="addStatus">
                <div class="item">
                    <div class="pad15">
                      <img class="rounded-circle w-75" src="<?=base_url('assets/webimg/face.png')?>">
                      <h6>Your Status</h6>       
                    </div>
                </div>
              </a>
                
                <?php
                  foreach ($FriendsStatus as $status) {
                    # code...
                    $nameArr=explode(" ",$status->full_name);
                    // print_r($nameArr);
                    ?><a href="javascript:void(0)" d-By="<?=$status->full_name?>" d-Gen="<?=$status->user_id?>" class="usr_status">
                      <div class="item">
                          <div class="pad15">
                            <img class="rounded-circle w-75" src="<?=base_url('assets/uploads/status/').$status->status_image_path?>">
                            <h6><?=$nameArr[0]?></h6>       
                          </div>
                      </div>
                    </a>
                    <?php
                  }
                ?>
            </div>
            <button class="btn btn-sm btn-primary leftLst"><i class="fa fa-chevron-left" aria-hidden="true"></i></button>
            <button class="btn btn-sm btn-primary rightLst  position-absolute"><i class="fa fa-chevron-right" aria-hidden="true"></i></button>
          </div>
        </div>
      </div>
      <div class="border border-2 bg-white rounded mt-4">
        <form class="chkpost" id="add_post"> 
    <!-- <textarea class="form-control border-0" name="about" placeholder="Share and Update..."></textarea> -->
         <div class="">
          <textarea id="emojionearea1" name="post"></textarea>        
        <!-- <label><span id="chars" class="lead">140</span></label> characters left -->
          <div class="d-flex">
          <i class="pl-2 fa fa-angle-left icontheme"></i>
          <ul class="d-flex list-unstyled px-3 bgimgs">
            <?php
              for($i=1; $i<=8; $i++){
                ?>
                   <li class="w-st">
                    <a href="javascript:void(0)" class="theme_">
                      <img class="w-100 border" src="<?=base_url('assets/webimg/theme/').$i.'.jpg'?>">
                    </a>
                    
                  </li>
                <?php
              }
            ?>
        
          </ul>
          </div>
         </div>
            <div class="row mx-0 my-2 withs" style="display: none">
              <div class="col-md-2 pr-0 text-center bgdefault">  
                <label for="tags">With</label>
              </div>
              <div class="col-md-10 px-0">
               <!--  <input class="form-control" type="text" name="tag" id="tags"> -->
                <select class="js-example-basic-multiple" name="friends[]" multiple="multiple">
                  <option value="Deepak">Deepak Nouliya</option>
                  <option value="Rahul">Rahul</option>
                  <option value="Ravish">Ravish</option>
                  <option value="Shivam">Shivam</option>
                  <option value="Shubham">Shubham</option>
                  <option value="Kaif">Kaif</option>
                </select>
              </div>
            </div>
            <div id="divOutside" class="divOutside">
            </div>
          <hr>
          <div class="row mx-0 my-2 fy">
            <div class="col-md-3 posttab">
              <a class="text-dark text-decoration-none tagfriend" href="javascript:void(0)"><i class="fa fa-user-o" aria-hidden="true"></i> Tag Friends</a>
            </div>
            <div class="col-md-4 posttab">
               <input type="file" id="img_video" class="d-none" name="files[]" multiple="">
               <label for="img_video"><i class="fa fa-picture-o" aria-hidden="true"></i> Add photo/videos</label>
            </div> 
            <div class="col-md-3 posttab">
              <img class="img-fluid" src="<?=base_url('assets/webimg/emoji.png')?>"> Feelings
            </div>  
            <div class="col-md-2 text-center">
              <img class="img-fluid" src="<?=base_url('assets/webimg/dots.png')?>">
            </div>      
          </div>
          <div class="form-check pl-5 py-2">
            <label class="form-check-label">
              <input type="checkbox" class="form-check-input mt-3" name="optradio" value="post"><i class="far fa-address-card"></i>
 News Feed
            </label>
          </div>
          <div class="form-check pl-5">
            <label class="form-check-label">
              <input type="checkbox" class="form-check-input mt-3" name="optradio" value="story"><img class="rounded-circle " src="<?=base_url('assets/webimg/face.png')?>" style="width: 15%"> Your Story
            </label>
          </div>
<div id="previewImage">
    </div>
          <div class="text-right pr-2">
             <input id="btn-Preview-Image"  class="btn btn-primary my-2 back_col border-0 px-4" type="submit" value="POST"/>
         <!--       <a id="btn-Convert-Html2Image" href="#">Download</a> -->
             <!-- <div id="match-button" >capture</div> -->
           <!--  <button type="submit" class="btn btn-primary my-2 back_col border-0 px-4" >POST</button> -->
          </div>
        </form>
      </div>
	  
	  <?php
	// print_r($AllPosts);
	   foreach($AllPosts as $p_ost){
     // print_r($p_ost);
		   if($p_ost['post_type']==0){
			   
			   ?>
				<div class="card mt-4">
					<div class="card-header ">
            <div class="d-flex float-left">
             <div> 
  					  <a class="font-weight-bold" href="#">
                 <img class="rounded-circle" src="<?=base_url('assets/webimg/face.png')?>" width="60">
               </a>
             </div>
            <div>
              <a class="font-weight-bold _use_n" href="#">  
               <?=$p_ost['posted_by']?>
              </a>
              <br>
                <small>
                  Published: June, 2 2018, 1:19 PM
                </small>
            </div>
                 
           </div>
               <?php if($_SESSION['logged_in'][0]->user_id==$p_ost['user_id']){ ?>
                    <div class="float-right mt-2">
                          <div class="dropdown">
                            <button class="dropbtn"><i class="fa fa-ellipsis-v" aria-hidden="true"></i></button>
                            <div class="dropdown-content bg-white">
                              <a href="#">Edit</a>
                              <a href="javascript:void(0)" class="dlt_post_" p_d=<?=$p_ost['post_id']?> >Delete</a>
                              
                            </div>
                          </div>
                    </div> 
                <?php } ?>
					   <!-- <a class="" href="#"><img class="img-fluid float-right pt-3" src="<?=base_url('assets/webimg/dots.png')?>"></a> -->
            
					<!--   <div class="titles mt-1">
						<p class="pl-2">CAA के विरोध के नाम पर विपक्ष भड़का रहा है उपद्रवियों को?</p>
					  </div> -->
					</div>
					<div class="card-body text-justify">
						<p>
						<?=$p_ost['post']?>
						</p>
            
      
					</div>
					<!--<div class="total row px-2 text-right">
					  <div class="col-md-3 text-left"> 
						<i class="fa fa-thumbs-o-up" aria-hidden="true"></i><span>200</span>
					  </div>
					  <div class="col-md-3"> 
						<span>200</span><span> Comments</span>
					  </div>
					  <div class="col-md-3"> 
						<span>200</span><span> Share</span>
					  </div>
					  <div class="col-md-3"> 
						<span>200</span><span> views</span>
					  </div> */
					</div>-->
					<div class="card-footer p-0">
					  <div class="row ">
						<div class="col-md-4 manage ">
						 <!--  <div class="btn-like" ><a href="javascript:void(0)" class="likePost" d-Post="<?=$p_ost['post_id']?>"><i class="fa fa-thumbs-o-up" aria-hidden="true"></i>Like</a> <span class="font-weight-bold likeValue"> <?=$p_ost['total_likes']?></span></div> -->
              <div class="text-center px-3 py-1">
                <div class="btn-like d-flex" ><a href="javascript:void(0)" class="text-danger likePost" d-Post="<?=$p_ost['post_id']?>">
              <?php 

                if(count($p_ost['likes_data']) > 0){
                foreach ($p_ost['likes_data'] as $likedata) {
                 // print_r($likedata->profile_picture);
                  if($_SESSION['logged_in'][0]->user_id==$likedata->user_id){ ?>
                   <i class="fa fa-heart " aria-hidden="true"></i>
                 <?php   break;
                  }else{ ?>
                    <i class="fa fa-heart-o" aria-hidden="true"></i>
                 <?php }
                }
              }else{ ?>
                     <i class="fa fa-heart-o" aria-hidden="true"></i>
          <?php    }
              ?>
                  Like &nbsp;</a> 
                  <ul class="list-unstyled d-flex m-0">
                      <?php
                         $sno=1;
                        foreach ($p_ost['likes_data'] as $likedata) { 
                         
                            if($sno <= 5){
                            
                              if($sno==1){ ?>

                                   <li><img class="rounded-circle like_img " src="<?=base_url('assets/img/Profile_Pic/').$likedata->profile_picture?> "></li>

                          <?php }else{    ?>
                                <li><img class="rounded-circle like_img like_img_marg25" src="<?=base_url('assets/img/Profile_Pic/').$likedata->profile_picture?> "></li>
                     <?php  
                            }
                         }
                        $sno++;
                       }
                    ?>
                  
                    <!-- <li><img class="rounded-circle like_img  like_img_marg45" src="<?=base_url('assets/webimg/face.png')?> "></li>
                    <li><img class="rounded-circle like_img like_img_marg45" src="<?=base_url('assets/webimg/face.png')?> "></li>
                    <li><img class="rounded-circle like_img like_img_marg45" src="<?=base_url('assets/webimg/face.png')?> "></li> -->
                   <?php 
                     if(count($p_ost['likes_data']) > 0){ ?>
                         <li><div class=" like_cont likeValue rounded-circle like_img_marg25"> <?=$p_ost['total_likes']?></div></li>
                    <?php  
                        }else{ ?>
                            <li><div class=" like_cont likeValue rounded-circle "> <?=$p_ost['total_likes']?></div></li> 
                   <?php } ?>
                  </ul>
                </div> 
              </div>
						</div>
						<div class="col-md-4 manage px-3 py-1">
						  <div class="btn-comment post-btns">
                <a href="javascript:void(0)"><i class="fa fa-comment-o" aria-hidden="true"></i> Comments</a> 
                <span class=""><?=count($p_ost['total_comments'])?></span>
              </div>
						</div>
						<div class="col-md-4 manage px-3 py-1">
						  <div class="btn-share post-btns">
                <a href=""><i class="fa fa-share-square-o" aria-hidden="true"></i> Share</a>
                <span class=""><?=$p_ost['total_share']?></span>
              </div>
						</div>
					  </div>
           
					</div>
          <hr>
           <div class=" comments_list">
                <?php 
                //echo"hello";

                  //print_r($p_ost['total_comments']);
                if(count($p_ost['total_comments']>0)){
                ?>

                <?php for($i=0; $i < count($p_ost['total_comments']); $i++){ ?>
              <div class="row m-0">
                  <div class="col-md-1">
                      <span> <img class="rounded-circle like_img" src="<?=base_url()?>assets/img/Profile_Pic/<?=$MyDetails[0]->profile_picture?>"></span>  
                  </div>
                  <div class="col-md-10 comnt_text border-bottom">
                      <h6 class="font-weight-bold m-0" > <?=$p_ost['total_comments'][$i]->full_name?><small class="ml-3"><?=$p_ost['total_comments'][$i]->commented_on?></small></h6>
                      <p class=""><?=$p_ost['total_comments'][$i]->comment?></p>
                  </div>
                  <div class="col-md-1">
                    <div class="">
                          <div class="dropdown">
                            <button class="dropbtn"><i class="fa fa-ellipsis-v" aria-hidden="true"></i></button>
                            <div class="dropdown-content bg-white">
                              <a href="#">Edit</a>
                              <a href="#">Delete</a>
                              
                            </div>
                          </div>
                    </div>
                  </div>
              </div>
            <?php } 
          }?>
                <div class="p-2">
                 <div class="d-flex m-0">
                    <span> <img class="rounded-circle like_img" src="<?=base_url()?>assets/img/Profile_Pic/<?=$MyDetails[0]->profile_picture?>"></span>
                    <form method="POST" class="w-100 ad_cmnt" >
                      <div class="pl-2 w-100 _input">
                        <p class="lead emoji-picker-container">
                          <textarea class="input-field cmnt_" data-emojiable="true" type="text" name="comment" id="comment" placeholder="Add a Message">  </textarea>
                        </p>
                              <input type="hidden" name="post_id" value="<?=$p_ost['post_id']?>">
                      </div>
                      <!------contenteditable  data-text="Write a comment"------>
                     <!--  <div class="cmnt_icons">
                          <span title="Insert an emoji"> <i class="fa fa-smile-o" aria-hidden="true"></i>  </span> 
                           <label for="camera"><span title="Attach a photo or video"> <i class="fa fa-camera" aria-hidden="true"></i></span> </label>
                           <input type="file" id="camera" name="camera" class="d-none" >
                      </div> -->
                    </form>
                 </div>
                </div>
           
            </div>
				  </div>
			   <?php
		   }else if($p_ost['post_type']==1){
			   ?>
				<div class="card mt-4">
			   <div class="card-header ">
            <div class="d-flex float-left">
             <div> 
              <a class="font-weight-bold" href="#">
                 <img class="rounded-circle" src="<?=base_url('assets/webimg/face.png')?>" width="60">
               </a>
             </div>
            <div>
              <a class="font-weight-bold _use_n" href="#">  
               <?=$p_ost['posted_by']?>
              </a>
              <br>
                <small>
                  Published: June, 2 2018, 1:19 PM
                </small>
            </div>
                 
           </div>
                <?php if($_SESSION['logged_in'][0]->user_id==$p_ost['user_id']){ ?>
                    <div class="float-right mt-2">
                          <div class="dropdown">
                            <button class="dropbtn"><i class="fa fa-ellipsis-v" aria-hidden="true"></i></button>
                            <div class="dropdown-content bg-white">
                              <a href="#">Edit</a>
                              <a href="javascript:void(0)" class="dlt_post_" p_d=<?=$p_ost['post_id']?> >Delete</a>
                              
                            </div>
                          </div>
                    </div> 
                <?php } ?>
             <!-- <a class="" href="#"><img class="img-fluid float-right pt-3" src="<?=base_url('assets/webimg/dots.png')?>"></a> -->
            
          <!--   <div class="titles mt-1">
            <p class="pl-2">CAA के विरोध के नाम पर विपक्ष भड़का रहा है उपद्रवियों को?</p>
            </div> -->
          </div>
					<div class="card-body text-center">
						<p>
						<?=$p_ost['post']?>
						</p>
					  <div class="post_img"><a class="" href="#"><img class="img img-fluid d-block" src="<?=base_url()?>assets/uploads/images/<?=$p_ost['post_files']?>"></a></div>
					</div>
					
					<div class="card-footer p-0">
					  <div class="row text-center">
						<div class="col-md-4 manage ">
              <div class="text-center px-3 py-1">
  						  <div class="btn-like d-flex" ><a href="javascript:void(0)" class="text-danger likePost" d-Post="<?=$p_ost['post_id']?>">
              <?php 

                  if(count($p_ost['likes_data']) > 0){
                  foreach ($p_ost['likes_data'] as $likedata) {
                   // print_r($likedata->profile_picture);
                    if($_SESSION['logged_in'][0]->user_id==$likedata->user_id){ ?>
                     <i class="fa fa-heart " aria-hidden="true"></i>
                   <?php   break;
                    }else{ ?>
                      <i class="fa fa-heart-o" aria-hidden="true"></i>
                   <?php }
                  }
                }else{ ?>
                       <i class="fa fa-heart-o" aria-hidden="true"></i>
            <?php    }
                ?>
            Like &nbsp;</a> 
                  <ul class="list-unstyled d-flex m-0">
                    <?php

                         $sno=1;
                        foreach ($p_ost['likes_data'] as $likedata) { 
                         
                            if($sno <= 5){
                             
                              if($sno==1){ ?>
                                   <li><img class="rounded-circle like_img " src="<?=base_url('assets/img/Profile_Pic/').$likedata->profile_picture?> "></li>
                      <?php }else{    ?>
                            <li><img class="rounded-circle like_img like_img_marg25" src="<?=base_url('assets/img/Profile_Pic/').$likedata->profile_picture?> "></li>
                   <?php 
                            }
                         }
                        $sno++;
                       }
                    ?>
                    <?php 
                     if(count($p_ost['likes_data']) > 0){ ?>
                         <li><div class=" like_cont likeValue rounded-circle like_img_marg25"> <?=$p_ost['total_likes']?></div></li>
                    <?php  
                        }else{ ?>
                            <li><div class=" like_cont likeValue rounded-circle "> <?=$p_ost['total_likes']?></div></li> 
                   <?php } ?>
                   
                  </ul>
                </div>   
              </div>  
						</div>
						<div class="col-md-4 manage px-3 py-1">
						  <div class="btn-comment post-btns">
                <a href="javascript:void(0)"><i class="fa fa-comment-o" aria-hidden="true"></i> Comments</a>
                <span class=""><?=count($p_ost['likes_data'])?></span>
              </div>
						</div>
						<div class="col-md-4 manage px-3 py-1">
						  <div class="btn-share post-btns">
                <a href="javascript:void(0)"><i class="fa fa-share-square-o" aria-hidden="true"></i> Share</a>
                <span class=""><?=$p_ost['total_share']?></span>
              </div>
						</div>
					  </div>
					</div>
           <hr>
           <div class=" comments_list">
                <?php 
                //echo"hello";

                  //print_r($p_ost['total_comments']);
                if(count($p_ost['total_comments'])>0){
                ?>

                <?php for($i=0; $i < count($p_ost['total_comments']); $i++){ ?>
              <div class="row m-0">
                  <div class="col-md-1">
                      <span> <img class="rounded-circle like_img" src="<?=base_url()?>assets/img/Profile_Pic/<?=$MyDetails[0]->profile_picture?>"></span>  
                  </div>
                  <div class="col-md-10 comnt_text border-bottom">
                      <h6 class="font-weight-bold m-0" > <?=$p_ost['total_comments'][$i]->full_name?><small class="ml-3"><?=$p_ost['total_comments'][$i]->commented_on?></small></h6>
                      <p class=""><?=$p_ost['total_comments'][$i]->comment?></p>
                  </div>
                  <div class="col-md-1">
                    <div class="">
                          <div class="dropdown">
                            <button class="dropbtn"><i class="fa fa-ellipsis-v" aria-hidden="true"></i></button>
                            <div class="dropdown-content bg-white">
                              <a href="#">Edit</a>
                              <a href="#">Delete</a>
                              
                            </div>
                          </div>
                    </div>
                  </div>
              </div>
            <?php } 
          }?>
                <div class="p-2">
                 <div class="d-flex m-0">
                    <span> <img class="rounded-circle like_img" src="<?=base_url()?>assets/img/Profile_Pic/<?=$MyDetails[0]->profile_picture?>"></span>
                    <form method="POST" class="w-100 ad_cmnt" >
                      <div class="pl-2 w-100 _input">
                        <p class="lead emoji-picker-container">
                          <textarea class="input-field cmnt_" data-emojiable="true" type="text" name="comment" id="comment" placeholder="Add a Message">  </textarea>
                        </p>
                              <input type="hidden" name="post_id" value="<?=$p_ost['post_id']?>">
                      </div>
                      <!------contenteditable  data-text="Write a comment"------>
                     <!--  <div class="cmnt_icons">
                          <span title="Insert an emoji"> <i class="fa fa-smile-o" aria-hidden="true"></i>  </span> 
                           <label for="camera"><span title="Attach a photo or video"> <i class="fa fa-camera" aria-hidden="true"></i></span> </label>
                           <input type="file" id="camera" name="camera" class="d-none" >
                      </div> -->
                    </form>
                 </div>
                </div>

            </div>
				  </div>
			   <?php
		   }else{
			   ?>
				<div class="card mt-4">
					 <div class="card-header ">
            <div class="d-flex float-left">
             <div> 
              <a class="font-weight-bold" href="#">
                 <img class="rounded-circle" src="<?=base_url('assets/webimg/face.png')?>" width="60">
               </a>
             </div>
            <div>
              <a class="font-weight-bold _use_n" href="#">  
                <?=$p_ost['posted_by']?>
              </a>
              <br>
                <small>
                  Published: June, 2 2018, 1:19 PM
                </small>
            </div>
                 
           </div>
                <?php if($_SESSION['logged_in'][0]->user_id==$p_ost['user_id']){ ?>
                    <div class="float-right mt-2">
                          <div class="dropdown">
                            <button class="dropbtn"><i class="fa fa-ellipsis-v" aria-hidden="true"></i></button>
                            <div class="dropdown-content bg-white">
                              <a href="#">Edit</a>
                              <a href="javascript:void(0)" class="dlt_post_" p_d=<?=$p_ost['post_id']?> >Delete</a>
                              
                            </div>
                          </div>
                    </div> 
                <?php } ?>
             <!-- <a class="" href="#"><img class="img-fluid float-right pt-3" src="<?=base_url('assets/webimg/dots.png')?>"></a> -->
            
          <!--   <div class="titles mt-1">
            <p class="pl-2">CAA के विरोध के नाम पर विपक्ष भड़का रहा है उपद्रवियों को?</p>
            </div> -->
          </div>
					<div class="card-body text-center">
					<p>
						<?=$p_ost['post']?>
						</p>
					  <div class="">
					  <video controls class="w-100">
					  <source src="<?=base_url()?>assets/uploads/videos/<?=$p_ost['post_files']?>" type="video/mp4">
					
					Your browser does not support the video tag.
					</video>
					</div>  
					</div>
					
					<div class="card-footer p-0">
					  <div class="row text-center">
  						<div class="col-md-4 manage  ">
  						<!--   <div class="btn-like" ><a href="javascript:void(0)" class="likePost" d-Post="<?=$p_ost['post_id']?>"><i class="fa fa-thumbs-o-up" aria-hidden="true"></i>Like</a> <span class="font-weight-bold likeValue"> <?=$p_ost['total_likes']?></span></div> -->
                <div class="text-center px-3 py-1">
                  <div class="btn-like d-flex" ><a href="javascript:void(0)" class="text-danger likePost" d-Post="<?=$p_ost['post_id']?>">

                    <?php 

                    if(count($p_ost['likes_data']) > 0){
                    foreach ($p_ost['likes_data'] as $likedata) {
                     // print_r($likedata->profile_picture);
                      if($_SESSION['logged_in'][0]->user_id==$likedata->user_id){ ?>
                       <i class="fa fa-heart " aria-hidden="true"></i>
                     <?php   break;
                      }else{ ?>
                        <i class="fa fa-heart-o" aria-hidden="true"></i>
                     <?php }
                    }

                  }else{ ?>
                         <i class="fa fa-heart-o" aria-hidden="true"></i>
              <?php    }
                  ?>
                  Like &nbsp;</a> 
                    <ul class="list-unstyled d-flex m-0">
                      <?php
                           $sno=1;
                          foreach ($p_ost['likes_data'] as $likedata) { 
                            
                              if($sno <= 5){
                               
                                if($sno==1){ ?>
                                     <li><img class="rounded-circle like_img " src="<?=base_url('assets/img/Profile_Pic/').$likedata->profile_picture?> "></li>
                        <?php }else{    ?>
                              <li><img class="rounded-circle like_img like_img_marg25" src="<?=base_url('assets/img/Profile_Pic/').$likedata->profile_picture?> "></li>
                     <?php 
                              }
                           }
                          $sno++;
                         }
                      ?>
                      <?php 
                     if(count($p_ost['likes_data']) > 0){ ?>
                         <li><div class=" like_cont likeValue rounded-circle like_img_marg25"> <?=$p_ost['total_likes']?></div></li>
                    <?php  
                        }else{ ?>
                            <li><div class=" like_cont likeValue rounded-circle "> <?=$p_ost['total_likes']?></div></li> 
                   <?php } ?>
                    </ul>
                </div> 
              </div>
						</div>
						<div class="col-md-4 manage  px-3 py-1">
						  <div class="btn-comment post-btns">
                <a href="javascript:void(0)"><i class="fa fa-comment-o" aria-hidden="true"></i> Comments</a>
                 <span class=""><?=count($p_ost['likes_data'])?></span>
               </div>
						</div>
						<div class="col-md-4 manage  px-3 py-1">
						  <div class="btn-share post-btns">
                <a href="javascript:void(0)"><i class="fa fa-share-square-o" aria-hidden="true"></i> Share</a>
                <span class=""><?=$p_ost['total_share']?></span>
              </div>
						</div>
					  </div>
					</div>
           <hr>
           <div class=" comments_list">
                   <?php 
                //echo"hello";

                  //print_r($p_ost['total_comments']);
                if(count($p_ost['total_comments']>0)){
                ?>

                <?php for($i=0; $i < count($p_ost['total_comments']); $i++){ ?>
              <div class="row m-0">
                  <div class="col-md-1">
                      <span> <img class="rounded-circle like_img" src="<?=base_url()?>assets/img/Profile_Pic/<?=$MyDetails[0]->profile_picture?>"></span>  
                  </div>
                  <div class="col-md-10 comnt_text border-bottom">
                      <h6 class="font-weight-bold m-0" > <?=$p_ost['total_comments'][$i]->full_name?><small class="ml-3"><?=$p_ost['total_comments'][$i]->commented_on?></small></h6>
                      <p class=""><?=$p_ost['total_comments'][$i]->comment?></p>
                  </div>
                  <div class="col-md-1">
                    <div class="">
                          <div class="dropdown">
                            <button class="dropbtn"><i class="fa fa-ellipsis-v" aria-hidden="true"></i></button>
                            <div class="dropdown-content bg-white">
                              <a href="#">Edit</a>
                              <a href="#">Delete</a>
                              
                            </div>
                          </div>
                    </div>
                  </div>
              </div>
            <?php } 
          }?>
              <div class="p-2">
                 <div class="d-flex m-0">
                    <span> <img class="rounded-circle like_img" src="<?=base_url()?>assets/img/Profile_Pic/<?=$MyDetails[0]->profile_picture?>"></span>
                    <form method="POST" class="w-100 ad_cmnt" >
                      <div class="pl-2 w-100 _input">
                        <p class="lead emoji-picker-container">
                          <textarea class="input-field cmnt_" data-emojiable="true" type="text" name="comment" id="comment" placeholder="Add a Message">  </textarea>
                        </p>
                              <input type="hidden" name="post_id" value="<?=$p_ost['post_id']?>">
                      </div>
                      <!------contenteditable  data-text="Write a comment"------>
                     <!--  <div class="cmnt_icons">
                          <span title="Insert an emoji"> <i class="fa fa-smile-o" aria-hidden="true"></i>  </span> 
                           <label for="camera"><span title="Attach a photo or video"> <i class="fa fa-camera" aria-hidden="true"></i></span> </label>
                           <input type="file" id="camera" name="camera" class="d-none" >
                      </div> -->
                    </form>
                 </div>
              </div>

            </div>
				  </div>
			   <?php
		   }
		   
	   }
	  ?>
      
       
       
    </div>
    <!-- end center panel -->
    <!--right sidepanel -->
    <div class="col-md-3 border-left pt-3 bgdefault">
      <div class="">
        <form class="form-inline my-2"> 
          <input class="form-control w-100" type="search" placeholder="Search">
        </form>
        <nav>
          <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
              <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">All</a>
              <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-active" role="tab" aria-controls="nav-profile" aria-selected="false">Active</a>
          </div>
        </nav>
        <div class="tab-content" id="nav-tabContent">
          <div class="tab-pane fade show active pt-4" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
            <span class="d-flex">
              <h5><?=$MyDetails[0]->full_name?> <i class="fa fa-circle" aria-hidden="true" style="font-size: 12px"></i>
              </h5>
              <input type="checkbox" checked data-toggle="toggle" data-onstyle="success" data-offstyle="secondary">
            </span>
            <span>Contact <?=count($MyFriends)?></span>
            <ul class="list-group">
              <?php
                foreach ($MyFriends as $frnd) {
                  # code...
                  ?>
                     <li class="list-group-item d-flex justify-content-between align-items-center">
                      <a href="javascript:void(0)" class="chatFriend" d-name="<?=$frnd->full_name?>" d-fNd="<?=$frnd->user_id?>">
                        <?=$frnd->full_name?>
                        <i class="fa fa-circle ml-auto" aria-hidden="true"></i> <i class="pl-3 fa fa-angle-right" aria-hidden="true"></i>
                      </a>
                      </li>
                  <?php
                }
              ?>
            </ul>
          </div>
          <div class="tab-pane fade pt-3" id="nav-active" role="tabpanel" aria-labelledby="nav-profile-tab">
            <h5><?=$MyDetails[0]->full_name?> <i class="fa fa-circle" aria-hidden="true" style="font-size: 12px"></i>
              </h5>
            <ul class="list-group">
              <?php
                foreach ($MyFriends as $frnd) {
                  # code...
                  ?>
                     <li class="list-group-item d-flex justify-content-between align-items-center">
                        <a href="javascript:void(0)" class="chatFriend">
                          <?=$frnd->full_name?>
                          <i class="fa fa-circle ml-auto" aria-hidden="true"></i> <i class="pl-3 fa fa-angle-right" aria-hidden="true"></i>
                        </a>
                      </li>
                  <?php
                }
              ?>
            </ul>
          </div>
        </div>
        <div class="trend bg-white p-3 mt-3">
          <h6>TRENDING</h6>
            <ul class="list-group">
              <?php
              foreach ($Trending as $trending) {
              ?>
              <li class="list-group-item d-flex justify-content-between align-items-center px-1">
                <img class="img-fluid w-25" src="<?=base_url()?>assets/img/Profile_Pic/<?=$trending->profile_picture?>">
                <small><?=$trending->post?></small>
                <i class="fa fa-angle-right pl-1" aria-hidden="true"></i>
              </li>
              <?php
              }
              ?>
            </ul>
        </div>
      </div>
    </div>
    <!--End right sidepanel -->
  </div>
</div>
<div id="statusModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <a href="" id="redirecTo"><h4 class="modal-title" id="prod_By"></h4></a>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        
      </div>
      <div class="modal-body">
        <img src="" class="img-fluid" id="stImg">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<div id="postStatus" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h4><?=$MyDetails[0]->full_name?></h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        
      </div>
      <div class="modal-body">
        <img src="" class="img-fluid" id="stImg">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<script type="text/javascript">
  $(document).on('click','#addStatus',function(){
    $('#postStatus').modal('show');
  });
  $(document).on('click','.usr_status',function(){
    var status_=$(this).find('img').attr('src');
    var name_=$(this).attr('d-By');
    var profile_=$(this).attr('d-Gen');
    $('#redirecTo').attr('href',"<?=base_url('Profile/')?>"+profile_);
    $('#stImg').attr('src',status_);
    
    
    $('#prod_By').html(name_);
    $('#statusModal').modal('show');

  });
  $(document).ready(function() {
      $('.js-example-basic-multiple').select2();
  });

$(function () {
    $('.icontheme').click (function () {
        $(this).toggleClass ('expanded');
        $('.bgimgs').toggleClass ('expanded');
    });
});
</script>
<script type="text/javascript">
  $(document).on('click','.likePost',function(){
	  var ele=$(this);
    var post_id=ele.attr('d-Post');
	  // var likes=ele.find('likeValue').html();
	// console.log(likes);
var like = ele.find("i").attr("class");
 var lcnt = $(this).parent().find('ul').find('.like_cont').html();
  var post_id=ele.attr('d-Post');
    $.ajax({
      url:"<?=base_url('APIController/likeOrdislike')?>",
      type:"post",
      data:{post_id:post_id,to_do:'like'},
      success:function(response){
        response=JSON.parse(response);
        if(response.code==1){
			     if(like=='fa fa-heart-o'){
               ele.parent().find('ul').find('.like_cont').html(parseInt(lcnt)+1);
               ele.find("i").attr("class","fa fa-heart");
            }else{
              ele.find("i").attr("class","fa fa-heart-o");
               ele.parent().find('ul').find('.like_cont').html(parseInt(lcnt)-1);
            }
      //    swal("Good", response.msg, "success");
        }else{
        //  swal("Oops...!", response.msg, "warning");
        }
      }
    })
  });
</script>
<script type="text/javascript">
  $(document).on('click','.theme_',function()
  {
     var imgs=$(this).find('img').attr('src');
      //console.log(imgs);
      $('.emojionearea-editor').css('background','url('+imgs+')');
      $('.emojionearea-editor').css("min-height","9em");
      $('.emojionearea-editor').css("text-align","center");
      $('.emojionearea-editor').css("font-size","28px");
      $('.emojionearea-editor').css("background-size","cover");
      $('.emojionearea-editor').css("color","black");
      $('.emojionearea-editor').attr("id","screenshot");
  })
</script>
<script>
// $(document).ready(function(){

// // var element = $(".emojionearea"); // global variable

// var getCanvas; // global variable
 
//     $("#btn-Preview-Image").on('click', function () {
//       var element = $("#screenshot");
//          html2canvas(element, {
//          onrendered: function (canvas) {
//                 $("#previewImage").append(canvas);
//                 getCanvas = canvas;
//              }
//          });
//     });

//   $("#btn-Convert-Html2Image").on('click', function () {
//     var element = $("#screenshot");
//     var imgageData = getCanvas.toDataURL("image/png");
//    // console.log(imgageData);
//     // Now browser starts downloading it instead of just showing it
//     var newData = imgageData.replace(/^data:image\/png/, "data:application/octet-stream");
//     $("#btn-Convert-Html2Image").attr("download", "your_pic_name.png").attr("href", newData);
//   });

// });
</script>
<script>
  $(document).on('click','.tagfriend',function(){
   // $('.withs').css('display','flex');
   $('.withs').toggleClass ('expanded');
  });
</script>
<script>

  $(document).ready(function() {
        $("#emojionearea1").emojioneArea({
            pickerPosition: "right",
            tonesStyle: "bullet",
            events: {
            keyup: function (editor, event) {
              countChar(this);
                //console.log(editor.html());
               console.log(this.getText());
            }
          }
        });
        $('#divOutside').click(function () {
          $('.emojionearea-button').click()
        })        
    });
   function countChar(val) {
            var len = val.getText().length;
            if (len >= 140) {
                 /*  val.value = val.content.substring(0, 140) */;
                 $('#chars').text(0); 
                    $('.emojionearea-editor').css('background','transparent');
                    $('.emojionearea-editor').css("min-height","8em");
                    $('.emojionearea-editor').css("max-height","15em");
                    $('.emojionearea-editor').css("font-size","inherit");
            } 
            else 
            {
                // $('#chars').text(140 - len);
            }
        }
</script>
<script>
  $("#add_post").submit(function(e){
        e.preventDefault();
        var formData= new FormData($(this)[0]);
        // formData.append('user_id',user_id);
        var ext_array=[];
        var selection = document.getElementById('img_video');
        for (var i=0; i<selection.files.length; i++) {
            var ext = selection.files[i].name.substr(-3);
            ext_array.push(ext);
        }
        if ($.inArray('mp4', ext_array) != -1 && ($.inArray('jpg', ext_array) != -1 || $.inArray('jpeg', ext_array) != -1 || $.inArray('gif', ext_array) != -1 || $.inArray('png', ext_array) != -1)) {
            alert('Video and Image');
            formData.append('post_type','3');
        }
        else if($.inArray('mp4', ext_array) != -1){
          // alert('video only');
          formData.append('post_type','2');
        }
        else if($.inArray('jpg', ext_array) != -1 || $.inArray('jpeg', ext_array) != -1 || $.inArray('gif', ext_array) != -1 || $.inArray('png', ext_array) != -1){
          formData.append('post_type','1');
        }
        else{
          formData.append('post_type','0');
          // alert('Text Only');
        }
         var bg=$('.emojionearea-editor').css('background');
          if(bg!='rgba(0, 0, 0, 0) none repeat scroll 0% 0% / auto padding-box border-box')
          { 
            var getCanvas;
             html2canvas($('#screenshot'),{
            allowTaint:false,
            useCORS :true
          }).then(function (canvas) {
          // global variable
            // var element = $("#screenshot");
            // html2canvas(element, {
            // onrendered: function (canvas) {
           // $("#previewImage").append(canvas);
            getCanvas = canvas;
            var imgageData = getCanvas.toDataURL("image/png");             
            formData.append('imgageData',imgageData);
            run();
           });
        }

          else
          {
              run();
          }
            function run()
            {
              var posted_on = [];
              $.each($("input[name='optradio']:checked"), function(){
                  posted_on.push($(this).val());
              });
              var myString= posted_on.join(",");
              var arr=myString.split(',');
              for(var i=0;i<arr.length;i++)
              {
                if(arr[i]=='story')
                {
                  story();
                }
                else if(arr[i]=='post' && arr[i+1]=='story')
                {
                  post();
                  story();
                  break;
                }
                else
                {
                  post();
                }
            }
            function story()
            {
                     $.ajax({
                        url:"<?=base_url()?>Home/addstories",
                         type:"post",
                         data:formData,
                         contentType:false,
                         processData:false,
                         cache:false,

                        success:function(response)
                        {
                          console.log(response);
                          response=JSON.parse(response);
                          if(response.status==1){
                            alert(response.msg);
                            // swal("Success", "Story Successfully", "success");
                            $("#add_post").trigger("reset");
                            location.reload();
                          }
                        }
                    });  
            }
            function post()
            {
                     $.ajax({
                        url:"<?=base_url()?>APIController/addPost",
                         type:"post",
                         data:formData,
                         contentType:false,
                         processData:false,
                         cache:false,

                        success:function(response)
                        {
                          console.log(response);
                          response=JSON.parse(response);
                          if(response.status==1){
                            alert(response.msg);
                            // swal("Success", "Story Successfully", "success");
                            $("#add_post").trigger("reset");
                            location.reload();
                          }
                        }
                  });  
              }
            }
          });


</script>

<script type="text/javascript">
  $(function() {
    $.fn.scrollBottom = function() {
        return $(document).height() - this.scrollTop() - this.height();
    };

    var $el = $('#w_t_follow');
    var $window = $(window);

    $window.bind("scroll resize", function() {
        var gap = $window.height() - $el.height() - 10;
        var visibleFoot = 630 - $window.scrollBottom();
        var scrollTop = $window.scrollTop()
        
        if(scrollTop < 630 + 10){
            $el.css({
                top: (630 - scrollTop) + "px",
                bottom: "auto"
            });
        }else if (visibleFoot > gap) {
            $el.css({
                top: "auto",
                bottom: visibleFoot + "px"
            });
        } else {
            $el.css({
                top: 80,
                bottom: "auto"
            });
        }
    });
});
</script>

<!-- <script type="text/javascript">
  $(document).on("click",".btn-comment",function(){
      $(this).parent().parent().parent().find(".comments_list").slideToggle();
  })
</script> -->


<script>
$(function () {
    // Initializes and creates emoji set from sprite sheet
    window.emojiPicker = new EmojiPicker({
        emojiable_selector: '[data-emojiable=true]',
        assetsPath: 'http://onesignal.github.io/emoji-picker/lib/img/',
          popupButtonClasses: 'fa fa-smile-o',
          events: {
            keyup: function (editor, event) {
              countChar(this);
                console.log(editor.html());
                console.log(this.getText());
            }
          }
    });

    window.emojiPicker.discover();
});
     
        // $("#emojionearea1").emojioneArea({
        //     pickerPosition: "right",
        //     tonesStyle: "bullet",
        //     events: {
        //     keyup: function (editor, event) {
        //       countChar(this);
        //         console.log(editor.html());
        //         console.log(this.getText());
        //     }
        //   }
        // });
</script>

<script type="text/javascript">
   $(document).ready(function () {
  $('.cmnt_').keyup(function (e) {
    if (e.which == 13) {
      console.log("dsadnsajnda");
      var text = $(this).closest(".emoji-wysiwyg-editor").html();
console.log(text);
      // $(".ad_cmnt").submit(function (ev) {
      //     ev.preventDefault();
        var form = $('.ad_cmnt')[0];
        console.log(form);
         var formdata = new FormData(form);
         formdata.append("comment",text);
          for (var value of formdata.values()) {
             console.log(value); 
          }
          console.log("hello");
          // var comment =$(this).val();
          // var post_id_comnt =$(this).attr("p_d");

          // console.log(comment);
          //  console.log(post_id_comnt);
          // Get input field values
             // var formData= new FormData($(this)[0]);
             $.ajax({
                        url:"<?=base_url()?>APIController/addComment",
                         type:"post",
                         data:formdata,
                         contentType:false,
                         processData:false,
                         cache:false,

                        success:function(response)
                        {
                          console.log(response);
                          response=JSON.parse(response);
                          // if(response.status==1){
                          //   alert(response.msg);
                          //   // swal("Success", "Story Successfully", "success");
                          //   $("#add_post").trigger("reset");
                          //   location.reload();
                          // }
                          $('.ad_cmnt').trigger("reset");
                        }
                  });  
         
 
    }
  });

  $(document).on("click",".dlt_post_",function(){
    var ele =$(this);
     var post_id =ele.attr("p_d");
     $.ajax({
            url:"<?=base_url()?>APIController/deletePost",
             type:"post",
             data:{post_id:post_id},
             cache:false,

            success:function(response)
            {
              console.log(response);
              response=JSON.parse(response);
              if(response.code==1){
                  ele.parent().parent().parent().parent().parent().remove();
              } 
            }
      });  
  })

});
</script>
