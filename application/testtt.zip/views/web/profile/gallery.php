
 <!-- center panel -->
    <div class="col-md-9">
        
        <nav>
          <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
              <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Photos</a>
              <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-active" role="tab" aria-controls="nav-profile" aria-selected="false">Albums</a>
              <a class="nav-item nav-link" id="nav-profile-videos" data-toggle="tab" href="#nav-videos" role="tab" aria-controls="nav-profile" aria-selected="false">Videos</a>
          </div>
        </nav>
        <div class="tab-content" id="nav-tabContent">
          <div class="tab-pane fade show active pt-3" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
            <div class="row">
              <div class="col-md-3 mt-2">
                <form method="post" action="#" id="drg">
                   <div class=" files">
                      <label class="" for="drag_imgs"></label>
                      <input type="file" id="drag_imgs" class="form-control d-none" multiple="">
                      </div>
                </form>
              </div>

              <?php
                foreach ($MyPosts as $post) {
                  if($post->post_type==1){
                    ?>
                      <div class="col-md-3 mt-2 p-1">
                        <div class="content">
                          <a href="<?=base_url().$post->post_id?>" target="_blank">
                            <div class="content-overlay"></div>
                            <img class="content-image" src="<?=base_url('assets/uploads/images/').$post->post_files?>">
                            <div class="content-details fadeIn-bottom fadeIn-right">
                              <div class="">
                                <div class="float-left"><p><span>100</span> <i class="fa fa-thumbs-o-up" aria-hidden="true"></i></p></div>
                                <div class="float-right"><p><span>12</span> <i class="fa fa-comment-o" aria-hidden="true"></i></p></div>
                              </div>
                            
                            </div>
                          </a>
                        </div>
                    </div>
                    <?php
                  }
                }
              ?>
              
              <!-- <div class="col-md-3 mt-2 p-1">
                  <div class="content">
                    <a href="https://unsplash.com/photos/HkTMcmlMOUQ" target="_blank">
                      <div class="content-overlay"></div>
                      <img class="content-image" src="https://images.unsplash.com/photo-1433360405326-e50f909805b3?ixlib=rb-0.3.5&q=80&fm=jpg&crop=entropy&w=1080&fit=max&s=359e8e12304ffa04a38627a157fc3362">
                      <div class="content-details fadeIn-bottom fadeIn-right">
                        <div class="">
                          <div class="float-left"><p><span>100</span> <i class="fa fa-thumbs-o-up" aria-hidden="true"></i></p></div>
                          <div class="float-right"><p><span>12</span> <i class="fa fa-comment-o" aria-hidden="true"></i></p></div>
                        </div>
                      
                      </div>
                    </a>
                  </div>
              </div>
              <div class="col-md-3 mt-2 p-1">
                  <div class="content">
                    <a href="https://unsplash.com/photos/HkTMcmlMOUQ" target="_blank">
                      <div class="content-overlay"></div>
                      <img class="content-image" src="https://images.unsplash.com/photo-1433360405326-e50f909805b3?ixlib=rb-0.3.5&q=80&fm=jpg&crop=entropy&w=1080&fit=max&s=359e8e12304ffa04a38627a157fc3362">
                      <div class="content-details fadeIn-bottom fadeIn-right">
                        <div class="">
                          <div class="float-left"><p><span>100</span> <i class="fa fa-thumbs-o-up" aria-hidden="true"></i></p></div>
                          <div class="float-right"><p><span>12</span> <i class="fa fa-comment-o" aria-hidden="true"></i></p></div>
                        </div>
                      
                      </div>
                    </a>
                  </div>
              </div>
              <div class="col-md-3 mt-2 p-1">
                  <div class="content">
                    <a href="https://unsplash.com/photos/HkTMcmlMOUQ" target="_blank">
                      <div class="content-overlay"></div>
                      <img class="content-image" src="https://images.unsplash.com/photo-1433360405326-e50f909805b3?ixlib=rb-0.3.5&q=80&fm=jpg&crop=entropy&w=1080&fit=max&s=359e8e12304ffa04a38627a157fc3362">
                      <div class="content-details fadeIn-bottom fadeIn-right">
                        <div class="">
                          <div class="float-left"><p><span>100</span> <i class="fa fa-thumbs-o-up" aria-hidden="true"></i></p></div>
                          <div class="float-right"><p><span>12</span> <i class="fa fa-comment-o" aria-hidden="true"></i></p></div>
                        </div>
                      
                      </div>
                    </a>
                  </div>
              </div> -->
              <!-- <div class="col-md-3 mt-2 p-1">
                  <div class="content">
                    <a href="https://unsplash.com/photos/HkTMcmlMOUQ" target="_blank">
                      <div class="content-overlay"></div>
                      <img class="content-image" src="https://images.unsplash.com/photo-1433360405326-e50f909805b3?ixlib=rb-0.3.5&q=80&fm=jpg&crop=entropy&w=1080&fit=max&s=359e8e12304ffa04a38627a157fc3362">
                      <div class="content-details fadeIn-bottom fadeIn-right">
                        <div class="">
                          <div class="float-left"><p><span>100</span> <i class="fa fa-thumbs-o-up" aria-hidden="true"></i></p></div>
                          <div class="float-right"><p><span>12</span> <i class="fa fa-comment-o" aria-hidden="true"></i></p></div>
                        </div>
                      
                      </div>
                    </a>
                  </div>
              </div> -->
            </div>
          </div>
          <div class="tab-pane fade pt-3" id="nav-active" role="tabpanel" aria-labelledby="nav-profile-tab">
           <!--  <h5>Diana Katherine <i class="fa fa-circle" aria-hidden="true" style="font-size: 12px"></i>
              </h5> -->
              <div class="row">
                <div class="mt-2 col-md-4">
                 
                    <div class="text-center crt_ht border p-3" data-toggle="modal" data-target="#myModal">
                      <h2><i class="fa fa-plus-circle" aria-hidden="true"></i></h2>
                      <h4>Create an Album</h4>
                      <p>It only takes a few minutes!</p>
                    </div>
                </div>
                <?php
                  foreach ($MyAlbum as $album) {
                    $imgArr=explode(',',$album->images_path);
                    # code...?>
                    <div class="mt-2 col-md-4 albums border-bottom">
                      <div class="albums_ht">
                        <img src="<?=base_url().$imgArr[0]?>" class="h-100 img-fluid">
                      </div>
                      <div class="d-flex mt-1 justify-content-center">
                         <h4><?=$album->album_title?></h4>
                      </div>
                      
                    </div>
                    <?php
                  }
                ?>
                
            </div>
          </div>
           <div class="tab-pane fade pt-3" id="nav-videos" role="tabpanel" aria-labelledby="nav-profile-videos">
              <div class="row">
                <div class="col-md-4 mt-2">
                  <form method="post" action="#" id="videos">
                      <div class=" files">
                        <label class="" for="drag_img"></label>
                        <input type="file" name="videos_name" id="drag_img" class="form-control d-none">
                      </div>
                      <button class="btn btn-success" type="submit">Submit</button>
                  </form>
                </div>
                <?php
                foreach ($MyPosts as $post) {
                  if($post->post_type==2){
                    ?>
                      <div class="mt-2 col-md-4">
                        <video width="100%"  controls>
                          <source src="<?=base_url('assets/uploads/videos/').$post->post_files?>" type="video/mp4">
                          <source src="<?=base_url('assets/uploads/videos/').$post->post_files?>" type="video/ogg">
                          Your browser does not support the video tag.
                        </video>
                      </div>
                    <?php
                  }
                }
                ?>
                
                <!-- <div class="mt-2 col-md-4">
                  <video width="100%"  controls>
                    <source src="assets/uploads/videos/56821.mp4" type="video/mp4">
                    <source src="assets/uploads/videos/56821.mp4" type="video/ogg">
                    Your browser does not support the video tag.
                  </video>
                </div> -->
                <div class="mt-2 col-md-4">
                  <video width="100%"  controls>
                    <source src="assets/uploads/videos/56821.mp4" type="video/mp4">
                    <source src="assets/uploads/videos/56821.mp4" type="video/ogg">
                    Your browser does not support the video tag.
                  </video>
                </div>
              
              </div>
           </div>
        </div>
    </div>
    <!-- end center panel -->
</div>
</section>
   <!-- Album Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
          <h5 class="modal-title">Create an Album</h5>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      
      </div>
      <div class="modal-body">
        <form method="POST" id="album">
          <div class="form-group">
          <!--   <label><strong>Album Title :</strong></label>
            -->
            <label for="title" class="inp">
              <input type="text" name="alb_title" id="alb_title"  class="">
              <span class="label">Album Title :</span>
              <span class="border"></span>
            </label>
        
          </div>
          <div class="form-group">
            <label for="description" class="inp">
              <textarea name="alb_desc"  id="alb_desc" placeholder="&nbsp;" class="" rows="2"> </textarea> 
              <span class="label">Album Description</span>
            
            </label>

          </div>
          <div class="form-group">
            <label for="ad_img" class="inp">
              <input type="file" id="ad_img" name="files[]"  class="" multiple="">
              <span class="label">Add Image</span>
            
            </label>
          </div>
          <div class="text-center"><button class="btn btn-success" type="submit">Add Album</button></div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

<script type="text/javascript">
  
$("#album").submit(function(e){
      e.preventDefault();
      var formData= new FormData($(this)[0]);
      $.ajax({
          url:"<?=base_url()?>APIController/createalbum",
           type:"post",
           data:formData,
           contentType:false,
           processData:false,
           cache:false,
          success:function(response)
          {
            var response=JSON.parse(response);
            if(response.status==1)
            {
              alert(response.msg);
              location.reload();
            }
            else
            {
              alert(response.msg)
            }
          }
      });
  });
$("#videos").submit(function(e){
        e.preventDefault();
        var formData= new FormData($(this)[0]);
        $.ajax({
            url:"<?=base_url()?>APIController/insertvideo",
             type:"post",
             data:formData,
             contentType:false,
             processData:false,
             cache:false,
            success:function(response)
            {
              var response=JSON.parse(response);
              if(response.status==1)
              {
                alert(response.msg);
                location.reload();
              }
              else
              {
                alert(response.msg)
              }
            }
        });
    });
</script>
<!-- <script type="text/javascript">
  $('.file-upload').file_upload();
</script> -->
<style>
.inp {
  position: relative;
  margin: auto;
  width: 100%;
 
}
.inp .label {
  position: absolute;
  top: 16px;
  left: 0;
  font-size: 16px;
  color: #9098a9;
  font-weight: 500;
  transform-origin: 0 0;
  transition: all 0.2s ease;
}
.inp .border {
  position: absolute;
  bottom: 0;
  left: 0;
  height: 2px;
  width: 100%;
  background: #07f;
  transform: scaleX(0);
  transform-origin: 0 0;
  transition: all 0.15s ease;
}
.inp input, textarea {
  -webkit-appearance: none;
  width: 100%;
  border: 0;
  font-family: inherit;
  
  height: 48px;
  font-size: 16px;
  font-weight: 500;
  border-bottom: 2px solid #c8ccd4;
  background: none;
  border-radius: 0;
  color: #223254;
  transition: all 0.15s ease;
}
.inp input:hover, .inp textarea:hover {
  background: rgba(34,50,84,0.03);
}
.inp input:not(:placeholder-shown) + span,
.inp textarea:not(:placeholder-shown) + span {
  color: #5a667f;
  transform: translateY(-26px) scale(0.75);
}
.inp input:focus,
.inp textarea:focus {
  background: none;
  outline: none;
}
.inp input:focus + span,
.inp textarea:focus + span  {
  color: #07f;
  transform: translateY(-26px) scale(0.75);
}
.inp input:focus + span + .border,
.inp textarea:focus + span + .border {
  transform: scaleX(1);
}




.crt_ht{
      height: 220px;
}

  .albums .albums_ht{
    height: 180px;
  }

  /*----drag and drop-----*/
  .files label {
    outline: 2px dashed #92b0b3;
   /* outline-offset: -10px;*/
    -webkit-transition: outline-offset .15s ease-in-out, background-color .15s linear;
    transition: outline-offset .15s ease-in-out, background-color .15s linear;
 padding: 43px 0px 83px 8%;
    text-align: center !important;
    margin: 0;
    width: 100% !important;
}
.files input:focus{     outline: 2px dashed #92b0b3;  outline-offset: -10px;
    -webkit-transition: outline-offset .15s ease-in-out, background-color .15s linear;
    transition: outline-offset .15s ease-in-out, background-color .15s linear; border:1px solid #92b0b3;
 }
.files{ position:relative}
.files:after {  pointer-events: none;
    position: absolute;
    top: 22px;
    left: 0;
    width: 30px;
    right: 0;
    height: 56px;
    content: "";
    background-image: url(https://image.flaticon.com/icons/png/128/109/109612.png);
    display: block;
    margin: 0 auto;
    background-size: 100%;
    background-repeat: no-repeat;
}
.color input{ background-color:#f1f1f1;}
.files:before {
    position: absolute;
    bottom: 10px;
    left: 0;  pointer-events: none;
    width: 100%;
    right: 0;
    height: 57px;
    content: "Select or drag it here. ";
    display: block;
    margin: 0 auto;
    color: #2ea591;
    font-weight: 600;
    text-transform: capitalize;
    text-align: center;
} 
</style>  