<style type="text/css">
  .postProfile-pic{
    width: 30px !important;
    height: : 30px !important;
  }
  .fa-address-card {
    border: 1px solid black;
    border-radius: 50%;
    padding: 10px;
}
</style>
<script>
$( document ).ready(function(e) {
  $('.profile').addClass('active');
})
</script>
<link href="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/js/select2.min.js"></script>
<script type="text/javascript" src="https://html2canvas.hertzen.com/dist/html2canvas.min.js"></script>
    <script src="https://files.codepedia.info/files/uploads/iScripts/html2canvas.js"></script>
 <!-- center panel -->
<div class="col-md-6">
        <div class="border border-2 bg-white rounded mt-4">
        <form class="chkpost" id="add_post"> 
    <!-- <textarea class="form-control border-0" name="about" placeholder="Share and Update..."></textarea> -->
         <div class="">
          <textarea id="emojionearea1" name="post"></textarea>        
        <!-- <label><span id="chars" class="lead">140</span></label> characters left -->
          <div class="d-flex">
          <i class="pl-2 fa fa-angle-left icontheme"></i>
          <ul class="d-flex list-unstyled px-3 bgimgs">
            <?php
              for($i=1; $i<=8; $i++){
                ?>
                   <li class="w-st">
                    <a href="javascript:void(0)" class="theme_">
                      <img class="w-100 border" src="<?=base_url('assets/webimg/theme/').$i.'.jpg'?>">
                    </a>
                    
                  </li>
                <?php
              }
            ?>
        
          </ul>
          </div>
         </div>
            <div class="row mx-0 my-2 withs" style="display: none">
              <div class="col-md-2 pr-0 text-center bgdefault">  
                <label for="tags">With</label>
              </div>
              <div class="col-md-10 px-0">
               <!--  <input class="form-control" type="text" name="tag" id="tags"> -->
                <select class="js-example-basic-multiple" name="friends[]" multiple="multiple">
                  <option value="Deepak">Deepak Nouliya</option>
                  <option value="Rahul">Rahul</option>
                  <option value="Ravish">Ravish</option>
                  <option value="Shivam">Shivam</option>
                  <option value="Shubham">Shubham</option>
                  <option value="Kaif">Kaif</option>
                </select>
              </div>
            </div>
            <div id="divOutside" class="divOutside">
            </div>
          <hr>
          <div class="row mx-0 my-2 fy">
            <div class="col-md-3 posttab">
              <a class="text-dark text-decoration-none tagfriend" href="javascript:void(0)"><i class="fa fa-user-o" aria-hidden="true"></i> Tag Friends</a>
            </div>
            <div class="col-md-4 posttab">
               <input type="file" id="img_video" class="d-none" name="files[]" multiple="">
               <label for="img_video"><i class="fa fa-picture-o" aria-hidden="true"></i> Add photo/videos</label>
            </div> 
            <div class="col-md-3 posttab">
              <img class="img-fluid" src="<?=base_url('assets/webimg/emoji.png')?>"> Feelings
            </div>  
            <div class="col-md-2 text-center">
              <img class="img-fluid" src="<?=base_url('assets/webimg/dots.png')?>">
            </div>      
          </div>
          <div class="form-check pl-5 py-2">
            <label class="form-check-label">
              <input type="checkbox" class="form-check-input mt-3" name="optradio" value="post"><i class="far fa-address-card"></i>
 News Feed
            </label>
          </div>
          <div class="form-check pl-5">
            <label class="form-check-label">
              <input type="checkbox" class="form-check-input mt-3" name="optradio" value="story"><img class="rounded-circle " src="<?=base_url('assets/webimg/face.png')?>" style="width: 15%"> Your Story
            </label>
          </div>
<div id="previewImage">
    </div>
          <div class="text-right pr-2">
             <input id="btn-Preview-Image"  class="btn btn-primary my-2 back_col border-0 px-4" type="submit" value="POST"/>
         <!--       <a id="btn-Convert-Html2Image" href="#">Download</a> -->
             <!-- <div id="match-button" >capture</div> -->
           <!--  <button type="submit" class="btn btn-primary my-2 back_col border-0 px-4" >POST</button> -->
          </div>
        </form>
      </div>
      <div id="postViews">
      </div>
</div>
    <!-- end center panel -->
     <!--right sidepanel -->
    <div class="col-md-3 border-left pt-3" style="background:#e2e2e2">
      <div class="bg-white">
        
        <nav>
          <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
              <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Intro</a>
              <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-active" role="tab" aria-controls="nav-profile" aria-selected="false">Friends</a>
              <a class="nav-item nav-link" id="nav-profile-photo" data-toggle="tab" href="#nav-photos" role="tab" aria-controls="nav-profile" aria-selected="false">Photos</a>
          </div>
        </nav>
        <div class="tab-content" id="nav-tabContent">
          <div class="tab-pane fade show active pt-4" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">    
            <ul class="list-group list-unstyle">
            	<li class="list-group-item">
	              	<div class="row">
		              	<div class="col-md-3 pr-0">
		                	<img src="assets/webimg/face.png" class="img-fluid">
		                </div>
		                <div class="col-md-9 p-1">
		                	<a href=""><span>Paul walker</span></a>
		            	</div>
               		</div>
              	</li>
              	<li class="list-group-item">
	              	<div class="row">
		              	<div class="col-md-3 pr-0">
		                	<img src="assets/webimg/face.png" class="img-fluid">
		                </div>
		                <div class="col-md-9 p-1">
		                	<a href=""><span>Paul walker</span></a>
		            	</div>
               		</div>
              	</li>
              	<li class="list-group-item">
	              	<div class="row">
		              	<div class="col-md-3 pr-0">
		                	<img src="assets/webimg/face.png" class="img-fluid">
		                </div>
		                <div class="col-md-9 p-1">
		                	<a href=""><span>Paul walker</span></a>
		            	</div>
               		</div>
              	</li>
            	<li class="list-group-item">
	              	<div class="row">
		              	<div class="col-md-3 pr-0">
		                	<img src="assets/webimg/face.png" class="img-fluid">
		                </div>
		                <div class="col-md-9 p-1">
		                	<a href=""><span>Paul walker</span></a>
		            	</div>
               		</div>
              	</li>
            </ul>
          </div>
          <div class="tab-pane fade pt-3" id="nav-active" role="tabpanel" aria-labelledby="nav-profile-tab">
           <!--  <h5>Diana Katherine <i class="fa fa-circle" aria-hidden="true" style="font-size: 12px"></i>
              </h5> -->

            <ul class="list-group">
              <?php
                foreach ($MyFriends as $frnd) {
                  # code...
                  ?>
                     <li class="list-group-item d-flex justify-content-between align-items-center">
                      <a href="javascript:void(0)" class="chatFriend" d-name="<?=$frnd->full_name?>" d-fNd="<?=$frnd->user_id?>">
                        <?=$frnd->full_name?>
                        <!-- <i class="fa fa-circle ml-auto" aria-hidden="true"></i> --> <i class="pl-3 fa fa-angle-right" aria-hidden="true"></i>
                      </a>
                      </li>
                  <?php
                }
              ?>
            </ul>
          </div>
          <div class="tab-pane fade pt-3" id="nav-photos" role="tabpanel" aria-labelledby="nav-profile-photo">
		    	<div class="card border-0">
		 			<div class="card-body p-1">
		        	 <h4>Photos</h4>
		        	 <hr>	
			          <div class="row page_st m-0">
					  <?php
						foreach($MyPosts as $post){
							if($post->post_type==1){
								?>
									<div class="col-md-4 mt-2  px-1">
										<img src="<?=base_url('assets/uploads/images/').$post->post_files?>" class="">
									</div>
								<?php
							}
						}
					  ?>
			          	
			          	
			          	
			          </div>
			        </div>
			        <div class="card-body p-1">
		        	 	<h4>Videos</h4>
		        	 	<hr>
			          <div class="row page_st m-0">
			          	<?php
						foreach($MyPosts as $post){
							if($post->post_type==2){
								?>
									<div class="col-md-4 mt-2  px-1">
										<video width="50" height="50" controls>
										  <source src="<?=base_url('assets/uploads/videos/').$post->post_files?>" type="video/mp4">
										  <source src="<?=base_url('assets/uploads/videos/').$post->post_files?>" type="video/ogg">
										  Your browser does not support the video tag.
										</video>
										
									</div>
								<?php
							}
						}
					  ?>
			          </div>
			        </div>
			    </div>
          </div>
        </div>
         <div class="trend bg-white p-3 mt-3">
          <h6>TRENDING</h6>
            <ul class="list-group">
              <?php
              foreach ($Trending as $trending) {
              ?>
              <li class="list-group-item d-flex justify-content-between align-items-center px-1">
                <img class="img-fluid w-25" src="<?=base_url()?>assets/img/Profile_Pic/<?=$trending->profile_picture?>">
                <small><?=$trending->post?></small>
                <i class="fa fa-angle-right pl-1" aria-hidden="true"></i>
              </li>
              <?php
              }
              ?>
            </ul>
        </div>
      </div>
    </div>
	</div>
</section>
<script type="text/javascript">
  var user_id=<?=$_SESSION['logged_in'][0]->user_id?>;
  getMyPost(user_id);
  var lastId;
  var startId;
  var initial=0;

  function getMyPost(user_id){
    console.log("Scroll On Work.");
    $.ajax({
            url:"<?=base_url()?>APIController/getAllMyPost",
             type:"post",
             data:{user_id:user_id},
            success:function(response)
            {
              console.log(response);
              response=JSON.parse(response);
              if(response.code==1){
				  console.log("Inside If Loop :" +response.data.length);
                for(let i=0; i<response.data.length; i++){
					console.log("Inside For Loop");
                  if(response.data[i].post_id < lastId || initial==0 ){
                    initial=1;
					console.log("Post Type: "+response.data[i].post_type);
                    if(response.data[i].post_type == 0){
						console.log("Text Post");
                    var post='<div class="card mt-4">'+
                          '<div class="card-header">'+
                          '<a class="font-weight-bold" href="<?=base_url('Profile/')?>'+response.data[i].user_id+'"><img class="rounded-circle postProfile-pic" src="<?=base_url()?>assets/img/Profile_Pic/'+response.data[i].profile_pic+'" width="30">'+response.data[i].posted_by+'</a>'+
                          '<a class="" href="#"><img class="img-fluid float-right pt-3" src="assets/webimg/dots.png"></a>'+
                          
                          '</div>'+
						              '<div class="card-body text-justify">'+
						              '<p>'+response.data[i].post+'</p>'+
							             '</div>'+
                          '<div class="total row px-2 text-right">'+
                        '</div>'+
                        '<div class="card-footer">'+
                          '<div class="row text-center">'+
                            '<div class="col-md-4 manage  py-2">'+
                              '<div class="btn-like" ><a href="javascript:void(0)" class="likePost" d-Post='+response.data[i].post_id+'><i class="fa fa-thumbs-o-up" aria-hidden="true"></i>Like</a> <span class="font-weight-bold"> '+response.data[i].total_likes+'</span></div>'+
                            '</div>'+
                            '<div class="col-md-4 manage  py-2">'+
                              '<div class="btn-comment"><a href=""><i class="fa fa-comment-o" aria-hidden="true"></i>Comment</a> <span class="font-weight-bold">'+response.data[i].total_comments+'</span></div>'+
                            '</div>'+
                            '<div class="col-md-4 manage  py-2">'+
                              '<div class="btn-share"><a href=""><i class="fa fa-share-square-o" aria-hidden="true"></i> Share</a><span class="font-weight-bold">'+response.data[i].total_share+'</span></div>'+
                            '</div>'+
                          '</div>'+
                        '</div>'+
                      '</div>';
                  }else if(response.data[i].post_type==1){
					  console.log("Image Post");
                    var post='<div class="card mt-4">'+
                          '<div class="card-header">'+
                          '<a class="font-weight-bold" href="<?=base_url('Profile/')?>'+response.data[i].user_id+'"><img class="rounded-circle  postProfile-pic" src="<?=base_url()?>assets/img/Profile_Pic/'+response.data[i].profile_pic+'" >'+response.data[i].posted_by+'</a>'+
                          '<a class="" href="#"><img class="img-fluid float-right pt-3" src="assets/webimg/dots.png"></a>'+
                         
                          '</div>'+
                          '<div class="card-body text-center">'+
						              '<p>'+response.data[i].post+'</p>'+
                          '<div class="post_img"><a class="" href="#"><img class="img img-fluid d-block" src="<?=base_url('assets/uploads/images/')?>'+response.data[i].post_files+'"></a>'+
                          '</div>'+
                          '</div>'+
                          '<div class="total row px-2 text-right">'+
                        '</div>'+
                        '<div class="card-footer">'+
                          '<div class="row text-center">'+
                            '<div class="col-md-4 manage  py-2">'+
                              '<div class="btn-like" ><a href="javascript:void(0)" class="likePost" d-Post='+response.data[i].post_id+'><i class="fa fa-thumbs-o-up" aria-hidden="true"></i>Like</a> <span class="font-weight-bold"> '+response.data[i].total_likes+'</span></div>'+
                            '</div>'+
                            '<div class="col-md-4 manage  py-2">'+
                              '<div class="btn-comment"><a href=""><i class="fa fa-comment-o" aria-hidden="true"></i>Comment</a> <span class="font-weight-bold">'+response.data[i].total_comments+'</span></div>'+
                            '</div>'+
                            '<div class="col-md-4 manage  py-2">'+
                              '<div class="btn-share"><a href=""><i class="fa fa-share-square-o" aria-hidden="true"></i> Share</a><span class="font-weight-bold">'+response.data[i].total_share+'</span></div>'+
                            '</div>'+
                          '</div>'+
                        '</div>'+
                      '</div>';
                  }else{
					  console.log("Video Post");
                    var post='<div class="card mt-4">'+
                          '<div class="card-header">'+
                          '<a class="font-weight-bold" href="<?=base_url('Profile/')?>'+response.data[i].user_id+'"><img class="rounded-circle postProfile-pic" src="<?=base_url()?>assets/img/Profile_Pic/'+response.data[i].profile_pic+'" >'+response.data[i].posted_by+'</a>'+
                          '<a class="" href="#"><img class="img-fluid float-right pt-3" src="assets/webimg/dots.png"></a>'+
                          
                          '</div>'+
                          '<div class="card-body">'+
						              '<p>'+response.data[i].post+'</p>'+
                          '<video controls class="w-100">'+
                          '<source src="<?=base_url()?>assets/uploads/videos/'+response.data[i].post_files+'" type="video/mp4">'+
                          'Your browser does not support the video tag.'+
                        '</video>'+
                        '</div> '+ 
                          '<div class="total row px-2 text-right">'+
                        '</div>'+
                        '<div class="card-footer">'+
                          '<div class="row text-center">'+
                            '<div class="col-md-4 manage  py-2">'+
                              '<div class="btn-like" ><a href="javascript:void(0)" class="likePost" d-Post='+response.data[i].post_id+'><i class="fa fa-thumbs-o-up" aria-hidden="true"></i>Like</a> <span class="font-weight-bold"> '+response.data[i].total_likes+'</span></div>'+
                            '</div>'+
                            '<div class="col-md-4 manage  py-2">'+
                              '<div class="btn-comment"><a href=""><i class="fa fa-comment-o" aria-hidden="true"></i>Comment</a> <span class="font-weight-bold">'+response.data[i].total_comments+'</span></div>'+
                            '</div>'+
                            '<div class="col-md-4 manage  py-2">'+
                              '<div class="btn-share"><a href=""><i class="fa fa-share-square-o" aria-hidden="true"></i> Share</a><span class="font-weight-bold">'+response.data[i].total_share+'</span></div>'+
                            '</div>'+
                          '</div>'+
                        '</div>'+
                      '</div>';
                  }
                   $('#postViews').append(post);
                   lastId=response.data[i].post_id;
                  }
                  
                }
                console.log("Last Post Id: "+lastId);
              }
            }
        });
  }
  $(document).on('click','.likePost',function(){
    var post_id=$(this).attr('d-Post');
    $.ajax({
      url:"<?=base_url('APIController/likeOrdislike')?>",
      type:"post",
      data:{post_id:post_id,to_do:'like'},
      success:function(response){
        response=JSON.parse(response);
        if(response.code==1){
          swal("Good", response.msg, "success");
        }else{
          swal("Oops...!", response.msg, "warning");
        }
      }
    });
    

  });
  $(window).scroll(function () {
    var scrollValue=Math.round($(window).scrollTop());
    var screenSize=Math.round($(window).height());
    var documentSize=Math.round($(document).height());
    var windowSection=documentSize - screenSize;
    console.log(windowSection-scrollValue+" dsf ");
    if(windowSection-scrollValue<=1){
      getMyPost(user_id);
    }
   

      });
 
</script>
<script>
  $("#add_post").submit(function(e){
        e.preventDefault();
        var formData= new FormData($(this)[0]);
        // formData.append('user_id',user_id);
        var ext_array=[];
        var selection = document.getElementById('img_video');
        for (var i=0; i<selection.files.length; i++) {
            var ext = selection.files[i].name.substr(-3);
            ext_array.push(ext);
        }
        if ($.inArray('mp4', ext_array) != -1 && ($.inArray('jpg', ext_array) != -1 || $.inArray('jpeg', ext_array) != -1 || $.inArray('gif', ext_array) != -1 || $.inArray('png', ext_array) != -1)) {
            alert('Video and Image');
            formData.append('post_type','3');
        }
        else if($.inArray('mp4', ext_array) != -1){
          // alert('video only');
          formData.append('post_type','2');
        }
        else if($.inArray('jpg', ext_array) != -1 || $.inArray('jpeg', ext_array) != -1 || $.inArray('gif', ext_array) != -1 || $.inArray('png', ext_array) != -1){
          formData.append('post_type','1');
        }
        else{
          formData.append('post_type','0');
          // alert('Text Only');
        }
         var bg=$('.emojionearea-editor').css('background');
          if(bg!='rgba(0, 0, 0, 0) none repeat scroll 0% 0% / auto padding-box border-box')
          { 
            var getCanvas;
             html2canvas($('#screenshot'),{
            allowTaint:false,
            useCORS :true
          }).then(function (canvas) {
          // global variable
            // var element = $("#screenshot");
            // html2canvas(element, {
            // onrendered: function (canvas) {
           // $("#previewImage").append(canvas);
            getCanvas = canvas;
            var imgageData = getCanvas.toDataURL("image/png");             
            formData.append('imgageData',imgageData);
            run();
           });
        }
          else
          {
              run();
          }
            function run()
            {
              var posted_on = [];
              $.each($("input[name='optradio']:checked"), function(){
                  posted_on.push($(this).val());
              });
              var myString= posted_on.join(",");
              var arr=myString.split(',');
              for(var i=0;i<arr.length;i++)
              {
                if(arr[i]=='story')
                {
                  story();
                }
                else if(arr[i]=='post' && arr[i+1]=='story')
                {
                  post();
                  story();
                  break;
                }
                else
                {
                  post();
                }
            }
            function story()
            {
                     $.ajax({
                        url:"<?=base_url()?>Home/addstories",
                         type:"post",
                         data:formData,
                         contentType:false,
                         processData:false,
                         cache:false,

                        success:function(response)
                        {
                          console.log(response);
                          response=JSON.parse(response);
                          if(response.status==1){
                            alert(response.msg);
                            // swal("Success", "Story Successfully", "success");
                            $("#add_post").trigger("reset");
                            location.reload();
                          }
                        }
                    });  
            }
            function post()
            {
                     $.ajax({
                        url:"<?=base_url()?>APIController/addPost",
                         type:"post",
                         data:formData,
                         contentType:false,
                         processData:false,
                         cache:false,

                        success:function(response)
                        {
                          console.log(response);
                          response=JSON.parse(response);
                          if(response.status==1){
                            alert(response.msg);
                            // swal("Success", "Story Successfully", "success");
                            $("#add_post").trigger("reset");
                            location.reload();
                          }
                        }
                  });  
              }
            }
          });


</script>
<script type="text/javascript">
  $(document).on('click','.likePost',function(){
    var ele=$(this);
    var post_id=ele.attr('d-Post');
    // var likes=ele.find('likeValue').html();
  // console.log(likes);
var like = ele.find("i").attr("class");
 var lcnt = $(this).parent().find('ul').find('.like_cont').html();
  var post_id=ele.attr('d-Post');
    $.ajax({
      url:"<?=base_url('APIController/likeOrdislike')?>",
      type:"post",
      data:{post_id:post_id,to_do:'like'},
      success:function(response){
        response=JSON.parse(response);
        if(response.code==1){
           if(like=='fa fa-heart-o'){
               ele.parent().find('ul').find('.like_cont').html(parseInt(lcnt)+1);
               ele.find("i").attr("class","fa fa-heart");
            }else{
              ele.find("i").attr("class","fa fa-heart-o");
               ele.parent().find('ul').find('.like_cont').html(parseInt(lcnt)-1);
            }
      //    swal("Good", response.msg, "success");
        }else{
        //  swal("Oops...!", response.msg, "warning");
        }
      }
    })
  });
</script>
<script type="text/javascript">
  $(document).on('click','.theme_',function()
  {
     var imgs=$(this).find('img').attr('src');
      //console.log(imgs);
      $('.emojionearea-editor').css('background','url('+imgs+')');
      $('.emojionearea-editor').css("min-height","9em");
      $('.emojionearea-editor').css("text-align","center");
      $('.emojionearea-editor').css("font-size","28px");
      $('.emojionearea-editor').css("background-size","cover");
      $('.emojionearea-editor').css("color","black");
      $('.emojionearea-editor').attr("id","screenshot");
  })
</script>
<script>

  $(document).ready(function() {
        $("#emojionearea1").emojioneArea({
            pickerPosition: "right",
            tonesStyle: "bullet",
            events: {
            keyup: function (editor, event) {
              countChar(this);
                console.log(editor.html());
                console.log(this.getText());
            }
          }
        });
        $('#divOutside').click(function () {
          $('.emojionearea-button').click()
        })        
    });
   function countChar(val) {
            var len = val.getText().length;
            if (len >= 140) {
                 /*  val.value = val.content.substring(0, 140) */;
                 $('#chars').text(0); 
                    $('.emojionearea-editor').css('background','transparent');
                    $('.emojionearea-editor').css("min-height","8em");
                    $('.emojionearea-editor').css("max-height","15em");
                    $('.emojionearea-editor').css("font-size","inherit");
            } 
            else 
            {
                // $('#chars').text(140 - len);
            }
        }
</script>
<script>
  $(document).on('click','.tagfriend',function(){
   // $('.withs').css('display','flex');
   $('.withs').toggleClass ('expanded');

  });
</script>
<script>
 $(document).ready(function() {
    $('.js-example-basic-multiple').select2();
});
  $(document).on('click','#aad',function(e){
    e.preventDefault();
    console.log($('#emojionearea1').val());
  });

  $(function () {
    $('.icontheme').click (function () {
        $(this).toggleClass ('expanded');
        $('.bgimgs').toggleClass ('expanded');
    });
});
  $(document).ready(function() {
        $("#emojionearea1").emojioneArea({
        
            pickerPosition: "right",
            tonesStyle: "bullet",
            events: {
                keyup: function (editor, event) {
                    console.log(editor.html());
                    console.log(this.getText());
                }
            }
        });

        $('#divOutside').click(function () {
                    $('.emojionearea-button').click()
                })        
    });
</script>
