
<div class="container">
	<div class="row mt-3">
		<div class="col-md-6">
			<span class="notifi">Your Notification</span>
		</div>
		<div class="col-md-6">
			<a href="">Notification Setting</a>
		</div>
	</div>
	<hr>
	<!-- <span class="text-secondary ">Get notifications via:</span><a href="">Text message</a> -->
</div>
<div class="container mt-5">
	<div class="row">
		<div class="col">
			<ul>
				<?php
				foreach($myNotifications as $notification){
					//print_r($notification->notification_);
					?>
						<div class="row my-1">
							<div class="col-md-1">
								<img class="img rounded-pill" src="image/p5.jpg" onerror="this.src='<?=base_url()?>assets/img/Profile_Pic/default.png';" width="35" height="35">
							</div>
							<div class="col-md-10">
							<a href=""class="text-dark"><strong><?=$notification->full_name ?></strong> <?=$notification->notification_?></a> 
							</div>
						</div>
					<?php }
				?>
			</ul>
		</div>
	</div>
</div>
<script>
	$(window).on('load',function(){
		$.ajax({
			url:'<?=base_url('Test/updateNotificationStatus')?>',
			type:"post",
			success:function(response){

			}
		});
	});
</script>