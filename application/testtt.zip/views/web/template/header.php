  <!DOCTYPE html>
<html lang="en">
<head>
  	<title>Lanecrowd</title>
  	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

  	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">
  	<!-- Toggle cdn https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css-->

  	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.css">
  	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.min.js"></script>
  	<!-- Toggle cdn -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>
  	<link href="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/css/bootstrap4-toggle.min.css" rel="stylesheet">
	<script src="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/js/bootstrap4-toggle.min.js"></script>
	<script type="text/javascript" src="<?=base_url('assets/js/crousel.js')?>"></script>
	<!-- Toggle cdn -->
   <!-- emoji link -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/emojionearea/3.4.1/emojionearea.min.js"></script>
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/emojionearea/3.4.1/emojionearea.css">
  <!-- end emoji link -->      
  <!-- Multiple select link -->  
  <link href="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/css/select2.min.css" rel="stylesheet" />
  <script src="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/js/select2.min.js"></script>
       <!-- end Multiple select link -->  
   <link rel="stylesheet" type="text/css" href="<?=base_url('assets/css/home.css')?>">
    <link rel="stylesheet" type="text/css" href="https://onesignal.github.io/emoji-picker/lib/css/emoji.css">
    <script src="https://onesignal.github.io/emoji-picker/lib/js/config.js"></script>
    <script src="https://onesignal.github.io/emoji-picker/lib/js/util.js"></script>
    <script src="https://onesignal.github.io/emoji-picker/lib/js/jquery.emojiarea.js"></script>
   <script src="https://onesignal.github.io/emoji-picker/lib/js/emoji-picker.js"></script>

   <link href="https://fonts.googleapis.com/css?family=Crimson+Text&display=swap" rel="stylesheet"> 

</head>
<body>
	<style type="text/css">


.full-width {
  width: 100%;
  height: 100vh;
  display: flex;
}
.full-width .justify-content-center {
  display: flex;
  align-self: center;
  width: 100%;
}
.full-width .lead.emoji-picker-container {
  width: 300px;
  display: block;
}
.full-width .lead.emoji-picker-container input {
  width: 100%;
  height: 50px;
}

.emoji-wysiwyg-editor{
  height: auto !important;
}

body{
  font-family: 'Roboto,-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI","Helvetica Neue",Arial,sans-serif';
}
.badge {
      position: absolute;
    top: -3px;
   
    padding: 4px 4px;
    border-radius: 50%;
    background: red;
    color: white;
  }
  .badge_rt_notify{
    right: 19px;
    
  }
  .badge_rt{
     right: 11px;
    
  }
  a:hover{
    text-decoration: none !important;
  }
	.bgb
    {
      background:#231F20;
      /*#ff441a*/
    }
    input {
  outline: none;
}
input[type=search] {
  -webkit-appearance: textfield;
  -webkit-box-sizing: content-box;
  font-family: inherit;
  font-size: 100%;
}
input::-webkit-search-decoration,
input::-webkit-search-cancel-button {
  display: none; 
}


input[type=search] {
  background: #ededed url(https://static.tumblr.com/ftv85bp/MIXmud4tx/search-icon.png) no-repeat 9px center;
  border: solid 1px #ccc;
  padding: 3px 6px 5px 34px;
  width: 100px;
  
  -webkit-border-radius: 10em;
  -moz-border-radius: 10em;
  border-radius: 10em;
  
  -webkit-transition: all .5s;
  -moz-transition: all .5s;
  transition: all .5s;
}
input[type=search]:focus {
  width: 230px;
  background-color: #fff;

  
  -webkit-box-shadow: 0 0 5px rgba(109,207,246,.5);
  -moz-box-shadow: 0 0 5px rgba(109,207,246,.5);
  box-shadow: 0 0 5px rgba(109,207,246,.5);
}


input:-moz-placeholder {
  color: #999;
}
input::-webkit-input-placeholder {
  color: #999;
}



.hintDiv{
  position: sticky;
  background: white;
  border: 1px solid red;
  top: 63px;
  left: 392px;
  z-index: 122;
  width: 274px;
  height: auto;
  /* min-height: 100px; */
  max-height: 220px;
  overflow-y: scroll;
}
	</style>
  <?php
    $session=$this->session->userdata('logged_in');
    $user_Id=$session[0]->user_id;
    // Get MY Notifications
    $notif=array("notify_to"=>$user_Id,"status_"=>0);
    $this->db->where($notif);
    $this->db->join('users','users.user_id=notifications_.notify_by');
    $myNotifications=$this->db->get('notifications_')->result();
    //Get My Messages
    $this->db->join('users','users.user_id=messages_.sent_by');
    $notif=array("sent_to"=>$user_Id,"read_status "=>0);
    $this->db->where($notif);
    $myMessages=$this->db->get('messages_')->result();
  // print_r($myMessages);
    // $myMessages=

    
  ?>
  <style>
  .notfication_text{
    font-size:13px;
    font-family: 'Crimson Text', serif;
  }
  </style>
  <script>
    $(document).on('click',"#notific",function(){
      $('.notifications_box').toggle();
    });
    $(document).on('click',"#openMessage",function(){
      $('.message_box').toggle();
    });
    $(document).on('keyup','#search-frnd',function(){
      var key_=$(this).val();
      if(key_!=""){
        $('.hintDiv').show();
        $.ajax({
          url:"<?=base_url('Test/searchFriend')?>",
          type:"post",
          data:{key:key_},
          success:function(res){
            console.log(res);
            res=JSON.parse(res);
            $('#srchFndLs').empty();
            if(res.code==1 && res.data.length!=0){
              for(let i=0; i<res.data.length; i++){
                var li='';
                li+='<li ><a class="d-flex" href="<?=base_url('Profile/')?>'+res.data[i].user_id+'"><figure ><img style="border-radius:50%" src="<?=base_url('assets/img/Profile_Pic/')?>'+res.data[i].profile_picture +'" width="35px" height="35px"></figure><span> '+res.data[i].full_name+' </span></a></li>';
                $('#srchFndLs').append(li);
              }
            }
          }
        });
      }else{
        $('.hintDiv').hide();
      }
      console.log(' Key : '+key_);
      
    });
  </script>
    <div class="row hintDiv p-3" style="display:none">
      <div class="col">
          <ul id="srchFndLs" >
            
          </ul>
      </div>
    </div>
<section class="container-fluid bgb fixed-top">
    <nav class="navbar navbar-expand-md navbar-dark bgb container" >
      	<a class="navbar-brand" href=<?=base_url('Home')?>>Lanecrowd</a>
      	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
        	<span class="navbar-toggler-icon"></span>
      	</button>
      	<div class="collapse navbar-collapse" id="navbarTogglerDemo02">
    	    <form class="form-inline my-2 my-lg-0"> 
    	        <input type="search" placeholder="Search" name="" id="search-frnd">
    	    </form>

          <!-- test -->
        
          <!-- test end -->
    	    <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
           
      	    	<li class="nav-item home">
      				<a class="nav-link p-1 text-center" href="<?=base_url('Home')?>"><span><i class="fa fa-home" aria-hidden="true"></i></span><div class="mt-n2">Home</div></a>
      			</li>
          		<li class="nav-item profile">
    	        	<a class="nav-link p-1 text-center" href="<?=base_url('Profile')?>"><span><i class="fa fa-user" aria-hidden="true"></i></span><div class="mt-n2">Profile</div></a>
          		</li>
          		<li class="nav-item trending">
    	        	<a class="nav-link p-1 text-center" href="<?=base_url('Profile')?>"><span><i class="fa fa-bolt" aria-hidden="true"></i><span class="badge badge_rt">22</span></span><div class="mt-n2"> Trending</div></a>
          		</li>
    			<li class="nav-item messenger">
    				<a class="nav-link p-1 text-center " id="openMessage" href="javascript:void(0)"><span><i class="fa fa-comments-o" aria-hidden="true" title="Message"></i><span class="badge badge_rt_notify"><?=count($myMessages)?></span></span><div class="mt-n2">Messages</div></a>
    			  <ul class="dropdown-menu notify-drop p-3 message_box" style="width: 348px; height:348px; overflow-y:scroll">
              <div class="notify-drop-title">
                <div class="row">
                  <div class="col-md-6 col-sm-6 col-xs-6"><a href="<?=base_url('Message')?>">Messages (<b><?=count($myMessages)?></b>)</a></div>
                  <div class="col-md-6 col-sm-6 col-xs-6 text-right"><a href="" class="rIcon allRead" data-tooltip="tooltip" data-placement="bottom" title="close"><i class="fa fa-dot-circle-o"></i></a></div>
                </div>
              </div>
              <!-- end notify title -->
              <!-- notify content -->
              <div class="drop-content">
               
                <?php
                  foreach($myMessages as $msgs){
                      ?>
                        <li>
                          <div class="row p-1">
                      
                              <div class="col-md-2">
                                <img src="" onerror="this.src='<?=base_url()?>assets/img/Profile_Pic/default.png';" alt="" style="border-radius:50%" width="100%">
                              </div>
                              <div class="col-md-10">
                                <p class="notfication_text"><span><strong><?=$msgs->full_name?></strong> : </span><?=$msgs->message_?> <span class="time float-right">1 Seconds Ago</span></p>
                              </div>
                          </div>
                          <!-- <hr> -->
                        </li>
                      <?php
                  }
                ?>
              </div>
              <div class="notify-drop-footer text-center">
                <a href=""><i class="fa fa-eye"></i> Read More</a>
              </div>
            </ul>
          </li>		
      
           <li class="nav-item messenger ">
            <a class="nav-link p-1 text-center"  id="notific" href="javascript:void(0)"><span><i class="fa fa-bell-o" aria-hidden="true" title="Notification"></i><span class="badge badge_rt_notify"><?=count($myNotifications)?></span></span><div class="mt-n2">Notification</div></a>
            <ul class="dropdown-menu notify-drop p-3 notifications_box" style="width: 348px; height:348px">
              <div class="notify-drop-title">
                <div class="row">
                  <div class="col-md-6 col-sm-6 col-xs-6"><a href="<?=base_url('Test/notifications')?>">Notifications (<b><?=count($myNotifications)?></b>)</a></div>
                  <div class="col-md-6 col-sm-6 col-xs-6 text-right"><a href="" class="rIcon allRead" data-tooltip="tooltip" data-placement="bottom" title="close"><i class="fa fa-dot-circle-o"></i></a></div>
                </div>
              </div>
              <!-- end notify title -->
              <!-- notify content -->
              <div class="drop-content">
                <?php
                  foreach($myNotifications as $notifications){
                    // print_r($notifications);
                    ?>
                      <li>
                        <div class="row p-3">
                    
                            <div class="col-md-2">
                              <img src="<?=base_url('assets/img/Profile_Pic/').$notifications->profile_picture?>" onerror="this.src='<?=base_url()?>assets/img/Profile_Pic/default.png';" alt="" style="border-radius:50%" width="100%">
                            </div>
                            <div class="col-md-10">
                              <p class="notfication_text"><?=$notifications->notification_?><span class="time float-right"> 1 Seconds Ago</span></p>
                            </div>
                        
                        </div>
                        <hr>
                      </li>
                    <?php
                  }
                ?>
                
                <!-- <li>
                  <div class="row p-3">
               
                      <div class="col-md-2">
                        <img src="" onerror="this.src='<?=base_url()?>assets/img/Profile_Pic/default.png';" alt="" style="border-radius:50%" width="100%">
                      </div>
                      <div class="col-md-10">
                        <p class="notfication_text">Lorem ipsum sit dolor amet consilium. <span class="time">1 Seconds Ago</span></p>
                      </div>
                  
                  </div>
                  <hr>
                </li> -->
                <!-- <li>
                  <div class="row p-3">
               
                      <div class="col-md-2">
                        <img src="" onerror="this.src='<?=base_url()?>assets/img/Profile_Pic/default.png';" alt="" style="border-radius:50%" width="100%">
                      </div>
                      <div class="col-md-10">
                        <p class="notfication_text">Lorem ipsum sit dolor amet consilium. <span class="time">1 Seconds Ago</span></p>
                      </div>
                  
                  </div>
                  <hr>
                </li> -->
              </div>
              <div class="notify-drop-footer text-center">
                <a href=""><i class="fa fa-eye"></i> Read More</a>
              </div>
            </ul>
          </li> 
         <!--  <li class="nav-item messenger">
              <a class="nav-link" href="<?=base_url('Message')?>"><span><i class="fa fa-bolt" aria-hidden="true"></i></span><div class="mt-n2">Notification</div></a>
          </li>  -->
    			<li class="nav-item">
    				<a class="nav-link p-1 text-center" href="<?=base_url('Login/logout')?>"><span><i class="fa fa-power-off" aria-hidden="true"></i></span><div class="mt-n2">Logout</div></a>
    			</li>
    	    </ul>
      	</div>
    </nav>
</section>
<style>

</style>