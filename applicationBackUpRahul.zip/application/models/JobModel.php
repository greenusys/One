<?php 

class JobModel extends CI_Model{ 
	

}

?>