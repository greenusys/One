<?php
   include'header.php';
   ?>
<?php
   include'sidebar.php';
   ?>
<div class="col-md-8 p-2">
   <span class="text-secondary font-weight-bold">CONTACT INFORMATION</span>
   <hr>
   <div class="row ">
      <div class="col-md-3">
         <span class="text-secondary">Facebook </span>
      </div>
      <br><br>
      <div class="col-md-5">
         <a href="" class="text-dark font-weight-bold">http://facebook.com</a>
      </div>
   </div>
   <br>
   <span class="text-secondary font-weight-bold">WEBSITES AND SOCIAL LINKS
   </span>
   <hr>
   <div class="row ">
      <div class="col-md-3">
         <span class="text-secondary">Websites </span>
      </div>
      <div class="col-md-5">
         <a href="" class="text-dark font-weight-bold">http://abc.com</a>
      </div>
   </div>
   <br><BR>
   <span class="text-secondary font-weight-bold">BASIC INFORMATION
   </span>
   <hr>
   <br>
   <div class="row ">
      <div class="col-md-3">
         <span class="text-secondary">Gender </span><br>
         <hr>
         <span class="text-secondary">Languages
         </span><br>
         <hr>
         <span class="text-secondary">Religious Views
         </span><br>
         <hr>
         <span class="text-secondary">Politicle view </span><br>
         <hr>
      </div>
      <div class="col-md-5">
         <span class="font-weight-bold">Female</span><br>
         <hr>
         <a href="" class="text-dark font-weight-bold">
            Hindi,English</a><br>
            <hr>
         <a href="" class="text-dark font-weight-bold">Hindu</a><br>
         <hr>
         <a href="" class="text-dark font-weight-bold">Other</a><br>
         <hr>
      </div>
   </div>
</div>
