<?php
include'header.php';
?>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="jumbotron">
			<h4>
				Terms and Conditions
			</h4>
			<p class="para text-secondary">
			The following terms and conditions apply to all services, including website development and design services, (the Services) provided by Wombat Creative Limited (Wombat Creative) to the Client, in conjunction with any relevant quotation provided to the Client by Wombat Creative (Terms), unless otherwise agreed in writing. Acceptance of a quote, purchase and/or use of the Services shall be considered acceptance of the Terms..</p><br>
			<h4>
				1. Who can use Facebook
			</h4>
				<p class="para text-secondary">
					When people stand behind their opinions and actions, our community is safer and more accountable. For this reason, you must:
				</p>
				<div class="para ul">
				<li class="text-secondary">
					use the same name that you use in everyday life;
				</li>
					<li class="text-secondary">
						provide accurate information about yourself;
					</li>
				<li class="text-secondary">
					create only one account (your own) and use your timeline for personal purposes; and
				</li>
					<li class="text-secondary">
						not share your password, give access to your Facebook account to others or transfer your account to anyone else (without our permission).
					</li>
				</div>
				<h4>
					2. Use and develop advanced technologies to provide safe and functional services for everyone:
				</h4>
				<p class="para text-secondary">
					We use and develop advanced technologies such as artificial intelligence, machine learning systems and augmented reality so that people can use our Products safely regardless of physical ability or geographic location. For example, technology such as this helps people who have visual impairments understand what or who is in photos or videos shared on Facebook or Instagram. We also build sophisticated network and communication technology to help more people connect to the Internet in areas with limited access. And we develop automated systems to improve our ability to detect and remove abusive and dangerous activity that may harm our community and the integrity of our Products.
				</p>
				<h4>
					3. Enable global access to our services:
				</h4>
				<p class="para text-secondary">
					o operate our global service, we need to store and distribute content and data in our data centres and systems around the world, including outside your country of residence. This infrastructure may be operated or controlled by Facebook, Inc., Facebook Ireland Limited or its affiliates.
				</p>
				<h4>
					4. What you can share and do on Facebook
				</h4>
			<p class="para text-secondary">
				We want people to use Facebook to express themselves and to share content that is important to them, but not at the expense of the safety and well-being of others or the integrity of our community. You therefore agree not to engage in the conduct described below (or to facilitate or support others in doing so):
			</p>


		</div>
	</div>
</div>
</div>
