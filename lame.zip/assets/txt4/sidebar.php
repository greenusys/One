<div class=" container">
    <div class="row bg-white">
        <div class=" col-md-12 p-0">
            <div class="b2">
            </div>
        </div>
        <div class="col-md-2">
             <img class=" P1 rounded-pill img"width="160px" height="160px" src="image/p5.jpg">
             <h4 class="profilename">Diana</h4>
        </div>
        <div class="col-md-10">
            <div class="ul list-unstyled d-flex">
                <li class="p text-secondary font-weight-bold"><a href="aboutus.php" class="text-dark">About</a></li>
                <li class="p font-weight-bold">Friend</li>
                <li class="p font-weight-bold">Timeline</li>
                <li class="p font-weight-bold">Home</li>
            </div>
        </div>
    </div>
    <hr>
    <div class="card row">
        <div class="card-header">
           <h3> <i class="fa fa-user"> About</i></h3>
        </div>
        <div class="card-body row">
            <div class="col-md-4 p-0 border-right">       
                <ul class="list-group list-unstyled">
                    <li class="list-group-item active"><a href="" class="text-dark">Ovrerview</a></li>
                    <li class="list-group-item"><a href="workplace.php" class="text-dark">Work and Education</a></li>
                    <li class="list-group-item"><a href="place.php" class="text-dark">Places you've Lived</a></li>
                    <li class="list-group-item"><a href="contact.php" class="text-dark">Contact & Basic Info</a></li>
                    <li class="list-group-item"><a href="member.php" class="text-dark">Family & Relationship</a></li> 
                     <li class="list-group-item"><a href="dianaprofile.php" class="text-dark">Detail about Diana </a></li> 
                       <li class="list-group-item"><a href="lifeevent.php" class="text-dark">Life Event </a></li>         
                </ul>
            </div>
          
