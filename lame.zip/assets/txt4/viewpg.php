<?php
   include'header.php';
   ?> 		
   <nav class="tex navbar navbar-expand-sm bg-light">
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="text-dark ml-5 nav-link" href="index.php">Page</a>
    </li>
    <li class="text-dark nav-item">
      <a class="text-dark mx-5 nav-link" href="">Inbox</a>
    </li>
    <li class="nav-item">
      <a class="text-dark ml-5 nav-link" href="">Managed Job</a>
    </li>
     <li class="nav-item">
      <a class="text-dark ml-5 nav-link" href="#">Notification</a>
    </li>
     <li class="nav-item">
      <a class="text-dark ml-5 nav-link" href="#">Publishing Tool</a>
    </li>
     <li class="nav-item">
      <a class="text-dark ml-5 nav-link" href="#">More</a>
    </li>
     <li class="nav-item">
      <a class="text-dark ml-5 nav-link" href="#">Edit profile info</a>
    </li>
     <li class="nav-item">
      <a class="text-dark ml-5 nav-link" href="#">Help</a>
    </li>
  </ul>
</nav>
<div class="container mt-5">
  <div class="row">
    <div class="col-md-2">
       <img class=" rounded-pill img"width="150px" height="150px" src="image/p5.jpg">
       <ul class="list-unstyled">
        <li><a href="" class="text-dark">create username</a></li>
         <li><a href="index.php"class="text-dark">Home</a></li>
          <li><a href="services.php" class="text-dark">Services</a></li>
            <li><a href="review.php" class="text-dark">Review</a></li>
             <li><a href="aboutus.php" class="text-dark">About</a></li>
            <li><a href="job.php" class="text-dark">Jobs</a></li>
            <li><a href="event.php" class="text-dark">Event</a></li>
            <button class="btn btn-primary">promote</button>
            </ul>
    </div>
    <div class="col-md-9">
       <img class=" img"width="800px" height="300px" src="image/view.jpg">
       <ul class="list-unstyled d-flex">
      <li> <button type="button" class="default">Like <i class="fa fa-thumbs-o-up"></i></button></li>
       <li><button type="button" class="default">Following <i class="fa fa-wifi"></i></button></li>
         <li><button type="button" class="default">Share <i class="fa fa-share"></i></button></li>
         <div class="col-md-3">
          <button class=" btn btn-primary pull-right">Send Message <i class="fa fa-pencil"></i></button>
         </div>
        </ul>
  