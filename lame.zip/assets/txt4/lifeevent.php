<?php
   include'header.php';
   include'sidebar.php';
   ?>
<div class="col-md-8 p-2">
   <span class="text-secondary font-weight-bold">Life Events</span>
   <hr>
   <div class="row">
      <div class="col-md-2">
         <span class="text-secondary">2018 </span>
      </div>
      <div class="col-md-8">
         <a href=""class=" text-secondary fa fa-home"><span class="ml-2 place"> Moved to Delhi</span>.</a><br>
         <a href=""class=" text-secondary fa fa-home"><span class="ml-2 place"> Banglore</span></a><br>
         <a href="" class=" text-secondary fa fa-briefcase"><span class="ml-2 place">Left Job Future Group</span></a><br>
         <hr>
      </div>
   </div>
   <div class="row">
      <div class="col-md-2">
         <span class="text-secondary">2019 </span>
      </div>
        <div class="col-md-8">
         <a href=""class=" text-secondary fa fa-home"><span class="ml-2 place"> Dehradun</span>.</a><br>
         <a href=""class=" text-secondary fa fa-home"><span class="ml-2 place"> Banglore</span></a><br>
         <a href="" class=" text-secondary fa fa-briefcase"><span class="ml-2 place">Started Job At L & T Financial Service</span>
         	<hr></a><br>
         <hr>
      </div>
   </div>
   <div class="row">
      <div class="col-md-2">
         <span class="text-secondary">2017 </span>
      </div>
      <div class="col-md-8">
         <a href=""class=" text-secondary fa fa-home"><span class="ml-2 place">Moved to Dehradun</span>.</a><br>
         <a href=""class=" text-secondary fa fa-home"><span class="ml-2 place"> Banglore</span></a><br>
         <a href="" class=" text-secondary fa fa-briefcase"><span class="ml-2 place">Started Job At Hotel Taj</span></a><br>
         <hr>
      </div>
   </div>
</div>