
<!DOCTYPE html>
<html lang="en">
   <head>
      <title>Bootstrap Example</title>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="css/style.css">
         <style>
.dropbtn {
  padding: 16px;
  font-size: 16px;
  border: none;
  cursor: pointer;
}


.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  overflow: auto;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown a:hover {background-color: #ddd;}

.show {display: block;}
</style>

   </head>
   <body style="background-color: #edf0f5;font-family:Helvetica, Arial, sans-serif">
      <div class=" container-fluid">
         <div class="row">
            <div class="pl-0 pr-0 col-md-12">
               <nav class="head navbar navbar-expand-md">
                  <a class="ml-5 text-white navbar-brand font-weight-bold" href="#">Logo</a>
                  <form action="/action_page.php">
                     <input type="text" placeholder="Search.." name="search">
                     <button type="submit"><i class="fa fa-search"></i></button>
                  </form>
                  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                  <span class="navbar-toggler-icon"></span>
                  </button>
                  <div class="collapse navbar-collapse" id="collapsibleNavbar">
                     <ul class="navbar-nav">
                        <li class="nav-item">
                           <a class="pl-5 text-white nav-link font-weight-bold" href="aboutus.php">About Us</a>
                        </li>
                        <li class="nav-item">
                           <a class="pl-5 text-white nav-link font-weight-bold" href="term&condition.php">Term & Condition</a>
                        </li>
                        <li class="nav-item">
                           <a class="pl-5 text-white font-weight-bold nav-link" href="privacypolicy.php">Privacy & Policy</a>
                        </li>
                  


<div class="pl-5 dropdown">
  <button onclick="myFunction()" class="dropbtn"><i class="fa fa-bell " aria-hidden="true"></i></button>
  <div id="myDropdown" class="dropdown-content">
    <a href="#home">Notification</a>
    <hr>
    <a href="#"><img class="img rounded-pill" src="image/p5.jpg" width="30" height="30">Richa likes your posts</a>
     <a href="#"><img class="img rounded-pill" src="image/p5.jpg" width="30" height="30">Richa likes your posts</a>
      <a href="#"><img class="img rounded-pill" src="image/p5.jpg" width="30" height="30">Richa likes your posts</a>
       <a href="#"><img class="img rounded-pill" src="image/p5.jpg" width="30" height="30">Richa likes your posts</a>
       <a href="notification.php">Show all notifications</a>
       <hr>
   </div>
</div>

<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>

                        
                     </ul>
                  </div>
               </nav>
            </div>
         </div>
      </div>
   </body>
</html>