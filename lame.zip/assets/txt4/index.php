<?php
   include'viewpg.php';
   ?>
<div class="row">
<div class="col-md-9">
  <div class="bg-white card-header d-flex ">
    <div class="col-md-2">
    <span >Create</span>
    </div>
    <div class="col-md-2">
      <i class="fa fa-camera"><a href="" class="text-secondary"> Live</a></i>
    </div>
    <div class="col-md-2">
    <i class="fa fa-calendar"><a href=""class="text-secondary" > Event</a></i>
    </div>
    <div class="col-md-2">
      <i class="fa fa-percent"><a href=""class="text-secondary" > Offer </a></i>
    </div>
    <div class="col-md-2">
      <i class="fa fa-briefcase"><a href=""class="text-secondary" > Job </a></i>
    </div>
    </div>
    <div class="card mt-2">
      <div class="card-header">
        <span class="text-secondary">create post</span>
      </div>
      <div class="card-body">
        <div class="row d-flex">
          <div class="col-md-2">
        <img class="img rounded-pill"src="image/p5.jpg"width="50px" height="50px">
          </div>
          <div class="col-md-3">
        <span class="text-secondary">Write a Post....</span>
          </div>
        </div>
      </div>
      <hr>
       <div class="row">
        <div class="col-md-3">
          <i class="aw1 fa fa-file-image-o"> <a href="" class="text-secondary">photos/video</a></i>
        </div>
          <div class="col-md-3">
            <i class="a9 fa fa-map-marker"> <a href=""class="text-secondary"> Checkin</a></i>
        </div>
          <div class="col-md-3">
            <i class="aw fa fa-smile-o"> <a href="" class="text-secondary"> Feeling/Activity</a></i>
        </div>
          <div class="col-md-3">
            <i class="text-secondary fa fa-ellipsis-v"> </i>
        </div>
        </div> 
    </div>
    <div class="card mt-2">
      <div class="row ">
      <div class="col-md-6">
        <div class="cd1 my-2 mx-2 mr-2 mt-2 card text-center" >
          <a href="" class="text-dark font-weight-bold mt-5">Get more page like</a>
          <a href="" class="text-secondary text-center">Help people find and like your page</a>
        </div>
      </div>
       <div class="col-md-6">
         <div class=" cd1 my-2 mx-2 mr-2 mt-2 card text-center" >
          <a href="" class="text-dark font-weight-bold mt-5">Get more page like</a>
          <a href="" class="text-secondary text-center">Help people find and like your page</a>
        </div>
      </div>
    </div>
    </div>
    <div class="card">
      <div class="card-body">
        <h5 class="font-weight-bold">Photos</h5>
        <hr>
        <img class="img" src="image/view.jpg" width="580px"height="400px"
        >
      </div>
    </div>
     <div class="card">
      <div class="card-body">
        <h5 class="font-weight-bold">Videos</h5>
        <hr>
        <video width="580px" height="400px" controls>
          <source src="movie.mp4" type="video/mp4">
          Your browser does not support the video tag.
        </video>
       
      </div>
    </div>
     <div class="card mt-2">
      <div class="card-body">
        <h5 class="font-weight-bold">post</h5>
        <hr>
        <div class="row">
          <div class="col-md-2">
            <img class="img rounded-pill" src="image/p5.jpg"widtgh="40px" height="40px">
          </div>
          <div class="col-md-4 d-flex">
            <span >published by Diana<i class="fa fa-globe">july 21 2018</i></span>
            <hr>
          </div>
            <img class="img"src="image/view.jpg"width="585" height="400px">
          
        </div>
        <div class="card">
          <div class="card-body">
              <div class="text-right mt-2">
                  <button class="btn btn-primary">boost post</button>
            </div>
          </div>
        </div>
        <div class="card">
          <div class="card-body">
            <i class="text-primary fa fa-thumbs-o-up"> <a href="" class="text-center ">you and 5 other like this</a></i>
          </div>
        </div>
      </div>
      </div>
  </div>
  <div class="col-md-3">
         <div class="bg-white card-header ">
            <span class="text-secondary">No Rating Yet</span>
            <hr>
            <img class="img"src="image/view.jpg"width="150" height="100">
         <span class="text-secondary">our story</span><br>
         <a href="" class="text-dark">Finish your story to all people more about your business</a>
         </div>
        
          <ul class="card list-unstyled mt-2">
            <li><i class="text-secondary fa fa-users"><a href="" class="text-dark"> 115 followers</a></i></li>
               <hr>
               <li><i class="text-secondary fa fa-signal"><a href=""class="text-dark"> 2 post reach this week</a></i></li>
               <hr>
               <li><img class="img rounded-pill"src="image/p5.jpg"width="50" height="50"><a href="" class="text-dark"> 117 people like this </a></li>
          </ul>
          <div class="card ">
            <div class="card-body">
            <h5 class="ml-2 mt-2 font-weight-bold">Community</h5>
            <hr>
            <i class="text-secondary fa fa-users"> <span class="text-secondary">diana and 5 other like </span></i>
            <ul class="list-unstyled d-flex mt-2">
              <li><img class="img rounded-pill" src="image/p5.jpg"width="50px" height="50"></li>
                <li><img class="img rounded-pill" src="image/p5.jpg"width="50px" height="50"></li>
                  <li><img class="img rounded-pill" src="image/p5.jpg"width="50px" height="50"></li>

            </ul>
             <button class="bt btn btn">invite friend</button>
             <ul class="list-unstyled d-flex">
              <li><i class="mt-2 fa fa-thumbs-o-up"></i><span class="text-secondary">112 people like this</span></li>
             </ul>
          </div>
        </div>
          <div class="card">
            <div class="card-body">
            <h5>About</h5>
            <hr>
             <ul class="list-unstyled ">
            <li><a href="Addwebsite.php" class="ml-2">Add website</a></li>
            <li><a href="suggest.php" class="ml-2">suggest editors</a></li>
            
          </ul>
          </div>
        </div>
          <div class="card">
            <div class="card-body">
             <li class="text-primary fa fa-facebook"><span class="text-secondary font-weight-bold"> Page Transparency</span></li>
             <hr>
             <p class="para4 text-secondary text-justify">Facebook is showing information to help you better understand the purpose of a Page. See actions taken by the people who manage and post content.</p>
            </div>
          </div>
         
      </div>
</div>

