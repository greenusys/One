<?php
   include'viewpg.php';
   ?>
   <div class="row">
   	<div class="col-md-3 ">
   		<div class="card">
   			<div class="text-center card-body ">
   				<i class="text-secondary fa fa-commenting"></i>
   				<div class="text-center">No Review yet</div>
   				<div class="text-center">No recommendations yet</div>
   			</div>
   		</div>
   		<div class="card mt-2">
   			<div class="card-body">
   				<div class="font-weight-bold text-center">Have Feedback About Your Business
   				 Reviews Experience?</div>
   				 <p class="text-center">We've made changes to the Reviews tab and would love your feedback. What do you think of the new experience?<p>
   				 	<button>Share feedback</button>
   			</div>
   		</div>
   		<div class="card mt-2">
   			<div class="card-body">
   				<div class="text-center font-weight-bold">Ratings and reviews have changed
				</div>
				<div class="text-center">We've made it easier for people to recommend your Page
				</div>
				<div class="text-center">
				<button class="btn btn-primary">Learn more</button>
			</div>
   			</div>
   		</div>
   	</div>
   	<div class="col-md-9">
   		<div class="card">
   			<div class="card-header">
   				<ul class="list-unstyled d-flex">
   					<li><a href="" class="ml-4">Most helpfull</a></li>
   					<li><a href="" class="ml-4 text-secondary">Most recent</a></li>
   				</ul>
   			</div>
   		</div>
   	</div>
   	</div>