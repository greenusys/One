<?php
   include'header.php';
   include'sidebar.php';
   ?>
<div class="col-md-8 p-2">
   <span class=" text-secondary font-weight-bold">About Diana</span>
   <hr>
   <div class="col-md-8">
      <span class="text-secondary"> Carefully thought out content allows your audience to interact with you and builds brand recognition and loyalty. Potential customers and clients begin to trust your business as a source of useful information. Relevant and interesting content draws people together and creates an online community.
      </span>
      <hr>
      <span class=" text-secondary font-weight-bold">Favourite Quotes</span><hr>
      
      <span class="text-secondary">With the new day comes new strength and new thoughts. </span><hr>
   </div>
</div>