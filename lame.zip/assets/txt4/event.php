<?php
include 'viewpg.php';
?>
<div class="row">
	<div class="col-md-11">
		<div class="card">
			<div class="card-body">
				
			<div class="text-center card-body">
				<img class="img"src="image/j1.jpg"width="50px"height="50px">
				<div clas="mt-2">Get more people to your event</div>
				<div>Post a job for My school budiesss to reach the right applicants on Facebook.
				</div>
				<button type="button" class="mt-3 btn btn-success">Create job</button>
			</div>
		</div>


		</div>
	</div>
</div>