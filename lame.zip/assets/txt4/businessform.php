<?php
   include'header.php';
   ?>
<div class="container mt-5">
   <div class="row">
      <ul class="list-unstyled">
         <li class="font-weight-bold">Create a Page</li>
         <li>Connect your business, yourself or your cause to the worldwide community of people on Facebook. To get started, choose a Page category.
         </li>
      </ul>
      <div class="col-md-6">
         <div class="card">
            <span class="text-center ml-3 font-weight-bold">Business Or Brand </span>
            <span class="text-center ml-3 text-secondary">Connect with customers, grow your audience and showcase your products with a free business Page.</span>
            <form action="/action_page.php">
               <div class="mx-3 form-group">
                  <label for="text">Page Name</label>
                  <input type="text" class="form-control"  placeholder="Name your Page">
               </div>
               <div class="mx-3 form-group">
                  <label for="text">Category</label>
                  <input type="password" class="form-control" placeholder="Add a category to describe your page">
               </div>
               <span class="mx-3 text-secondary">When you create the page</span>
               <div class="text-center">
                  <a href="form2.php" class="ml-3 mt-3 mb-3 btn btn-primary">Continue</a>
               </div>
            </form>
         </div>
      </div>
      <div class="col-md-6">
         <div class="card">
            <span class="text-center ml-3 font-weight-bold">Public Figure </span>
            <span class="text-center ml-3 text-secondary">Connect with customers, grow your audience and showcase your products with a free business Page.</span>
            <form action="/action_page.php">
               <div class="mx-3 form-group">
                  <label for="text">Page Name</label>
                  <input type="text" class="form-control"  placeholder="Name your Page">
               </div>
               <div class="mx-3 form-group">
                  <label for="pwd">Category</label>
                  <input type="password" class="form-control" placeholder="Add a category to describe your page">
               </div>
               <span class="mx-3 text-secondary">When you create the page</span>
               <div class="text-center">
                   <a href="form2.php" class="ml-3 mt-3 mb-3 btn btn-primary">Continue</a>
               </div>
            </form>
         </div>
      </div>
   </div>
</div>