<?php
include'header.php';
?>
	<?php
	include'sidebar.php';
	?>
 		<div class="col-md-8 p-2">
   <span class="text-secondary font-weight-bold">Current City and Hometown</span>
   <hr>
   <div class="row">
      <div class="col-md-2 text-center">
         <img class=" rounded-pill img"width="50px" height="50px" src="image/p5.jpg"><br>
      </div>
      <div class="col-md-8">
         <a href=""class="t4 font-weight-bold">New Delhi</a><br>
         <span class="txt3 text-secondary"> Current city since October 27, 2018<span>
      </div>
   </div>
   <hr>
   <br>
   <div class="row">
      <div class="col-md-2 text-center">
         <img class=" rounded-pill img"width="50px" height="50px" src="image/p5.jpg"><br>
      </div>
      <div class="col-md-8">
         <a href="" class="t4 font-weight-bold">Dehradun</a><br>
         <span class="txt3 text-secondary"> Hometown</span>
      </div>
   </div>
   <br>
   <div class="row">
      <div class="col-md-2 text-center">
         <img class=" rounded-pill img"width="50px" height="50px" src="image/p5.jpg"><br>
      </div>
      <div class="col-md-8">
         <a href="" class="t4 font-weight-bold">Others places lived</a><br>
         <span class="txt3 text-secondary">Banglore
         <span><br>
         <a href="" class="txt3 text-secondary">moved on 1may 2017</a>
      </div>
   </div>
   <br> 
</div>