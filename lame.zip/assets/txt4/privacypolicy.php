<?php
   include'header.php';
   ?>
<div class="container">
   <div class="row">
      <div class="col-md-12">
         <div class="jumbotron">
            <h4>
               What is a Privacy Policy
            </h4>
            <p class="para text-secondary">
               A Privacy Policy is a legal statement that specifies what the business owner does with the personal data collected from users, along with how the data is processed and for what purposes.
            </p>
            <p class="para text-secondary">
               In 1968, Council of Europe did studies on the threat of the Internet expansion as they were concerned with the effects of technology on human rights. This lead to the development of policies that were to be developed to protect personal data.
            </p>
            <p class="para text-secondary">
               This marks the start of what we know now as a “Privacy Policy.” While the name “Privacy Policy” refers to the legal agreement, the concept of privacy and protecting user data is closely related.
            </p>
            <p class="para text-secondary">
               This agreement can also be known under these names:
            </p>
            <div class="ul">
               <li class="para text-secondary">
                  Privacy Statement
               </li>
               <li class="para text-secondary">
                  Privacy Notice
               </li>
               <li class="para text-secondary">
                  Privacy Information
               </li>
               <li class="para text-secondary">
                  Privacy Page
               </li>
            </div>
            <h4>
               Accessing and modifying your information
            </h4>
            <p class="para text-secondary">
               You and your Organisation may access, correct or delete information that you have uploaded to the Service using the tools within the Service (for example, editing your profile information or via the Activity Log). If you are not able to do so using the tools provided in the Service, you should contact your Organisation directly to access or modify your information.
            </p>
            <h4> 
               Third-party links and content
            </h4>
            <p class="text-secondary">
               The Service may contain links to content maintained by third parties that your Organisation does not control. You should review the privacy policies of each website that you visit.
            </p>
            <h4>
               Disclosure of information
            </h4>
            <p class="para text-secondary">
               Your Organisation discloses the information collected in the following ways:
            </p>
            <div class="ul">
               <li class="para text-secondary">
                  to third-party service providers that assist in providing the Service or part of the Service;
               </li>
               <li class="para text-secondary">
                  to third-party apps, websites or other services that you can connect to through the Service;
               </li>
               <li class="para text-secondary">
                  in connection with a substantial corporate transaction, such as the transfer of the Service, a merger, consolidation, asset sale or in the unlikely event of bankruptcy or insolvency;
               </li>
               <li class="para text-secondary">
                  to protect the safety of any person; to address fraud, security or technical issues; and
               </li>
               <li class="para text-secondary">
                  in connection with a subpoena, warrant, discovery order or other request or order from a law enforcement agency.
               </li>
               <h4>
                  Changes to the Privacy Policy
               </h4>
               <p class="para text-secondary">
                  This Privacy Policy may be updated from time to time. When updated the “last updated" date below will be amended and the new Privacy Policy will be posted online.
               </p>
               <h4>
                  Account Closure
               </h4>
               <p class=" para text-secondary">
                  If you would like to stop using the Service, you should contact your Organisation. Similarly, if you stop working for or with the Organisation, the Organisation may suspend Your Account and/or delete any information associated with Your Account.
               </p>
               <p class=" para text-secondary">
                  It typically takes about 90 days to delete an account after account closure, but some information may remain in backup copies for a reasonable period of time. Please note that content you create and share on the Service is owned by your Organisation and may remain on the Service and be accessible even if your Organisation deactivates or terminates Your Account. In this way, content that you provide on the Service is similar to other types of content (such as presentations or memos) that you may generate in the course of your work.
               </p>
            </div>
         </div>
      </div>
   </div>
</div>