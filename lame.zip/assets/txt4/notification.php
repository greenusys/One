<?php
include'header.php';
?>
<div class="container">
	<div class="row mt-3">
		<div class="col-md-6">
			<span class="notifi">Your Notification</span>
		</div>
		<div class="col-md-6">
			<a href="">Notification Setting</a>
		</div>
	</div>
	<hr>
	<span class="text-secondary ">Get notifications via:</span><a href="">Text message</a>
</div>
<div class="container mt-5">
	<div class="row">
		<div class="col-md-2 text-center">
			<img class="img rounded-pill" src="image/p5.jpg"width="35" height="35"><br><br><br>
			<img class="img rounded-pill" src="image/p5.jpg"width="35" height="35"><br><br><br>
			<img class="img rounded-pill" src="image/p5.jpg"width="35" height="35"><br><br><br>
			<img class="img rounded-pill" src="image/p5.jpg"width="35" height="35"><br><br><br>
			<img class="img rounded-pill" src="image/p5.jpg"width="35" height="35"><br><br><br>
			<img class="img rounded-pill" src="image/p5.jpg"width="35" height="35"><br><br><br>
		</div>
		<div class="col-md-10">
			<a href=""class="text-dark">Richa likes your post </a><br><i class="fa fa-facebook-official"></i>
			<br><br><hr>
			<a href=""class="text-dark">Richa likes your image</a><br><i class="fa fa-facebook-official"></i><br><br><hr>
			<a href=""class="text-dark">Richa likes your image</a><br><i class="fa fa-facebook-official"></i><br><hr>
			<a href=""class="text-dark">Richa likes your image</a><br><i class="fa fa-facebook-official"></i><br><hr>
			<a href=""class="text-dark">Richa likes your post</a><br><i class="fa fa-facebook-official"></i><br><hr>
			<a href=""class="text-dark">Richa likes your image</a><br><i class="fa fa-facebook-official"></i><br><hr>
		</div>
	</div>
</div>