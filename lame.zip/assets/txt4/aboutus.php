<?php
include'header.php';
include 'sidebar.php';
?>
           
    <div class="col-md-8 p-2">
                <a href=""class="ml-3 t1 text-dark">Finance Manager at L & T</a><br><br><br><br>
                <hr>
                <a href=""class="ml-3 t1 text-dark">Studied BSC From Tula College</a><br><br>
                <hr>
                <a href=""class="ml-3 t1 text-dark">Lives in D.Dun india</a><br>
                <hr>
                <a href=""class="ml-3 t1 text-dark">From Roorkee</a><br><br>
                <hr>
                <i class="ml-3 t1 text-dark fa fa-birthday-cake"> 9/10/1995</i><br><br>
                <hr>
            </div>
      

