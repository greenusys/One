<?php
   include'header.php';
   include'sidebar.php';
   ?>
<div class="col-md-8 p-2">
   <span class="text-secondary font-weight-bold">Work</span>
   <hr>
   <div class="row">
      <div class="col-md-2 text-center">
         <img class="rounded-pill img"width="50px" height="50px" src="image/p5.jpg"><br>
      </div>
      <div class="col-md-8">
         <a href=""class="t4  font-weight-bold">Finance Manager at L & T</a><br>
         <span class="txt3 text-secondary"> September 8, 2014 to March 31, 2018 · Dehra Dun, India</span>
      </div>
   </div>
   <br>
   <div class="row">
      <div class="col-md-2 text-center">
         <img class=" rounded-pill img"width="50px" height="50px" src="image/p5.jpg"><br>
      </div>
      <div class="col-md-8">
         <a href=""class="t4 font-weight-bold">Future group</a><br>
         <span class="txt3 text-secondary"> September 8, 2018 to March 31, 2019· Dehra Dun, India</span>
      </div>
   </div>
   <br>
   <div class="row">
      <div class="col-md-2 text-center">
         <img class=" rounded-pill img"width="50px" height="50px" src="image/p5.jpg"><br>
      </div>
      <div class="col-md-8">
         <span class="text-secondary font-weight-bold">Professional skill</span><br>
         <span class="txt3 text-secondary">Ability to Work Under Pressure,Decision Making,Time Management.
         <span>
      </div>
   </div>
   <br>
   <div class="row">
      <div class="col-md-2 text-center">
         <img class=" rounded-pill img"width="50px" height="50px" src="image/p5.jpg"><br>
      </div>
      <div class="col-md-8">
         <a href="" class="t4 font-weight-bold">Education</a><br>
         <span class="txt3 text-secondary">Army public school
         </span>
      </div>
   </div>
</div>