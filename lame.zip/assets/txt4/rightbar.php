 <div class="col-md-3">
         <div class="bg-white card-header ">
            <span class="text-secondary">No Rating Yet</span>
            <hr>
            <img class="img"src="image/view.jpg"width="150" height="100">
         <span class="text-secondary">our story</span><br>
         <a href="" class="text-dark">Finish your story to all people more about your business</a>
         </div>
        
          <ul class="card list-unstyled mt-2">
            <li><i class="text-secondary fa fa-users"><a href="" class="text-dark"> 115 followers</a></i></li>
               <hr>
               <li><i class="text-secondary fa fa-signal"><a href=""class="text-dark"> 2 post reach this week</a></i></li>
               <hr>
               <li><img class="img rounded-pill"src="image/p5.jpg"width="50" height="50"><a href="" class="text-dark"> 117 people like this </a></li>
          </ul>
          <div class="card ">
            <div class="card-body">
            <h5 class="ml-2 mt-2 font-weight-bold">Community</h5>
            <hr>
            <i class="text-secondary fa fa-users"> <span class="text-secondary">diana and 5 other like </span></i>
            <ul class="list-unstyled d-flex mt-2">
              <li><img class="img rounded-pill" src="image/p5.jpg"width="50px" height="50"></li>
                <li><img class="img rounded-pill" src="image/p5.jpg"width="50px" height="50"></li>
                  <li><img class="img rounded-pill" src="image/p5.jpg"width="50px" height="50"></li>

            </ul>
             <button class="bt btn btn-">invite friend</button>
             <ul class="list-unstyled d-flex">
              <li><i class="mt-2 fa fa-thumbs-o-up"></i><span class="text-secondary">112 people like this</span></li>
             </ul>
          </div>
        </div>
          <div class="card">
            <div class="card-body">
            <h5>About</h5>
            <hr>
             <ul class="list-unstyled ">
            <li><a href="" class="ml-2">Add website</a></li>
            <li><a href="" class="ml-2">suggest editors</a></li>
            
          </ul>
          </div>
        </div>
          <div class="card">
            <div class="card-body">
             <li class="text-primary fa fa-facebook"><span class="text-secondary font-weight-bold"> Page Transparency</span></li>
             <hr>
             <p class="para text-secondary text-justify"style="font-size: 10px;">Facebook is showing information to help you better understand the purpose of a Page. See actions taken by the people who manage and post content.</p>
            </div>
          </div>
         
      </div>