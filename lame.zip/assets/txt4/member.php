<?php
include'header.php';
?>
	<?php
	include'sidebar.php';
	?>
<div class="col-md-8 p-2">
               	<span class="text-secondary">Relationship</span>
                <hr>
                <div class="row">
	                <div class="col-md-2 text-center">
	                	<img class="rounded-pill img"width="50px" height="50px" src="image/p5.jpg"><br>
	                </div>
	                <div class="col-md-8">
	                	<a href=""class="t4 font-weight-bold">Neha sharma</a><br>
	                	<span class="txt3 text-secondary">Friend
	                </div>

                </div><br>
                 <div class="row">
	               
	                <div class="col-md-8">
	                	<span class="text-secondary">FAMILY MEMBERS
						</span>
							<hr>
	                	<span class="text-secondary"> </span>
	                </div>
	                
                </div><br>
                  <div class="row">
	                <div class="col-md-2 text-center">
	                	<img class="rounded-pill img"width="50px" height="50px" src="image/p5.jpg"><br>
	                </div>
	                <div class="col-md-8">
	                	<a href=""class="t4 font-weight-bold">Sweta</a><br>
	                	<span class="txt3 text-secondary">Sister in law
						<span><br>
							
	                </div>
	                
                </div><br>
                <div class="row">
	                <div class="col-md-2 text-center">
	                	<img class="rounded-pill img"width="50px" height="50px" src="image/p5.jpg"><br>
	                </div>
	                <div class="col-md-8">
	                	<a href=""class="t4 font-weight-bold">Ayush </a><br>
	                	<span class="txt3 text-secondary">Brother in law
						<span><br>	
	                </div>
                </div>
             </div>
