<?php
include'header.php';
?>
<div class="container mt-5">
	<div class="row">
		<ul class="list-unstyled">
			<li class="font-weight-bold">Create a Page</li>
			<li>Connect your business, yourself or your cause to the worldwide community of people on Facebook. To get started, choose a Page category.
			</li>
		</ul>
		<div class="text-center col-md-6">
			<div class="pl-5 card ">
				 <img class="imgcente rounded-pill "width="200px" height="200px" src="image/p5.jpg">
				 <span class=" font-weight-bold">Business or Brand</span>
				<span class=" text-secondary">howcase your products and services, spotlight your brand and 
				reach more customers on Facebook.</span>
				 <a href="businessform.php" class="text-center">Get Started</a>														
			</div>
		</div>
		<div class="text-center col-md-6">
			<div class="pl-5 card ">
				 <img class=" imgcente rounded-pill"width="200px" height="200px" src="image/p5.jpg">
				 <span class="font-weight-bold">Business or Brand</span>
				<span class="text-secondary">howcase your products and services, spotlight your brand and 
				reach more customers on Facebook.</span>
				 <a href="businessform.php" class="text-center">Get Started</a>
																		
			</div>
		</div>
	</div>
</div>