<?php
include 'viewpg.php';
?>

<div class="row">
<div class="col-md-9">
	<div class="card">
		<ul class="list-unstyled mt-3">
			<li class="text-center font-weight-bold">Showcase your services</li>
			<li class="text-secondary text-center">Let People know what my buddies offer</li>
			<div class="text-center mt-4">
		<button type="button" class="text-center btn btn-primary">Add a Services</button>
			</div>
		</ul>
	</div>
</div>
<?php
include 'rightbar.php';
?>
</div>


