<?php include 'header.php';?>
<div class="container card mt-5  shadow-sm p-4">
    <div class="row">
	    <div class="col-md-11">
			<h5 class="font-weight-bold text-dark">Suggested for you</h5>
			<h6 class="font-weight:normal;">Groups you might be interested in</h6>
		</div>
		<div class="col-md-1">
		    <a href="#"><h6 class="text-primary font-weight-normal mt-3">See All</h6></a>
		</div>
	</div>
    <div class="row mt-2">
		<?php
		for($i=0;$i<4;$i++)
		{?>
			<div class="col-md-3 ">
				<div class="suggest-group">
					<img src="image/photo.jpeg" class="group-image-size">
					<div class="row p-4">
						 <h6 class="font-weight-bold text-dark ">My Thought - BK Shivani</h6>
						 <h6 class="font-weight-normal">117K members • 350 posts a day</h6>
						 <button type="button" class="join-butn mt-2" id="join">Join</button>
						  <button type="button" class="join-butn mt-2" id="request" style="display:none">Requested</button>
					</div>
				</div>
			</div>
		<?php
			}
		?>	
	</div>
</div>

<div class="container card mt-5  shadow-sm p-4">
   <div class="row">
		<div class="col-md-11">
			<h5 class="font-weight-bold text-dark">Friends' groups</h5>
			<h6 class="font-weight:normal;">Groups that your friends are in</h6>
		</div>
		<div class="col-md-1">
			<a href="#"><h6 class="text-primary font-weight-normal mt-3">See All</h6></a>
		</div>
	</div>
	<hr>
    <div class="row mt-2">
	    <?php
		for($i=0;$i<2;$i++)
		{?>
			<div class="col-md-6">
				<div class="card mb-3 bg-light" style="max-width: 540px;">
					<div class="row no-gutters">
						<div class="col-md-4">
						  <img src="image/images.jpg" class="card-img group-img-size">
						</div>
						<div class="col-md-8">
							<div class="card-body">
								<h5 class="card-title">Uttarakhand Jobs</h5>
								<p class="card-text">53K members • 10 posts a week</p>
								<div class="row">
									<div class="col-sm-2">
									   <img src="image/profile.jpeg" class="rounded-circle img-fluid group-profile">
									</div>
									 <div class="col-sm-2">
									   <img src="image/photo.jpeg" class="rounded-circle img-fluid group-profile">
									</div>
									 <div class="col-sm-2">
									   <img src="image/profile.jpeg" class="rounded-circle img-fluid group-profile">
									</div>
								</div>
								<div class="row">
								    <div class="col-sm-6">
										<h6 class="font-weight-bold mt-2 fs">8 friends are members</h6>
									</div>
									<div class="col-sm-6">
										<button type="button" class="join-butn  w-100" id="join1">Join</button>
								        <button type="button" class="join-butn  w-100" id="request1" style="display:none">Requested</button>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php
			}
		?>	
	</div>
</div>

<div class="container card mt-5  shadow-sm p-4">
   <div class="row">
	   <div class="col-md-11">
			<h5 class="font-weight-bold text-dark">Categories</h5>
			<h6 class="font-weight:normal;">Find a group by browsing top categories</h6>
		</div>
		<div class="col-md-1">
			<a href="#"><h6 class="text-primary font-weight-normal mt-3">See All</h6></a>
		</div>
	</div>
    <div class="row mt-2">
	    <div class="col-md-3">
		    <div class="card rounded-lg">
			    <img src="image/photo.jpeg" class="rounded-lg group-image-size">
				<a href="#"><div class="centered font-weight-bold text-white">Entertainment</div></a>
			</div>
		</div>
		<div class="col-md-3">
		    <div class="card rounded-lg">
			    <img src="image/coverphoto.jpg" class="rounded-lg group-image-size">
				<a href="#"><div class="centered font-weight-bold text-white">Relationship & Identity</div></a>
			</div>
		</div>
		<div class="col-md-3">
		    <div class="card rounded-lg">
			    <img src="image/profile.jpeg" class="rounded-lg group-image-size">
				<a href="#"><div class="centered font-weight-bold text-white">Civics & Community</div></a>
			</div>
		</div>
		<div class="col-md-3">
		    <div class="card rounded-lg">
			    <img src="image/images.jpg" class="rounded-lg group-image-size">
				<a href="#"><div class="centered font-weight-bold text-white">Buy & Sell</div></a>
			</div>
		</div>
	</div>
</div>

<div class="container card mt-5  shadow-sm p-4">
    <div class="row">
		<div class="col-md-11">
			<h5 class="font-weight-bold text-dark">Popular near you</h5>
			<h6 class="font-weight:normal;">Groups that people in your area are in</h6>
		</div>
		<div class="col-md-1">
			<a href="#"><h6 class="text-primary font-weight-normal mt-3">See All</h6></a>
		</div>
	</div>
    <div class="row mt-2">
	    <?php
		for($i=0;$i<2;$i++)
		{?>
			<div class="col-md-6">
				<div class="card mb-3 bg-light" style="max-width: 540px;">
					<div class="row no-gutters">
						<div class="col-md-4">
						  <img src="image/coverphoto.jpg" class="card-img group-img-size">
						</div>
						<div class="col-md-8">
							<div class="card-body">
								<h5 class="card-title">Soups and Salads of the world ...part 2</h5>
								<p class="card-text">161K members • 140 posts a day</p>
								<div class="row">
									<button type="button" class="join-butn  w-50 m-auto" id="join2">Join</button>
									<button type="button" class="join-butn  w-50 m-auto" id="request2" style="display:none">Requested</button>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php
			}
		?>	
	</div>
</div>

<div class="container card mt-5  shadow-sm p-4">
    <h5 class="font-weight-bold text-dark">More suggestions</h5>
	<div class="row mt-2">
	    <?php
		for($i=0;$i<2;$i++)
		{?>
			<div class="col-md-6">
				<div class="card mb-3 bg-light" style="max-width: 540px;">
					<div class="row no-gutters">
						<div class="col-md-4">
						  <img src="image/images.jpg" class="card-img group-img-size">
						</div>
						<div class="col-md-8">
							<div class="card-body">
								<h5 class="card-title">Wipro Wilp 2019 Freshers</h5>
								<p class="card-text">143 members • 10 posts a year</p>
								<div class="row">
									<button type="button" class="join-butn  w-50 m-auto" id="join2">Join</button>
									<button type="button" class="join-butn  w-50 m-auto" id="request2" style="display:none">Requested</button>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php
			}
		?>	
	</div>
</div>

 
 <script>
$(document).ready(function(){
   $("#join").click(function(){
	 $("#request").show();
	 $("#join").hide();
  });
});
</script>

<script>
$(document).ready(function(){
   $("#request").click(function(){
	 $("#join").show();
	 $("#request").hide();
  });
});
</script>

<script>
$(document).ready(function(){
   $("#join1").click(function(){
	 $("#request1").show();
	 $("#join1").hide();
  });
});
</script>

<script>
$(document).ready(function(){
   $("#request1").click(function(){
	 $("#join1").show();
	 $("#request1").hide();
  });
});
</script>

<script>
$(document).ready(function(){
   $("#join2").click(function(){
	 $("#request2").show();
	 $("#join2").hide();
  });
});
</script>

<script>
$(document).ready(function(){
   $("#request2").click(function(){
	 $("#join2").show();
	 $("#request2").hide();
  });
});
</script>



