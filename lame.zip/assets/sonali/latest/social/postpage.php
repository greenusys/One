<?php include 'header.php';?>
<div class="container profile-info-div bg-white border-1 shadow-sm p-2 w-50 mt-4">
    <div class="row  m-auto">
	    <div class="col-sm-4">
		    <div>
			    <img src="image/coverphoto.jpg"  class="rounded-sm img-fluid">
			</div>
			 <img src="image/profile.jpeg" class="rounded-circle img-fluid people-profile">
		</div>
		<div class="col-sm-8">
		    <a href="#"><h6 class="mt-3"><span class="font-weight-bold text-info mt-4">Sonali Sona </span></a> &nbsp; <i class="fa fa-caret-right" style="font-size:20px"></i> &nbsp; <a href="#"><span class="font-weight-bold text-info mt-4"> Abhishek </span></h6></a>
			<h6 class="mt-4" id="happy"><span>2 Nov 2019</span> &nbsp; <i class='fas fa-user-friends'></i>  &nbsp; <span>Happy birthday sir!!!!</span></h6>
		</div>
	</div>
	<hr>
	<div class="row mt-2" >
		<div class="col-sm-7" id="model"  >
			<button type="button" id="like" class="btn btn-primary rounded-circle"><i class="fa fa-thumbs-up" style="font-size:14px"></i></button> 80
			<button type="button"  id="lov" class="btn btn-danger rounded-circle" data-toggle="modal" data-target="#exampleModal" ><i class="fa fa-heart" style="font-size:14px"></i></button> 100
		</div>
		
		<div class="col-sm-5" id="comment" >
			<h6 class="font-weight-normal" > <strong>86 Comments </strong></h6>
		</div>
	</div>
	<div class="row card bg-dark mt-1 w-25 p-2 " id="likelist" style="display:none">
		<ul class="text-white" style="list-style:none">
			<li>Sonali Mishra</li> 
			<li>Shivam Saini</li>
			<li>Rahul Kumar</li>
			<li>Deepak Nauliya</li>
			<li>Ravish Beg</li>
		</ul>								
	</div>
	<div class="row card bg-dark mt-1 w-25 p-2 " id="lovlist" style="display:none">
		<ul class="text-white" style="list-style:none">
			<li>Sonali Mishra</li> 
			<li>Abhishek</li>
			
		</ul>								
	</div>
	<div class="row  " id="commentlist" style="display:none">
	    <div class="offset-7 col-sm-3 card bg-dark mt-1 w-25 p-2">
			<ul class="text-white" style="list-style:none">
				<li>Sonali Mishra</li> 
				<li>Abhishek</li>
			</ul>
        </div>		
	</div>
</div>

<div class="container profile-info-div bg-white border-1 shadow-sm p-2 w-50 mt-4">
    <div class="row  m-auto">
	    <div class="col-sm-4">
		    <div>
			    <img src="image/images.jpg"  class="rounded-sm img-fluid">
			</div>
			 <img src="image/photo.jpeg" class="rounded-circle img-fluid people-profile">
		</div>
		<div class="col-sm-8">
		    <a href="#"><h6 class="mt-3"><span class="font-weight-bold text-info mt-4">Sonali mishra </span></a> &nbsp; <i class="fa fa-caret-right" style="font-size:20px"></i> &nbsp; <a href="#"><span class="font-weight-bold text-info mt-4"> Abhishek </span></h6></a>
			<h6 class="mt-4" id="hapy"><span>2 Nov 2019</span> &nbsp; <i class='fas fa-user-friends'></i>  &nbsp; <span>Happy birthday sir!!!!</span></h6>
		</div>
	</div>
	<hr>
	<div class="row mt-2" >
		<div class="col-sm-7" id="model1"  >
			<button type="button" id="blue" class="btn btn-primary rounded-circle"><i class="fa fa-thumbs-up" style="font-size:14px"></i></button> 35
		</div>
		
		<div class="col-sm-5" id="rev">
			<h6 class="font-weight-normal" > <strong>16 Comments </strong></h6>
		</div>
	</div>
	<div class="row card bg-dark mt-1 w-25 p-2 " id="bluelist" style="display:none">
		<ul class="text-white" style="list-style:none">
			<li>Sonali Mishra</li> 
			<li>Shivam Saini</li>
			<li>Rahul Kumar</li>
			<li>Deepak Nauliya</li>
			<li>Ravish Beg</li>
		</ul>								
	</div>
	
	<div class="row" id="revlist" style="display:none">
	    <div class="offset-7 col-sm-3 card bg-dark mt-1 w-25 p-2">
			<ul class="text-white" style="list-style:none">
				<li>Sonali Mishra</li> 
				<li>Abhishek</li>
			</ul>
        </div>		
	</div>
</div>

<div class="container profile-info-div bg-white border-1 shadow-sm p-2 w-50 mt-4">
    <div class="row  m-auto">
	    <div class="col-sm-4">
		    <div>
			    <img src="image/coverphoto.jpg"  class="rounded-sm img-fluid">
			</div>
			 <img src="image/profile.jpeg" class="rounded-circle img-fluid people-profile">
		</div>
		<div class="col-sm-8">
		    <a href="#"><h6 class="mt-3"><span class="font-weight-bold text-info mt-4">Neha Sona </span></a> &nbsp; <i class="fa fa-caret-right" style="font-size:20px"></i> &nbsp; <a href="#"><span class="font-weight-bold text-info mt-4"> Abhishek </span></h6></a>
			<h6 class="mt-4" id="videotext"><span>2 Nov 2019</span> &nbsp; <i class='fas fa-user-friends'></i>  &nbsp; <span>shared a Birthday Video</span></h6>
		</div>
	</div>
	<hr>
	<div class="row card bg-dark mt-1 w-25 p-2 " id="bluelikelist" style="display:none">
		<ul class="text-white" style="list-style:none">
			<li>Sonali Mishra</li> 
			<li>Shivam Saini</li>
			<li>Rahul Kumar</li>
			<li>Deepak Nauliya</li>
			<li>Ravish Beg</li>
		</ul>								
	</div>
	
	<div class="row" id="redcomntlist" style="display:none">
	    <div class="offset-7 col-sm-3 card bg-dark mt-1 w-25 p-2">
			<ul class="text-white" style="list-style:none">
				<li>Sonali Mishra</li> 
				<li>Abhishek</li>
			</ul>
        </div>		
	</div>
	<div class="row mt-2" >
		<div class="col-sm-7" id="video"  >
			<button type="button" id="bluelike" class="btn btn-primary rounded-circle"><i class="fa fa-thumbs-up" style="font-size:14px"></i></button> 55
		</div>
		
		<div class="col-sm-5" id="redcomnt">
			<h6 class="font-weight-normal" > <strong>25 Comments </strong></h6>
		</div>
	</div>
	
</div>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
	
		<div class="modal-content" id="content" style="display:none">
		    <div class="modal-header border-bottom-0">
				<div class="row">
					<div class="col-sm-3"> 
					    <img src="image/profile.jpeg" class="rounded-circle img-fluid group-profile">
					</div>
					<div class="col-sm-8">
						<a href="#"><h6 class="mt-1"><span class="font-weight-bold text-info">Sonali Sona </span></a> &nbsp; <i class="fa fa-caret-right" style="font-size:20px"></i> &nbsp; <a href="#"><span class="font-weight-bold text-info mt-4"> Abhishek </span></h6></a>
						<h6 class="mt-2"><span>2 Nov 2019</span> &nbsp; <i class='fas fa-user-friends'></i> </h6>
					</div>
					<!--<div class="col-sm-1">
					    <i class="fa fa-caret-down" style="font-size:22px" id="option"></i>
					</div>--->
				</div>
			</div>
			<div class="modal-body">
			    <div class="hero-image space">
					<div class="hero-text">
						<h3>Happy Birth Day....!!</h3>
					</div>
				</div>
				<div class="row mt-3">
					<div class="col-sm-7">
						<button type="button" class="btn btn-primary rounded-circle" data-toggle="modal" data-target="#exampleModal" id="like2"><i class="fa fa-thumbs-up" style="font-size:14px"></i></button>
						  
						<button type="button" class="btn btn-danger rounded-circle" data-toggle="modal" data-target="#exampleModal" id="love"><i class="fa fa-heart" style="font-size:14px"></i></button> 100
						
						<div class="row card bg-dark mt-1 w-75 p-2 " id="likelist2" style="display:none">
							<ul class="text-white" style="list-style:none">
								<li>Sonali Mishra</li> 
								<li>Shivam Saini</li>
								<li>Rahul Kumar</li>
								<li>Deepak Nauliya</li>
								<li>Ravish Beg</li>
							</ul>								
						</div>
						
						<div class="row card bg-dark mt-1 w-75 p-2 " id="lovelist" style="display:none">
							<ul class="text-white" style="list-style:none">
								<li>Sonali Mishra</li> 
								<li>Abhishek</li>
								
							</ul>								
						</div>
					</div>
					
					<div class="col-sm-5">
						 <h6 class="font-weight-normal" id="review"> <strong>104 Comments </strong></h6>
						<div class="row card bg-dark mt-1 w-100 p-2 " id="reviewlist" style="display:none">
							<ul class="text-white" style="list-style:none">
								<li>Sonali Mishra</li> 
								<li> prakhar Abhishek</li>
								<li> abhishek</li>
							</ul>								
						</div>
					</div>
				</div>
				<hr>
				<div class="row emoji p-2 shadow-sm  rounded-pill" id="gif" style="display:none">
					<div class="col-sm-2">
					   <img src="image/em1.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em2.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em3.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em4.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em5.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em6.gif" class="rounded-circle gif">
					</div>
	            </div>
				<div class="row">
					<div class="offset-1 col-sm-3">
						<div id="emoji"><i class="fa fa-thumbs-up" style="font-size:24px"></i> Like</div>
					</div>
					<div class="offset-3 col-sm-4" data-toggle="tooltip" data-placement="top" title="Leave a Comment">
						 <i class="fa fa-comments" style="font-size:24px"></i>   Comment
					</div>
				</div>
			</div>
		</div>
		
		<div class="modal-content" id="coment" style="display:none">
		    <div class="modal-header border-bottom-0">
				<div class="row">
					<div class="col-sm-3"> 
					    <img src="image/profile.jpeg" class="rounded-circle img-fluid group-profile">
					</div>
					<div class="col-sm-8">
						<a href="#"><h6 class="mt-1"><span class="font-weight-bold text-info">Sonali Sona </span></a> &nbsp; <i class="fa fa-caret-right" style="font-size:20px"></i> &nbsp; <a href="#"><span class="font-weight-bold text-info mt-4"> Abhishek </span></h6></a>
						<h6 class="mt-2"><span>2 Nov 2019</span> &nbsp; <i class='fas fa-user-friends'></i> </h6>
					</div>
					<!--<div class="col-sm-1">
					    <i class="fa fa-caret-down" style="font-size:22px" id="option"></i>
					</div>--->
				</div>
			</div>
			<div class="modal-body">
			    <div class="hero-image space">
					<div class="hero-text">
						<h3>Happy Birth Day....!!</h3>
					</div>
				</div>
				<div class="row mt-3">
					<div class="col-sm-7">
						<button type="button" class="btn btn-primary rounded-circle" data-toggle="modal" data-target="#exampleModal" id="like1"><i class="fa fa-thumbs-up" style="font-size:14px"></i></button>
						  
						<button type="button" class="btn btn-danger rounded-circle" data-toggle="modal" data-target="#exampleModal" id="love1"><i class="fa fa-heart" style="font-size:14px"></i></button> 100
						
						<div class="row card bg-dark mt-1 w-75 p-2 " id="likelist1" style="display:none">
							<ul class="text-white" style="list-style:none">
								<li>Sonali Mishra</li> 
								<li>Shivam Saini</li>
								<li>Rahul Kumar</li>
								<li>Deepak Nauliya</li>
								<li>Ravish Beg</li>
							</ul>								
						</div>
						
						<div class="row card bg-dark mt-1 w-75 p-2 " id="lovelist1" style="display:none">
							<ul class="text-white" style="list-style:none">
								<li>Sonali Mishra</li> 
								<li>Abhishek</li>
								
							</ul>								
						</div>
					</div>
					
					<div class="col-sm-5">
						 <h6 class="font-weight-normal" id="review1"> <strong>104 Comments </strong></h6>
						<div class="row card bg-dark mt-1 w-100 p-2 " id="reviewlist1" style="display:none">
							<ul class="text-white" style="list-style:none">
								<li>Sonali Mishra</li> 
								<li> prakhar Abhishek</li>
								<li> abhishek</li>
							</ul>								
						</div>
					</div>
				</div>
				<hr>
				<div class="row emoji p-2 shadow-sm  rounded-pill" id="gif1" style="display:none">
					<div class="col-sm-2">
					   <img src="image/em1.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em2.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em3.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em4.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em5.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em6.gif" class="rounded-circle gif">
					</div>
	            </div>
				<div class="row">
					<div class="offset-1 col-sm-3">
						<div id="emoji1"><i class="fa fa-thumbs-up" style="font-size:24px"></i> Like</div>
					</div>
					<div class="offset-3 col-sm-4" data-toggle="tooltip" data-placement="top" title="Leave a Comment">
						 <i class="fa fa-comments" style="font-size:24px"></i>   Comment
					</div>
				</div>
				<div class="row mt-3">
					<div class="col-sm-2">
						<img src="image/profile.jpeg" class="rounded-circle img-fluid comment-profile">
					</div>
					<div class="col-sm-8 comnt rounded-pill">
						<h6 class="font-weight-bold mt-2 fs">Sonali Mishra</h6><span>Looking very very gorgeous</span>
					</div>
					<div class="col-sm-2">
						 <div class="dropdown mr-1">
							<i class="fa fa-caret-down mt-2 " id="dropdownMenuOffset" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-offset="10,20" data-toggle="tooltip" data-placement="top" title="Hide or report this" id="comment" ></i>
							<div class="dropdown-menu content-div" aria-labelledby="dropdownMenuOffset">
								<a class="dropdown-item" href="#"><button class="fs"> <i class="fa fa-close" style="color:gray"></i></button> Hide comment</a>
								<a class="dropdown-item" href="#">Find Support or report Comment</a>
							</div>
						</div>
					</div>
				</div>
						
				<div class="row emoji p-2 shadow-sm  rounded-pill" id="gif2" style="display:none">
					<div class="col-sm-2">
					   <img src="image/em1.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em2.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em3.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em4.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em5.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em6.gif" class="rounded-circle gif">
					</div>
				</div>
						
				<div class="row mt-1">
					<div class="offset-3 col-sm-2">
						<a href="#"><h6 class="font-weight:normal text-info fs" id="textemoji">Like.<h6></a>
					</div>
					<div class="col-sm-2">
						<a href="#"><h6 class="font-weight:normal text-info fs" id="comnt">Reply.<h6></a>
					</div>
					<div class="col-sm-2">
						<a href="#"><h6 class="font-weight:normal text-dark">1w<h6></a>
					</div>
				</div>
						
				<div class="row reply p-2 shadow-sm  rounded-pill" id="msg1" style="display:none">
					<div class="col-sm-2">
					   <img src="image/profile.jpeg" class="rounded-circle img-fluid comment-profile">
					</div>
					<div class="col-sm-5">
					   <input type="text" name="name" placeholder="Write a reply ..." class="border-0 rounded-pill bg-light mt-2">
					</div>
					<div class="offset-1 col-sm-1">
					<i class="fa fa-smile-o mt-2" data-toggle="tooltip" data-placement="top" title="Insert an emoji" style="font-size:22px"></i>
						
					</div>
					<div class="col-sm-1">
						<label for="file">
							<i class="fa fa-camera mt-2"  data-toggle="tooltip" data-placement="top" title="Attach a Photo or Video" style="font-size:20px"></i>
							<!---<img id="blah" src="#">--->
							<input type='file' onchange="readURL(this);" id="file" style="display: none" name="image" accept="image/gif,image/jpeg,image/jpg,image/png" multiple="" data-original-title="upload photos">
						</label>
					</div>
				</div>
			</div>
			<div class="row bottom-section p-2 shadow-sm">
				<div class="col-sm-2">
				   <img src="image/profile.jpeg" class="rounded-circle img-fluid comment-profile">
				</div>
				<div class="col-sm-5">
				   <input type="text" name="name" placeholder="Write a reply ..." class="border-0 rounded-pill bg-light mt-2">
				</div>
				<div class="offset-1 col-sm-1">
				<i class="fa fa-smile-o mt-2" data-toggle="tooltip" data-placement="top" title="Insert an emoji" style="font-size:22px"></i>
					
				</div>
				<div class="col-sm-1">
					<label for="file">
						<i class="fa fa-camera mt-2"  data-toggle="tooltip" data-placement="top" title="Attach a Photo or Video" style="font-size:20px"></i>
						<!---<img id="blah" src="#">--->
						<input type='file' onchange="readURL(this);" id="file" style="display: none" name="image" accept="image/gif,image/jpeg,image/jpg,image/png" multiple="" data-original-title="upload photos">
					</label>
				</div>
			</div>			
		</div>
		
		<div class="modal-content" id="content1" style="display:none">
		    <div class="modal-header border-bottom-0">
				<div class="row">
					<div class="col-sm-3"> 
					    <img src="image/profile.jpeg" class="rounded-circle img-fluid group-profile">
					</div>
					<div class="col-sm-8">
						<a href="#"><h6 class="mt-1"><span class="font-weight-bold text-info">Sonali mishra </span></a> &nbsp; <i class="fa fa-caret-right" style="font-size:20px"></i> &nbsp; <a href="#"><span class="font-weight-bold text-info mt-4"> Abhishek </span></h6></a>
						<h6 class="mt-2"><span>2 Nov 2019</span> &nbsp; <i class='fas fa-user-friends'></i> </h6>
					</div>
					<!--<div class="col-sm-1">
					    <i class="fa fa-caret-down" style="font-size:22px" id="option"></i>
					</div>--->
				</div>
			</div>
			<div class="modal-body">
			    <h5 >Wishing You a very very Happy Birthday...!!</h5>
				<hr>
				<div class="row mt-3">
					<div class="col-sm-7">
						<button type="button" class="btn btn-primary rounded-circle" data-toggle="modal" data-target="#exampleModal" id="like2"><i class="fa fa-thumbs-up" style="font-size:14px"></i></button>
						  
						<button type="button" class="btn btn-danger rounded-circle" data-toggle="modal" data-target="#exampleModal" id="love"><i class="fa fa-heart" style="font-size:14px"></i></button> 100
						
						<div class="row card bg-dark mt-1 w-75 p-2 " id="likelist2" style="display:none">
							<ul class="text-white" style="list-style:none">
								<li>Sonali Mishra</li> 
								<li>Shivam Saini</li>
								<li>Rahul Kumar</li>
								<li>Deepak Nauliya</li>
								<li>Ravish Beg</li>
							</ul>								
						</div>
						
						<div class="row card bg-dark mt-1 w-75 p-2 " id="lovelist" style="display:none">
							<ul class="text-white" style="list-style:none">
								<li>Sonali Mishra</li> 
								<li>Abhishek</li>
								
							</ul>								
						</div>
					</div>
					
					<div class="col-sm-5">
						 <h6 class="font-weight-normal" id="review"> <strong>104 Comments </strong></h6>
						<div class="row card bg-dark mt-1 w-100 p-2 " id="reviewlist" style="display:none">
							<ul class="text-white" style="list-style:none">
								<li>Sonali Mishra</li> 
								<li> prakhar Abhishek</li>
								<li> abhishek</li>
							</ul>								
						</div>
					</div>
				</div>
				<hr>
				<div class="row emoji p-2 shadow-sm  rounded-pill" id="gif" style="display:none">
					<div class="col-sm-2">
					   <img src="image/em1.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em2.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em3.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em4.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em5.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em6.gif" class="rounded-circle gif">
					</div>
	            </div>
				<div class="row">
					<div class="offset-1 col-sm-3">
						<div id="emoji"><i class="fa fa-thumbs-up" style="font-size:24px"></i> Like</div>
					</div>
					<div class="offset-3 col-sm-4" data-toggle="tooltip" data-placement="top" title="Leave a Comment">
						 <i class="fa fa-comments" style="font-size:24px"></i>   Comment
					</div>
				</div>
			</div>
		</div>
		
		<div class="modal-content" id="coment1" style="display:none">
		    <div class="modal-header border-bottom-0">
				<div class="row">
					<div class="col-sm-3"> 
					    <img src="image/profile.jpeg" class="rounded-circle img-fluid group-profile">
					</div>
					<div class="col-sm-8">
						<a href="#"><h6 class="mt-1"><span class="font-weight-bold text-info">Sonali Sona </span></a> &nbsp; <i class="fa fa-caret-right" style="font-size:20px"></i> &nbsp; <a href="#"><span class="font-weight-bold text-info mt-4"> Abhishek </span></h6></a>
						<h6 class="mt-2"><span>2 Nov 2019</span> &nbsp; <i class='fas fa-user-friends'></i> </h6>
					</div>
					<!--<div class="col-sm-1">
					    <i class="fa fa-caret-down" style="font-size:22px" id="option"></i>
					</div>--->
				</div>
			</div>
			<div class="modal-body">
			    <h5 >Wishing You a very very Happy Birthday...!!</h5>
				<hr>
				<div class="row mt-3">
					<div class="col-sm-7">
						<button type="button" class="btn btn-primary rounded-circle" data-toggle="modal" data-target="#exampleModal" id="like1"><i class="fa fa-thumbs-up" style="font-size:14px"></i></button>
						  
						<button type="button" class="btn btn-danger rounded-circle" data-toggle="modal" data-target="#exampleModal" id="love1"><i class="fa fa-heart" style="font-size:14px"></i></button> 100
						
						<div class="row card bg-dark mt-1 w-75 p-2 " id="likelist1" style="display:none">
							<ul class="text-white" style="list-style:none">
								<li>Sonali Mishra</li> 
								<li>Shivam Saini</li>
								<li>Rahul Kumar</li>
								<li>Deepak Nauliya</li>
								<li>Ravish Beg</li>
							</ul>								
						</div>
						
						<div class="row card bg-dark mt-1 w-75 p-2 " id="lovelist1" style="display:none">
							<ul class="text-white" style="list-style:none">
								<li>Sonali Mishra</li> 
								<li>Abhishek</li>
								
							</ul>								
						</div>
					</div>
					
					<div class="col-sm-5">
						 <h6 class="font-weight-normal" id="review1"> <strong>104 Comments </strong></h6>
						<div class="row card bg-dark mt-1 w-100 p-2 " id="reviewlist1" style="display:none">
							<ul class="text-white" style="list-style:none">
								<li>Sonali Mishra</li> 
								<li> prakhar Abhishek</li>
								<li> abhishek</li>
							</ul>								
						</div>
					</div>
				</div>
				<hr>
				<div class="row emoji p-2 shadow-sm  rounded-pill" id="gif1" style="display:none">
					<div class="col-sm-2">
					   <img src="image/em1.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em2.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em3.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em4.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em5.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em6.gif" class="rounded-circle gif">
					</div>
	            </div>
				<div class="row">
					<div class="offset-1 col-sm-3">
						<div id="emoji1"><i class="fa fa-thumbs-up" style="font-size:24px"></i> Like</div>
					</div>
					<div class="offset-3 col-sm-4" data-toggle="tooltip" data-placement="top" title="Leave a Comment">
						 <i class="fa fa-comments" style="font-size:24px"></i>   Comment
					</div>
				</div>
				<div class="row mt-3">
					<div class="col-sm-2">
						<img src="image/profile.jpeg" class="rounded-circle img-fluid comment-profile">
					</div>
					<div class="col-sm-8 comnt rounded-pill">
						<h6 class="font-weight-bold mt-2 fs">Sonali Mishra</h6><span>Looking very very gorgeous</span>
					</div>
					<div class="col-sm-2">
						 <div class="dropdown mr-1">
							<i class="fa fa-caret-down mt-2 " id="dropdownMenuOffset" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-offset="10,20" data-toggle="tooltip" data-placement="top" title="Hide or report this" id="comment" ></i>
							<div class="dropdown-menu content-div" aria-labelledby="dropdownMenuOffset">
								<a class="dropdown-item" href="#"><button class="fs"> <i class="fa fa-close" style="color:gray"></i></button> Hide comment</a>
								<a class="dropdown-item" href="#">Find Support or report Comment</a>
							</div>
						</div>
					</div>
				</div>
						
				<div class="row emoji p-2 shadow-sm  rounded-pill" id="gif2" style="display:none">
					<div class="col-sm-2">
					   <img src="image/em1.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em2.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em3.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em4.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em5.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em6.gif" class="rounded-circle gif">
					</div>
				</div>
						
				<div class="row mt-1">
					<div class="offset-3 col-sm-2">
						<a href="#"><h6 class="font-weight:normal text-info fs" id="textemoji">Like.<h6></a>
					</div>
					<div class="col-sm-2">
						<a href="#"><h6 class="font-weight:normal text-info fs" id="comnt">Reply.<h6></a>
					</div>
					<div class="col-sm-2">
						<a href="#"><h6 class="font-weight:normal text-dark">1w<h6></a>
					</div>
				</div>
						
				<div class="row reply p-2 shadow-sm  rounded-pill" id="msg1" style="display:none">
					<div class="col-sm-2">
					   <img src="image/profile.jpeg" class="rounded-circle img-fluid comment-profile">
					</div>
					<div class="col-sm-5">
					   <input type="text" name="name" placeholder="Write a reply ..." class="border-0 rounded-pill bg-light mt-2">
					</div>
					<div class="offset-1 col-sm-1">
					<i class="fa fa-smile-o mt-2" data-toggle="tooltip" data-placement="top" title="Insert an emoji" style="font-size:22px"></i>
						
					</div>
					<div class="col-sm-1">
						<label for="file">
							<i class="fa fa-camera mt-2"  data-toggle="tooltip" data-placement="top" title="Attach a Photo or Video" style="font-size:20px"></i>
							<!---<img id="blah" src="#">--->
							<input type='file' onchange="readURL(this);" id="file" style="display: none" name="image" accept="image/gif,image/jpeg,image/jpg,image/png" multiple="" data-original-title="upload photos">
						</label>
					</div>
				</div>
			</div>
			<div class="row bottom-section p-2 shadow-sm">
				<div class="col-sm-2">
				   <img src="image/profile.jpeg" class="rounded-circle img-fluid comment-profile">
				</div>
				<div class="col-sm-5">
				   <input type="text" name="name" placeholder="Write a reply ..." class="border-0 rounded-pill bg-light mt-2">
				</div>
				<div class="offset-1 col-sm-1">
				<i class="fa fa-smile-o mt-2" data-toggle="tooltip" data-placement="top" title="Insert an emoji" style="font-size:22px"></i>
					
				</div>
				<div class="col-sm-1">
					<label for="file">
						<i class="fa fa-camera mt-2"  data-toggle="tooltip" data-placement="top" title="Attach a Photo or Video" style="font-size:20px"></i>
						<!---<img id="blah" src="#">--->
						<input type='file' onchange="readURL(this);" id="file" style="display: none" name="image" accept="image/gif,image/jpeg,image/jpg,image/png" multiple="" data-original-title="upload photos">
					</label>
				</div>
			</div>			
		</div>
		
		<div class="modal-content" id="content2" style="display:none">
		    <div class="modal-header border-bottom-0">
				<div class="row">
					<div class="col-sm-3"> 
					    <img src="image/profile.jpeg" class="rounded-circle img-fluid group-profile">
					</div>
					<div class="col-sm-8">
						<a href="#"><h6 class="mt-1"><span class="font-weight-bold text-info">Sonali mishra </span></a> &nbsp; <i class="fa fa-caret-right" style="font-size:20px"></i> &nbsp; <a href="#"><span class="font-weight-bold text-info mt-4"> Abhishek </span></h6></a>
						<h6 class="mt-2"><span>2 Nov 2019</span> &nbsp; <i class='fas fa-user-friends'></i> </h6>
					</div>
					<!--<div class="col-sm-1">
					    <i class="fa fa-caret-down" style="font-size:22px" id="option"></i>
					</div>--->
				</div>
			</div>
			<div class="modal-body">
			    <div class="row">
				    <iframe width="560" height="315" src="https://www.youtube.com/embed/cajSxnjQC00" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
				</div>
				<hr>
				<div class="row mt-3">
					<div class="col-sm-7">
						<button type="button" class="btn btn-primary rounded-circle" data-toggle="modal" data-target="#exampleModal" id="like2"><i class="fa fa-thumbs-up" style="font-size:14px"></i></button>
						  
						<button type="button" class="btn btn-danger rounded-circle" data-toggle="modal" data-target="#exampleModal" id="love"><i class="fa fa-heart" style="font-size:14px"></i></button> 100
						
						<div class="row card bg-dark mt-1 w-75 p-2 " id="likelist2" style="display:none">
							<ul class="text-white" style="list-style:none">
								<li>Sonali Mishra</li> 
								<li>Shivam Saini</li>
								<li>Rahul Kumar</li>
								<li>Deepak Nauliya</li>
								<li>Ravish Beg</li>
							</ul>								
						</div>
						
						<div class="row card bg-dark mt-1 w-75 p-2 " id="lovelist" style="display:none">
							<ul class="text-white" style="list-style:none">
								<li>Sonali Mishra</li> 
								<li>Abhishek</li>
								
							</ul>								
						</div>
					</div>
					
					<div class="col-sm-5">
						 <h6 class="font-weight-normal" id="review"> <strong>104 Comments </strong></h6>
						<div class="row card bg-dark mt-1 w-100 p-2 " id="reviewlist" style="display:none">
							<ul class="text-white" style="list-style:none">
								<li>Sonali Mishra</li> 
								<li> prakhar Abhishek</li>
								<li> abhishek</li>
							</ul>								
						</div>
					</div>
				</div>
				<hr>
				<div class="row emoji p-2 shadow-sm  rounded-pill" id="gif" style="display:none">
					<div class="col-sm-2">
					   <img src="image/em1.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em2.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em3.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em4.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em5.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em6.gif" class="rounded-circle gif">
					</div>
	            </div>
				<div class="row">
					<div class="offset-1 col-sm-3">
						<div id="emoji"><i class="fa fa-thumbs-up" style="font-size:24px"></i> Like</div>
					</div>
					<div class="offset-3 col-sm-4" data-toggle="tooltip" data-placement="top" title="Leave a Comment">
						 <i class="fa fa-comments" style="font-size:24px"></i>   Comment
					</div>
				</div>
			</div>
		</div>
		
		<div class="modal-content" id="coment2" style="display:none">
		    <div class="modal-header border-bottom-0">
				<div class="row">
					<div class="col-sm-3"> 
					    <img src="image/profile.jpeg" class="rounded-circle img-fluid group-profile">
					</div>
					<div class="col-sm-8">
						<a href="#"><h6 class="mt-1"><span class="font-weight-bold text-info">Sonali Sona </span></a> &nbsp; <i class="fa fa-caret-right" style="font-size:20px"></i> &nbsp; <a href="#"><span class="font-weight-bold text-info mt-4"> Abhishek </span></h6></a>
						<h6 class="mt-2"><span>2 Nov 2019</span> &nbsp; <i class='fas fa-user-friends'></i> </h6>
					</div>
					<!--<div class="col-sm-1">
					    <i class="fa fa-caret-down" style="font-size:22px" id="option"></i>
					</div>--->
				</div>
			</div>
			<div class="modal-body">
			    <div class="row">
				    <iframe width="560" height="315" src="https://www.youtube.com/embed/cajSxnjQC00" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
				</div>
				<hr>
				<div class="row mt-3">
					<div class="col-sm-7">
						<button type="button" class="btn btn-primary rounded-circle" data-toggle="modal" data-target="#exampleModal" id="like1"><i class="fa fa-thumbs-up" style="font-size:14px"></i></button>
						  
						<button type="button" class="btn btn-danger rounded-circle" data-toggle="modal" data-target="#exampleModal" id="love1"><i class="fa fa-heart" style="font-size:14px"></i></button> 100
						
						<div class="row card bg-dark mt-1 w-75 p-2 " id="likelist1" style="display:none">
							<ul class="text-white" style="list-style:none">
								<li>Sonali Mishra</li> 
								<li>Shivam Saini</li>
								<li>Rahul Kumar</li>
								<li>Deepak Nauliya</li>
								<li>Ravish Beg</li>
							</ul>								
						</div>
						
						<div class="row card bg-dark mt-1 w-75 p-2 " id="lovelist1" style="display:none">
							<ul class="text-white" style="list-style:none">
								<li>Sonali Mishra</li> 
								<li>Abhishek</li>
								
							</ul>								
						</div>
					</div>
					
					<div class="col-sm-5">
						 <h6 class="font-weight-normal" id="review1"> <strong>104 Comments </strong></h6>
						<div class="row card bg-dark mt-1 w-100 p-2 " id="reviewlist1" style="display:none">
							<ul class="text-white" style="list-style:none">
								<li>Sonali Mishra</li> 
								<li> prakhar Abhishek</li>
								<li> abhishek</li>
							</ul>								
						</div>
					</div>
				</div>
				<hr>
				<div class="row emoji p-2 shadow-sm  rounded-pill" id="gif1" style="display:none">
					<div class="col-sm-2">
					   <img src="image/em1.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em2.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em3.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em4.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em5.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em6.gif" class="rounded-circle gif">
					</div>
	            </div>
				<div class="row">
					<div class="offset-1 col-sm-3">
						<div id="emoji1"><i class="fa fa-thumbs-up" style="font-size:24px"></i> Like</div>
					</div>
					<div class="offset-3 col-sm-4" data-toggle="tooltip" data-placement="top" title="Leave a Comment">
						 <i class="fa fa-comments" style="font-size:24px"></i>   Comment
					</div>
				</div>
				<div class="row mt-3">
					<div class="col-sm-2">
						<img src="image/profile.jpeg" class="rounded-circle img-fluid comment-profile">
					</div>
					<div class="col-sm-8 comnt rounded-pill">
						<h6 class="font-weight-bold mt-2 fs">Sonali Mishra</h6><span>Looking very very gorgeous</span>
					</div>
					<div class="col-sm-2">
						 <div class="dropdown mr-1">
							<i class="fa fa-caret-down mt-2 " id="dropdownMenuOffset" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-offset="10,20" data-toggle="tooltip" data-placement="top" title="Hide or report this" id="comment" ></i>
							<div class="dropdown-menu content-div" aria-labelledby="dropdownMenuOffset">
								<a class="dropdown-item" href="#"><button class="fs"> <i class="fa fa-close" style="color:gray"></i></button> Hide comment</a>
								<a class="dropdown-item" href="#">Find Support or report Comment</a>
							</div>
						</div>
					</div>
				</div>
						
				<div class="row emoji p-2 shadow-sm  rounded-pill" id="gif2" style="display:none">
					<div class="col-sm-2">
					   <img src="image/em1.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em2.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em3.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em4.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em5.gif" class="rounded-circle gif">
					</div>
					<div class="col-sm-2">
						<img src="image/em6.gif" class="rounded-circle gif">
					</div>
				</div>
						
				<div class="row mt-1">
					<div class="offset-3 col-sm-2">
						<a href="#"><h6 class="font-weight:normal text-info fs" id="textemoji">Like.<h6></a>
					</div>
					<div class="col-sm-2">
						<a href="#"><h6 class="font-weight:normal text-info fs" id="comnt">Reply.<h6></a>
					</div>
					<div class="col-sm-2">
						<a href="#"><h6 class="font-weight:normal text-dark">1w<h6></a>
					</div>
				</div>
						
				<div class="row reply p-2 shadow-sm  rounded-pill" id="msg1" style="display:none">
					<div class="col-sm-2">
					   <img src="image/profile.jpeg" class="rounded-circle img-fluid comment-profile">
					</div>
					<div class="col-sm-5">
					   <input type="text" name="name" placeholder="Write a reply ..." class="border-0 rounded-pill bg-light mt-2">
					</div>
					<div class="offset-1 col-sm-1">
					<i class="fa fa-smile-o mt-2" data-toggle="tooltip" data-placement="top" title="Insert an emoji" style="font-size:22px"></i>
						
					</div>
					<div class="col-sm-1">
						<label for="file">
							<i class="fa fa-camera mt-2"  data-toggle="tooltip" data-placement="top" title="Attach a Photo or Video" style="font-size:20px"></i>
							<!---<img id="blah" src="#">--->
							<input type='file' onchange="readURL(this);" id="file" style="display: none" name="image" accept="image/gif,image/jpeg,image/jpg,image/png" multiple="" data-original-title="upload photos">
						</label>
					</div>
				</div>
			</div>
			<div class="row bottom-section p-2 shadow-sm">
				<div class="col-sm-2">
				   <img src="image/profile.jpeg" class="rounded-circle img-fluid comment-profile">
				</div>
				<div class="col-sm-5">
				   <input type="text" name="name" placeholder="Write a reply ..." class="border-0 rounded-pill bg-light mt-2">
				</div>
				<div class="offset-1 col-sm-1">
				<i class="fa fa-smile-o mt-2" data-toggle="tooltip" data-placement="top" title="Insert an emoji" style="font-size:22px"></i>
					
				</div>
				<div class="col-sm-1">
					<label for="file">
						<i class="fa fa-camera mt-2"  data-toggle="tooltip" data-placement="top" title="Attach a Photo or Video" style="font-size:20px"></i>
						<!---<img id="blah" src="#">--->
						<input type='file' onchange="readURL(this);" id="file" style="display: none" name="image" accept="image/gif,image/jpeg,image/jpg,image/png" multiple="" data-original-title="upload photos">
					</label>
				</div>
			</div>			
		</div>
	
    </div>
 </div>
 
<script>
	$(document).ready(function(){
	  $("#like").hover(function(){
		  $("#likelist").toggle();
	 });
 });
 </script>
 
 <script>
	$(document).ready(function(){
	  $("#blue").hover(function(){
		  $("#bluelist").toggle();
	 });
 });
 </script>
 
 <script>
	$(document).ready(function(){
	  $("#redcomnt").hover(function(){
		  $("#redcomntlist").toggle();
	 });
 });
 </script>

 
 <script>
	$(document).ready(function(){
	  $("#bluelike").hover(function(){
		  $("#bluelikelist").toggle();
	 });
 });
 </script>
 
 <script>
	$(document).ready(function(){
	  $("#rev").hover(function(){
		  $("#revlist").toggle();
	 });
 });
 </script>
 
 <script>
	$(document).ready(function(){
	  $("#love").hover(function(){
		  $("#lovelist").toggle();
	 });
 });
 </script>
  <script>
	$(document).ready(function(){
	  $("#lov").hover(function(){
		  $("#lovlist").toggle();
	 });
 });
 </script>
 <script>
	$(document).ready(function(){
	  $("#comment").hover(function(){
		  $("#commentlist").toggle();
	 });
 });
 </script>
 
 <script>
	$(document).ready(function(){
	  $("#review").hover(function(){
		  $("#reviewlist").toggle();
	 });
 });
 </script>
 
 <script>
	$(document).ready(function(){
	  $("#like1").hover(function(){
		  $("#likelist1").toggle();
	 });
 });
 </script>
 
 <script>
	$(document).ready(function(){
	  $("#like2").hover(function(){
		  $("#likelist2").toggle();
	 });
 });
 </script>
 
 
 
 <script>
	$(document).ready(function(){
	  $("#love1").hover(function(){
		  $("#lovelist1").toggle();
	 });
 });
 </script>
 
 <script>
	$(document).ready(function(){
	  $("#review1").hover(function(){
		  $("#reviewlist1").toggle();
	 });
 });
 </script>
 
 <script>
     	$(document).ready(function(){
		  $("#emoji").hover(function(){
			  $("#gif").toggle();
		 });
	 });
 </script>
 
 <script>
     	$(document).ready(function(){
		  $("#emoji1").hover(function(){
			  $("#gif1").toggle();
		 });
	 });
 </script>
 
 <script>
	$(document).ready(function(){
	  $("#comnt").click(function(){
		  $("#msg1").toggle();
	 });
 });
 </script>
 
 <script>
     	$(document).ready(function(){
		  $("#textemoji").hover(function(){
			  $("#gif2").toggle();
		 });
	 });
 </script>
 
 <script>
$(document).on('click','#happy',function(){
	$("#content").show();
	$("#coment").hide();
	$("#content1").hide();
	$("#coment1").hide();
	$("#coment2").hide();
	$("#content2").hide();
	$('#exampleModal').modal('show');
})
</script>

<script>
$(document).on('click','#hapy',function(){
	$("#content1").show();
	$("#coment1").hide();
	$("#content").hide();
	$("#coment").hide();
	$("#coment2").hide();
	$("#content2").hide();
	$('#exampleModal').modal('show');
})
</script>

<script>
$(document).on('click','#videotext',function(){
	$("#content1").hide();
	$("#coment1").hide();
	$("#content").hide();
	$("#coment").hide();
	$("#content2").show();
	$("#coment2").hide();
	$('#exampleModal').modal('show');
})
</script>

<script>
	$(document).ready(function(){
	 
	  $("#comment").click(function(){
		 $("#content").hide();
		 $("#coment").show();
		  $("#content1").hide();
		 $("#coment1").hide();
		  $("#content2").hide();
		 $("#coment2").hide();
		 $('#exampleModal').modal('show');
			
	  });
	});
</script>

<script>
	$(document).ready(function(){
	 
	  $("#rev").click(function(){
		 $("#content1").hide();
		 $("#coment1").show();
		 $("#content").hide();
		 $("#coment").hide();
		  $("#content2").hide();
		 $("#coment2").hide();
		 $('#exampleModal').modal('show');
			
	  });
	});
</script>

<script>
	$(document).ready(function(){
	 
	  $("#redcomnt").click(function(){
		 $("#content1").hide();
		 $("#coment1").hide();
		 $("#content").hide();
		 $("#coment").hide();
		  $("#content2").hide();
		 $("#coment2").show();
		 $('#exampleModal').modal('show');
			
	  });
	});
</script>

<script>
	$(document).ready(function(){
	 
	  $("#model").click(function(){
		 $("#content").show();
		 $("#coment").hide();
		  $("#content1").hide();
		 $("#coment1").hide();
		  $("#content2").hide();
		 $("#coment2").hide();
		 $('#exampleModal').modal('show');
			
	  });
	});
</script>

<script>
	$(document).ready(function(){
	 
	  $("#model1").click(function(){
		 $("#content").hide();
		 $("#coment").hide();
		 $("#content1").show();
		 $("#coment1").hide();
		  $("#content2").hide();
		 $("#coment2").hide();
		 $('#exampleModal').modal('show');
			
	  });
	});
</script>

<script>
	$(document).ready(function(){
	 
	  $("#video").click(function(){
		 $("#content").hide();
		 $("#coment").hide();
		 $("#content1").hide();
		 $("#coment1").hide();
		  $("#content2").show();
		 $("#coment2").hide();
		 $('#exampleModal').modal('show');
			
	  });
	});
</script>
 
 
 
 