<!DOCTYPE html>
<html lang="en">
<head>
  <title>facebook post page </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src='https://kit.fontawesome.com/a076d05399.js'></script>
   <link href="css/style.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
  <body class="bg-light">
        <div class="container card mt-3">
	        <div class="row  bg-secondary p-2">
			    <div class="offset-1 col-md-11">
			  	    <h4 class="text-white"> <i class='fas fa-user-plus' style='font-size:24px'></i> About</h4>
                </div>				
			</div>
			<div class="row">
			    <div class="col-md-3 card">
				</div>
				<div class="col-md-9 card p-3">
				    <div class="row" id="work">
					    <div class="col-md-12">
							<h5 class="text-secondary mt-3">WORK</h5>
							<hr>
							<h5 class="text-info mt-3" id="add">Add a Workplace &nbsp; <span class="text-primary"> <i class='fas fa-arrow-alt-circle-down' style='font-size:24px'></i></span></h5> 
							<hr>
						</div>
					</div>
					<div class="row card bg-light pb-2" id="form1" style="display:none">
					    <div class="offset-1 col-sm-11 mt-4">
						    <form>
							    <div class="form-group">
									<div class="row">
										<div class="offset-1  col-sm-2">
											<label for="exampleInputEmail1">Company </label>
										</div>
										<div class="col-sm-6">
											<input type="name" class="form-control" id="company" aria-describedby="emailHelp" placeholder="where have you worked?">
										</div>
									</div>
								</div>
								
								<div class="form-group">
									<div class="row">
										<div class="offset-1  col-sm-2">
											<label for="exampleInputEmail1">Position </label>
										</div>
										<div class="col-sm-6">
											<input type="position" class="form-control" id="position" aria-describedby="emailHelp" placeholder="what is your job title?">
										</div>
									</div>
								</div>
								
								<div class="form-group">
									<div class="row">
										<div class="offset-1  col-sm-2">
											<label for="exampleInputEmail1">City/Town </label>
										</div>
										<div class="col-sm-6">
											<input type="city" class="form-control" id="city" aria-describedby="emailHelp">
										</div>
									</div>
								</div>
								
								<div class="form-group">
									<div class="row">
										<div class="offset-1 col-sm-2">
											<label for="exampleInputEmail1">Description </label>
										</div>
										<div class="col-sm-6">
												<textarea class="form-control" name="description"></textarea>
										</div>
									</div>
								</div>
								
								<div class="form-group">
									<div class="row">
										<div class="offset-1 col-sm-2">
											<label for="exampleInputEmail1">Time Period </label>
										</div>
										<div class="col-sm-6">
											<label class="small-box"> 
											  <input type="checkbox" checked="checked"> &nbsp; I currently work here
											  <span class="checkmark"></span>
											</label>
											<br>
											From <select>
												    <option value="volvo">2016</option>
												    <option value="saab">2017</option>
												    <option value="opel">2018</option>
												    <option value="audi">2019</option>
												</select> 
											to  <select>
												    <option value="volvo">2017</option>
												    <option value="saab">2018</option>
												    <option value="opel">2019</option>
												    <option value="audi">2020</option>
												</select>
										</div>
									</div>
								</div>
							</form>
							<hr>
							<div class="row">
							    <div class="col-sm-3">
								    <select class="bg-secondary text-white p-2 rounded" data-toggle="tooltip" data-placement="top" title="Public">
										<option value="volvo">Public</option>
										<option value="saab">Friends</option>
										<option value="opel">Only me</option>
										<option value="audi">Custom</option>
										<option value="audi">Close Friends</option>
								    </select> 
								</div>
								 <div class="col-sm-3">
								    <button type="button" class="btn btn-primary">Save Changes</button>
								</div>
								 <div class="col-sm-2">
								    <button type="button" class="btn btn-secondary" id="cancel1">Cancel</button>
								</div>
							</div>
						</div>
					</div>
										
					<div class="row" id="skills">
					    <div class="col-md-12">
							<h5 class="text-secondary mt-3">PROFESSIONAL SKILLS</h5>
							<hr>
							<h5 class="text-info mt-3" id="skill">Add a Professional Skill &nbsp; <span class="text-primary"> <i class='fas fa-arrow-alt-circle-down' style='font-size:24px'></i></span></h5> 
							<hr>
						</div>
					</div>
					
					<div class="row card bg-light pb-2" id="form2" style="display:none">
					    <div class="offset-1 col-sm-11 mt-4">
						    <form>
								<div class="form-group">
									<div class="row">
										<div class="  col-sm-3">
											<label for="exampleInputEmail1">Professional Skills </label>
										</div>
										<div class="col-sm-6">
											<input type="city" class="form-control" id="city" aria-describedby="emailHelp">
										</div>
									</div>
								</div>
							</form>
							<hr>
							<div class="row">
							    <div class="col-sm-3">
								    <select class="bg-secondary text-white p-2 rounded" data-toggle="tooltip" data-placement="top" title="Public">
										<option value="volvo">Public</option>
										<option value="saab">Friends</option>
										<option value="opel">Only me</option>
										<option value="audi">Custom</option>
										<option value="audi">Close Friends</option>
								    </select> 
								</div>
								 <div class="col-sm-3">
								    <button type="button" class="btn btn-primary">Save Changes</button>
								</div>
								 <div class="col-sm-2">
								    <button type="button" class="btn btn-secondary" id="cancel2">Cancel</button>
								</div>
							</div>
						</div>
					</div>
					
					<div class="row" id="university">
					    <div class="col-md-12">
							<h5 class="text-secondary mt-3">UNIVERSITY</h5>
							<hr>
							<h5 class="text-info mt-3" id="univ">Add a University&nbsp; <span class="text-primary"> <i class='fas fa-arrow-alt-circle-down' style='font-size:24px'></i></span></h5> 
							<hr>
						</div>
					</div>
					
					<div class="row card bg-light pb-2" id="form3" style="display:none">
					    <div class="offset-1 col-sm-11 mt-4">
						    <form>
							    <div class="form-group">
									<div class="row">
										<div class="offset-1  col-sm-2">
											<label for="exampleInputEmail1">school </label>
										</div>
										<div class="col-sm-6">
											<input type="name" class="form-control" id="company" aria-describedby="emailHelp" placeholder="what school/university did you attend ">
										</div>
									</div>
								</div>
								
								<div class="form-group">
									<div class="row">
										<div class="offset-1 col-sm-2">
											<label for="exampleInputEmail1">Time Period </label>
										</div>
										<div class="col-sm-6">
											<label class="small-box"> 
											  <input type="checkbox" checked="checked"> &nbsp; I currently work here
											  <span class="checkmark"></span>
											</label>
											<br>
											From <select>
												    <option value="volvo">2016</option>
												    <option value="saab">2017</option>
												    <option value="opel">2018</option>
												    <option value="audi">2019</option>
												</select> 
											to  <select>
												    <option value="volvo">2017</option>
												    <option value="saab">2018</option>
												    <option value="opel">2019</option>
												    <option value="audi">2020</option>
												</select>
										</div>
									</div>
								</div>
								
								<div class="form-group">
									<div class="row">
										<div class="offset-1 col-sm-2">
											<label for="exampleInputEmail1">Graduated </label>
										</div>
										<div class="col-sm-6">
											<label class="small-box"> 
											  <input type="checkbox" checked="checked">
											  <span class="checkmark"></span>
											</label>
										</div>
									</div>
								</div>
								
								<div class="form-group">
									<div class="row">
										<div class="offset-1 col-sm-2">
											<label for="exampleInputEmail1">Description </label>
										</div>
										<div class="col-sm-6">
												<textarea class="form-control" name="description"></textarea>
										</div>
									</div>
								</div>
								
								<div class="form-group">
									<div class="row">
										<div class="offset-1  col-sm-2">
											<label for="exampleInputEmail1">Concentrations </label>
										</div>
										<div class="col-sm-6">
											<input type="position" class="form-control" id="position" aria-describedby="emailHelp" >
										</div>
									</div>
								</div>
								
								<div class="form-group">
									<div class="row">
									    <div class="offset-1  col-sm-2">
											
										</div>
										<div class="col-sm-6">
											<input type="city" class="form-control" id="city" aria-describedby="emailHelp">
										</div>
									</div>
								</div>
								
								<div class="form-group">
									<div class="row">
									    <div class="offset-1  col-sm-2">
											
										</div>
										<div class="col-sm-6">
											<input type="city" class="form-control" id="city" aria-describedby="emailHelp">
										</div>
									</div>
								</div>
								
								<div class="form-group">
									<div class="row">
										<div class="col-sm-3">
											<label for="exampleInputEmail1">Attended for</label>
										</div>
										<div class="col-sm-9">
										
											<div class="checkbox c-radio needsclick ">
												<input type="radio" name="gender" value="male" class="btn1" checked="checked" id="post"> university<br>
											</div>
											<div class="checkbox c-radio needsclick">
												<input type="radio" name="gender" value="male" id="chk" onclick="ShowHideDiv(this)" > University (postgraduate)<br>
											</div>
										</div>
									</div>
								</div>
								
								<div class="form-group" id="degree" style="display:none">
									<div class="row">
										<div class="offset-1  col-sm-2">
											<label for="exampleInputEmail1">Gegree </label>
										</div>
										<div class="col-sm-6">
											<input type="position" class="form-control" id="position" aria-describedby="emailHelp" >
										</div>
									</div>
								</div>
							</form>
							<hr>
							<div class="row">
							    <div class="col-sm-3">
								    <select class="bg-secondary text-white p-2 rounded" data-toggle="tooltip" data-placement="top" title="Public">
										<option value="volvo">Public</option>
										<option value="saab">Friends</option>
										<option value="opel">Only me</option>
										<option value="audi">Custom</option>
										<option value="audi">Close Friends</option>
								    </select> 
								</div>
								 <div class="col-sm-3">
								    <button type="button" class="btn btn-primary">Save Changes</button>
								</div>
								 <div class="col-sm-2">
								    <button type="button" class="btn btn-secondary" id="cancel3">Cancel</button>
								</div>
							</div>
						</div>
					</div>
					
					<div class="row" id="school">
					    <div class="col-md-12">
							<h5 class="text-secondary mt-3">HIGH SCHOOL</h5>
							<hr>
							<h5 class="text-info mt-3" id="high">Add a High School &nbsp; <span class="text-primary"> <i class='fas fa-arrow-alt-circle-down' style='font-size:24px'></i></span></h5> 
							<hr>
						</div>
					</div>
					
					<div class="row card bg-light pb-2" id="form4" style="display:none">
					    <div class="offset-1 col-sm-11 mt-4">
						    <form>
							    <div class="form-group">
									<div class="row">
										<div class="offset-1  col-sm-2">
											<label for="exampleInputEmail1">school </label>
										</div>
										<div class="col-sm-6">
											<input type="name" class="form-control" id="company" aria-describedby="emailHelp" placeholder="what school/university did you attend ">
										</div>
									</div>
								</div>
								
								<div class="form-group">
									<div class="row">
										<div class="offset-1 col-sm-2">
											<label for="exampleInputEmail1">Time Period </label>
										</div>
										<div class="col-sm-6">
											<label class="small-box"> 
											  <input type="checkbox" checked="checked"> &nbsp; I currently work here
											  <span class="checkmark"></span>
											</label>
											<br>
											From <select>
												    <option value="volvo">2016</option>
												    <option value="saab">2017</option>
												    <option value="opel">2018</option>
												    <option value="audi">2019</option>
												</select> 
											to  <select>
												    <option value="volvo">2017</option>
												    <option value="saab">2018</option>
												    <option value="opel">2019</option>
												    <option value="audi">2020</option>
												</select>
										</div>
									</div>
								</div>
								
								<div class="form-group">
									<div class="row">
										<div class="offset-1 col-sm-2">
											<label for="exampleInputEmail1">Graduated </label>
										</div>
										<div class="col-sm-6">
											<label class="small-box"> 
											  <input type="checkbox" checked="checked">
											  <span class="checkmark"></span>
											</label>
										</div>
									</div>
								</div>
								
								<div class="form-group">
									<div class="row">
										<div class="offset-1 col-sm-2">
											<label for="exampleInputEmail1">Description </label>
										</div>
										<div class="col-sm-6">
												<textarea class="form-control" name="description"></textarea>
										</div>
									</div>
								</div>
												
							</form>
							<hr>
							<div class="row">
							    <div class="col-sm-3">
								    <select class="bg-secondary text-white p-2 rounded" data-toggle="tooltip" data-placement="top" title="Public">
										<option value="volvo">Public</option>
										<option value="saab">Friends</option>
										<option value="opel">Only me</option>
										<option value="audi">Custom</option>
										<option value="audi">Close Friends</option>
								    </select> 
								</div>
								 <div class="col-sm-3">
								    <button type="button" class="btn btn-primary">Save Changes</button>
								</div>
								 <div class="col-sm-2">
								    <button type="button" class="btn btn-secondary" id="cancel4">Cancel</button>
								</div>
							</div>
						</div>
					</div>
					
				</div>
			</div>
	    </div>
		
<script>
   $(document).ready(function(){
	  $("#add").click(function(){
		 $("#form1").show();
	 });
 });
</script>	

<script>
   $(document).ready(function(){
	  $("#cancel1").click(function(){
		 $("#work").show();
		 $("#form1").hide();
	 });
 });
</script>

<script>
   $(document).ready(function(){
	  $("#skill").click(function(){
		 $("#form2").show();
	 });
 });
</script>	

<script>
   $(document).ready(function(){
	  $("#cancel2").click(function(){
		 $("#skills").show();
		 $("#form2").hide();
	 });
 });
</script>

<script>
   $(document).ready(function(){
	  $("#univ").click(function(){
		 $("#form3").show();
	 });
 });
</script>	

<script>
   $(document).ready(function(){
	  $("#cancel3").click(function(){
		 $("#university").show();
		 $("#form3").hide();
	 });
 });
</script>

<script>
   $(document).ready(function(){
	  $("#high").click(function(){
		 $("#form4").show();
	 });
 });
</script>	

<script>
   $(document).ready(function(){
	  $("#cancel4").click(function(){
		 $("#school").show();
		 $("#form4").hide();
	 });
 });
</script>

<script>
   $(document).ready(function(){
	  $("#chk").click(function(){
		 $("#degree").show();
	 });
 });
</script>	

<script>
   $(document).ready(function(){
	  $("#post").click(function(){
		 $("#degree").hide();
	 });
 });
</script>	
	
	
		
  </body>
</html>