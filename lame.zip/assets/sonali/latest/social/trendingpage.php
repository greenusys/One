<!DOCTYPE html>
<html lang="en">
<head>
  <title>Favourite page </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src='https://kit.fontawesome.com/a076d05399.js'></script>
   <link href="css/style.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
<div class="container card mt-5 w-50 shadow-lg p-4">
    <h5 class="font-weight-bold text-dark">Trending Posts</h5>
	
	<div class="row bg-light border w-100 mt-4 mx-auto p-2">
	    <div class="col-sm-3">
		    <img src="image/img2.jpg"  class="img-fluid trend-img">
		</div>
		<div class="col-sm-9">
		   <h6 class="text-info">The Best Moment For Golden Global Awards</h6>
		     <h6 class="font-weight:normal">Google.com</h6> 
                <h6 class="font-weight:normal">I wish you a day filled with great fun and a year filled with true happiness! Let yourself do everything that you like most in life</h6>			 
		</div>
	</div>
	<hr>
	<div class="row mt-1">
		<div class="col-sm-2">
		   <img src="image/img6.jpg" class="rounded-circle img-fluid image-post">
		</div>
		<div class="col-sm-8">
			<a href="#"><h6 class="mt-2"><span class="font-weight-bold text-info mt-4">Sonali Sona </span></a> </h6>
			<h6 class="font-weight-normal">Actress/Director</h6>
		</div>
	</div>
    <div class="row mt-2">
		<div class="offset-3 col-md-6">
		    <img src="image/img3.jpg"  class="rounded img-thumbnail trend-image">
		</div>
	</div>
	<div class="row mt-3" >
		<div class="offset-2 col-sm-10">
			<button class="text-primary" > Like</button>
			<button class="text-primary" > Comment </button>
			<button class="text-primary" > Share </button> &nbsp; 
			<span class="text-primary"><i style="font-size:24px" class="fa">&#xf087;</i> 5,0778 </span> &nbsp;
			<span class="text-primary"><i style="font-size:24px" class="fa">&#xf0e6;</i> 84 </span> &nbsp;
			<span class="text-primary"><i class="fa fa-file-text-o"></i> 25 </span> &nbsp;
			<span class="text-primary"> January 6 at 10:20am.</span>
		</div>
    </div>
	<hr>
	<div class="row mt-1">
		<div class="col-sm-2">
		   <img src="image/img4.jpg" class="rounded-circle img-fluid image-post">
		</div>
		<div class="col-sm-8">
			<a href="#"><h6 class="mt-2"><span class="font-weight-bold text-info mt-4">ABC News</span></a> </h6>
			<h6 class="font-weight:normal">I wish you a day filled with great fun and a year filled with true happiness! Let yourself do everything that you like most in life</h6>		
		</div>
	</div>
    <div class="row mt-2">
		<div class="offset-2 col-md-6 ">
		   <iframe width="560" height="315" src="https://www.youtube.com/embed/6H02XiHCCtQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
		</div>
	</div>
	<div class="row mt-3" >
		<div class="offset-2 col-sm-10">
			<button class="text-primary" > Like</button>
			<button class="text-primary" > Comment </button>
			<button class="text-primary" > Share </button> &nbsp; 
			<span class="text-primary"><i style="font-size:24px" class="fa">&#xf087;</i> 5,0778 </span> &nbsp;
			<span class="text-primary"><i style="font-size:24px" class="fa">&#xf0e6;</i> 84 </span> &nbsp;
			<span class="text-primary"><i class="fa fa-file-text-o"></i> 25 </span> &nbsp;
			<span class="text-primary"> January 6 at 10:20am.</span>
		</div>
    </div>
	<hr>
</div>

<script>
	$(document).ready(function(){
	  $("#lov").hover(function(){
		  $("#lovlist").toggle();
	 });
 });
 </script>
 
 <script>
	$(document).ready(function(){
	  $("#likes").hover(function(){
		  $("#likeslist").toggle();
	 });
 });
 </script>
 
 <script>
	$(document).ready(function(){
	  $("#comment").hover(function(){
		  $("#commentlist").toggle();
	 });
 });
 </script>
 
</body>
</html>



 
 