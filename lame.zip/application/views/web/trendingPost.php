
<div class="container card mt-5 w-50 shadow-lg p-4">
    <h5 class="font-weight-bold text-dark">Trending Posts</h5>
    <hr>
    
    <?php
        // print_r($Trending);
        foreach($Trending as $p_ost){
            if($p_ost['post_type']==0){
                ?>
                      <div class="row bg-light border w-100 mt-4 mx-auto p-2">
                        <div class="col">
                            <div class="row">
                                <div class="col-sm-2">
                                    <img src="<?=base_url('assets/img/Profile_Pic/').$p_ost['profile_pic']?>" onerror="this.src='<?=base_url()?>assets/img/Profile_Pic/default.png';" class="img-fluid rounded-circle" width="30px" height="30px">
                                </div>
                                <div class="col-sm-10">
                                <a href="#"><h6 class="mt-2"><span class="font-weight-bold text-info mt-4"><?=$p_ost['posted_by']?> </span></a> </h6>
                                <h6>T<?=$p_ost['post']?></h6>
                                    <!-- <h6 class="font-weight:normal">Google.com</h6> 
                                        <h6 class="font-weight:normal">I wish you a day filled with great fun and a year filled with true happiness! Let yourself do everything that you like most in life</h6>			  -->
                                </div>
                            </div>
                            <div class="row mt-3" >
                                <div class="offset-2 col-sm-10">
                                    <!-- <button class="btn btn-success " > Like</button>
                                    <button class="btn btn-success " > Comment </button>
                                    <button class="btn btn-success " > Share </button> &nbsp;  -->
                                    <a href="javascript:void(0)"><i style="font-size:24px" class="fa">&#xf087;</i> 5,0778 </a> &nbsp;
                                    <a href="javascript:void(0)"><i style="font-size:24px" class="fa">&#xf0e6;</i> 84 </a> &nbsp;
                                    <a href="javascript:void(0)"><i class="fa fa-file-text-o"></i> 25 </a> &nbsp;
                                    <span class="text-primary"> January 6 at 10:20am.</span>
                                </div>
                            </div>
                        </div>   
                    </div>
                <?php
            }elseif($p_ost['post_type']==1){
                ?>
                    <div class="row bg-light border w-100 mt-4 mx-auto p-2">
                        <div class="col">
                            <div class="row mt-1">
                                <div class="col-sm-2">
                                <img src="<?=base_url('assets/img/Profile_Pic/').$p_ost['profile_pic']?>" onerror="this.src='<?=base_url()?>assets/img/Profile_Pic/default.png';" class="img-fluid rounded-circle" width="30px" height="30px">
                                </div>
                                <div class="col-sm-8">
                                    <a href="#"><h6 class="mt-2"><span class="font-weight-bold text-info mt-4"><?=$p_ost['posted_by']?> </span></a> </h6>
                                    <h6 class="font-weight-normal">Actress/Director</h6>
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="offset-3 col-md-6">
                                    <img src="<?=base_url('assets/uploads/images/').$p_ost['post_files']?>"  class="rounded img-thumbnail trend-image">
                                </div>
                            </div>
                            <div class="row mt-3" >
                                <div class="offset-2 col-sm-10">
                                    <!-- <button class="btn btn-success " > Like</button>
                                    <button class="btn btn-success " > Comment </button>
                                    <button class="btn btn-success " > Share </button> &nbsp;  -->
                                    <a href="javascript:void(0)"><i style="font-size:24px" class="fa">&#xf087;</i> 5,0778 </a> &nbsp;
                                    <a href="javascript:void(0)"><i style="font-size:24px" class="fa">&#xf0e6;</i> 84 </a> &nbsp;
                                    <a href="javascript:void(0)"><i class="fa fa-file-text-o"></i> 25 </a> &nbsp;
                                    <span class="text-primary"> January 6 at 10:20am.</span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php
            }else{
                ?>
                    <div class="row mt-2" id="video">
                        <div class="col">
                            <div class="row mt-1">
                                <div class="col-sm-2">
                                <img src="<?=base_url('assets/img/Profile_Pic/').$p_ost['profile_pic']?>" onerror="this.src='<?=base_url()?>assets/img/Profile_Pic/default.png';" class="img-fluid rounded-circle" width="30px" height="30px">
                                </div>
                                <div class="col-sm-8">
                                    <a href="#"><h6 class="mt-2"><span class="font-weight-bold text-info mt-4"><?=$p_ost['posted_by']?></span></a> </h6>
                                    <h6 class="font-weight:normal">I wish you a day filled with great fun and a year filled with true happiness! Let yourself do everything that you like most in life</h6>		
                                </div>
                            </div>
                            <div class="row">
                                <div class="offset-2 col-md-6 ">
                                    <!-- <iframe width="560" height="315" src="https://www.youtube.com/embed/6H02XiHCCtQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe> -->
                                        <video width="560" height="315" controls>
                                            <source src="<?=base_url('assets/uploads/videos/').$p_ost['post_files']?>" type="video/mp4">
                                            <source src="movie.ogg" type="video/ogg">
                                            Your browser does not support the video tag.
                                        </video> 
                                </div>
                            </div>
                            <div class="row mt-3" >
                                <div class="offset-2 col-sm-10">
                                    <!-- <button class="btn btn-success " > Like</button>
                                    <button class="btn btn-success " > Comment </button>
                                    <button class="btn btn-success " > Share </button> &nbsp;  -->
                                    <a href="javascript:void(0)"><i style="font-size:24px" class="fa">&#xf087;</i> 5,0778 </a> &nbsp;
                                    <a href="javascript:void(0)"><i style="font-size:24px" class="fa">&#xf0e6;</i> 84 </a> &nbsp;
                                    <a href="javascript:void(0)"><i class="fa fa-file-text-o"></i> 25 </a> &nbsp;
                                    <span class="text-primary"> January 6 at 10:20am.</span>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                <?php
            }
        }
    ?>
  
   
	
</div>

<script>
	$(document).ready(function(){
	  $("#lov").hover(function(){
		  $("#lovlist").toggle();
	 });
 });
 </script>
 
 <script>
	$(document).ready(function(){
	  $("#likes").hover(function(){
		  $("#likeslist").toggle();
	 });
 });
 </script>
 
 <script>
	$(document).ready(function(){
	  $("#comment").hover(function(){
		  $("#commentlist").toggle();
	 });
 });
 </script>
 



 
 