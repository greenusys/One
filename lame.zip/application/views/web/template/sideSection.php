
<!------------main _container------>
<style type="text/css">
  .activi{
    text-decoration: none !important;
  }
  .activi:hover{
    color: orange;
  }
  .ranUse{
      font-size: 12px;
    }
</style>
<section class="container">
  <div class="row">
    <!-------------activity  start---->
    <div class="col-md-3 p-1 bg_gr">
      <div class="card ">
        <div class="card-body ">
          <h4 class="text-center">Recent Activity</h4>
          <hr>
          <div class="">
            <ul class="list-unstyled">
              <?php
                foreach ($FriendsActivity as $activity) {
                  # code...
                  ?>
                    <li><a href="<?=base_url('Profile/').$activity->user_id?>" class="activi"><strong><?=$activity->full_name?></strong> <small><?=$activity->activity_?></small></a></li>
                  <?php
                }
              ?>
              
              <!-- <li><span><i class="far fa-sticky-note"></i>   </span><strong>Deepak</strong> <small>update his picture</small></li>
              <li><span><i class="fas fa-pen-alt"></i>  </span><strong>Rahul</strong> <small>update his picture</small></li>
              <li><span><i class="fas fa-edit"></i>  </span><strong>Umesh</strong> <small>update his picture</small></li> -->
            </ul>
          </div>
          <div class="text-center">
            <a href="<?=base_url()?>Test/ActivityLogs"> <span>See More <i class="fas fa-angle-double-down"></i></span></a>
          </div>
        </div>
      </div>
      <div class="card">
        <div class="card-body">
          <h4 class="text-center">Who to follow?</h4>
          <hr>
          <ul class="list-unstyled d-flex">
            <?php
              // print_r($RandomPeople);
             
              foreach ($RandomPeople as $user) {
                $nameArrI=explode(" ",$user->full_name);
                ?>
                  <li class="text-center">
                    <a href="<?=base_url('Profile/').$user->user_id?>">
                    <img class="rounded-circle " src="<?=base_url()?>assets/img/Profile_Pic/<?=$user->profile_picture?>" onerror="this.src='<?=base_url()?>assets/img/Profile_Pic/default.png';" width="60px" height="60px">
                    <span class="ranUse"><?=$nameArrI[0]?></span></a>
                  </li>
                <?php
              }
            ?>
          </ul>
          <div class="text-center">
             <a href="<?=base_url()?>test/SuggestionFriends" ><span>See More <i class="fas fa-angle-double-down"></i></span></a>
          </div>
        </div>
      </div>
      <div class="card">
        <div class="card-body">
            <h4 class="text-center">Page Feed</h4>
            <hr>
            <div class="row page_st">
              <?php
               // print_r($AllPosts);
               // die;
                foreach ($AllPosts as $post) {
                  # code...
               //    print_r($post);
               // die;
                  if($post['post_type']==1){
                    ?>
                    <a href="<?=base_url('Post/viewPost/').$post['post_id']?>">
                      <div class="col-md-4 mt-2 px-1">
                        <img src="assets/uploads/images/<?=$post['post_files']?>" class="">
                      </div>
                    </a>
                    <?php
                  }else if($post['post_type']==2){
                    ?>
                    <a href="<?=base_url('Post/viewPost/').$post['post_id']?>">
                      <div class="col-md-4 mt-2 px-1">
                        <video  width="60" >
                          <source src="<?=base_url()?>assets/uploads/videos/<?=$post['post_files']?>" type="video/mp4">
                         
                          Your browser does not support the video tag.
                        </video>
                      </div>
                    </a>
                    <?php
                  }
                }
              ?>
              
            </div>
        </div>
      </div>
    </div>
    <!-------------activity end---->