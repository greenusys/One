

<style type="text/css">
	/** {
	box-sizing: border-box;
	-moz-box-sizing: border-box;
	-webkit-box-sizing: border-box;
}*/
/*body {
	background-color: #f1f1f1;
	display: flex;
	font-family: 'Lato', sans-serif;
	font-size: 0.875rem;
	font-weight: 400;
	color: #2c3e50;
	height: 100vh;
	overflow-y: hidden;
}*/
/* CUSTOM SCROLLBAR FOR CHATBOX */
.senDMes{

    border: 1px solid #b1b1b1;
    background: border-box;

}
.mBar{

}
.chats{
	/*border: 1px solid red;*/
	/*background: cadetblue;*/
}
.newMs{
	border: 1px solid red;
}
.chats::-webkit-scrollbar { width: 0.125rem; }
.chats::-webkit-scrollbar-thumb { background: #CFD8DC; }
.chats::-webkit-scrollbar-thumb:hover { background: #B0BEC5; }
/* INPUT TEXT PLACEHOLDER CUSTOMIZE */
::-webkit-input-placeholder { color: #B0BEC5; }
::-moz-placeholder { color: #B0BEC5; }
:-ms-input-placeholder { color: #B0BEC5; }
:-moz-placeholder { color: #B0BEC5; }

#viewport { 
	position: fixed;
    display: flex;
    flex: 1;
    justify-content: center;
    align-items: center;
    bottom: 0px;
}
#viewport > .chatbox {
	position: relative;
	display: table;
	float: left;
	margin-left: 2px;

	width: 20rem;
	height: 22rem;
	background-color: white;
	box-shadow: 0 0.25rem 2rem rgba(38,50,56, 0.1);
	overflow: hidden;
	   -webkit-transition:height, 0.5s linear;
    -moz-transition: height, 0.5s linear;
    -ms-transition: height, 0.5s linear;
    -o-transition: height, 0.5s linear;
    transition: height, 0.5s linear;
}

.viewport_ht2{
	height: 2rem !important;
	    margin-top: 49.5%;
	  -webkit-transition:height, 0.5s linear;
    -moz-transition: height, 0.5s linear;
    -ms-transition: height, 0.5s linear;
    -o-transition: height, 0.5s linear;
    transition: height, 0.5s linear;
}
#viewport > .chatbox > .chats {
	position: absolute;
	top: 38px; left: 0; bottom: 0; right: 0;	
	display: table-cell;
	vertical-align: bottom;
	padding: 0.3rem;
	/*
	overflow: auto;*/
}

#viewport > .chatbox > .chats > .chat_ud{
	/*bottom: 83px; */
    overflow: auto;
    height: 16rem;
    /* margin-bottom: 22px; */
    position: absolute;
    width: 100%;
    display: table-cell;
    vertical-align: bottom;
}
ul { padding: 0; }
ul > li {
	position: relative;
	list-style: none;
	display: block;
	/*margin-top: 1.5rem;*/
	/*margin: 1rem 0;*/
	transition: 0.5s all;
}
ul > li:after {
	display: table;
	content: '';
	clear: both;
}
.msg {		
	max-width: 85%;
	display: inline-block;
	padding: 0.5rem 1rem;
	line-height: 1rem;
	min-height: 2rem;
	font-size: 0.875rem;
	border-radius: 1rem;
	margin-bottom: 0.5rem;
	word-break: break-all;
	text-transform: capitalize;
}
.msg.him {
	float: left;
	background-color: #E91E63;
	color: #fff;
	border-bottom-left-radius: 0.125rem;
}
.msg.you {
	float: right;
	background-color: #ECEFF1;
	color: #607D8B;
	border-bottom-right-radius: 0.125rem;
}
.msg.load { 
	background-color: #F8BBD0; 
	border-bottom-left-radius: 0.125rem;
}
.msg > span {
	font-weight: 500;
	position: absolute;
}
.msg > span.partner {
	color: #8c9ba2;
	font-size: 0.7rem !important;
	top: 0;
	font-size: 0.675rem;
	margin-top: -1rem;
}
.msg > span.time {
	    color: #00b1ff;
    font-size: 0.6rem;
    bottom: -0.35rem;
    display: none;

}
.msg:hover span.time { display: block; }
.msg.him > span { left: 0;	 }
.msg.you > span {	right: 0; }
.sendBox {
	position: absolute;
    left: 0;
    width: 100%;
    background: white;
    bottom: 0px;
        box-shadow: -2px 0px 5px 1px #00000057;
}
.sendBox input {
	font-family: 'Lato', sans-serif;
	font-size: 0.875rem;
	display: block;
	width: 100%;
	border: none;
	padding: 0.75rem 0.75rem;
	line-height: 1.25rem;
	border-top: 0.125rem solid #ECEFF1;
	transition: 0.5s ease-in-out;
}
input:hover,
input:focus,
input:active { 
	outline: none!important; 
/*	border-top: 0.125rem solid #E91E63;*/
}

/*  LOADING MESSAGE CSS */
.load .dot {
	display: inline-block;
	width: 0.375rem;
	height: 0.375rem;
	border-radius: 0.25rem;
	margin-right: 0.125rem;
	background-color: rgba(255,255,255,0.75);	
}
.load .dot:nth-last-child(1) {animation: loadAnim 1s .2s linear infinite;}
.load .dot:nth-last-child(2) {animation: loadAnim 1s .4s linear infinite;}
.load .dot:nth-last-child(3) {animation: loadAnim 1s .6s linear infinite;}
@keyframes loadAnim {
    0 {transform: translate(0,0);}
    25% {transform: translate(0,-0.25rem);}
    50% {transform: translate(0,0);}
}



.emojionearea-standalone {
  float: right;
}
.emojionearea{
    width:100% !important;
}
 .divOutside {
            height: 20px;
            width: 20px;
            background-position: -1px -26px;
            background-repeat: no-repeat;
            background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABcAAABuCAYAAADMB4ipAAAHfElEQVRo3u1XS1NT2Rb+9uOcQF4YlAJzLymFUHaLrdxKULvEUNpdTnRqD532f+AHMLMc94gqR1Zbt8rBnUh3YXipPGKwRDoWgXvrYiFUlEdIkPPYZ/dAkwox5yQCVt/bzRrBPnt9e+211/etFeDQDu3ArL+/X37OeqmRWoH7+vpItfWawStF1tfXR+zW9xW5ne0p8loOcAKuCdwpRft60C8a+X5zTvebCqcAvmidf1GGHtqhHdpf1qqKzsrKipyensbi4iKWl5cBAMFgEG1tbYhGo2hpadlbmxseHpaDg4MAgI6ODng8HgBAPp/H/Pw8AODatWvo7e2tvUHrui7v3r2L+fl5XL58GVeuXIHH49m1N5/Py0ePHmF0dBQdHR24desWVFXdtYdXAn/48CHm5+dx8+ZNRKPRigEUDpuenpb3799H4YaOnWh5eVmOj48jFoshGo0STdPkwMCAXF5elqV7BgYGpKZpMhqNklgshrGxMbx580Y6gicSCTDGEIvFAADpdBqpVArJZLK4J5lMIpVKIZ1OAwBisRgYY0gkEs6Rp1IphMNh+Hw+AgCGYQAANE0r7in8Xfjm8/lIOBzGq1evnMHX19fR1NRU/D8UCoFzjnA4XFwLh8PgnCMUChXXmpqakM1mUfVBS62xsZHk83lZWi1nz579ZA0AhBDO4A0NDchkMsWSJIRAURRiVy26rktVVUkmk0EgEHAGP3XqFKamppDP56Vpmrhz5w5u374t/X4/OP+w3TRNZLNZ6LoO0zSRz+dlf38/Ll686Jzz8+fPQwiBeDwOt9tNrl+/jkwmU6yaQpVkMhncuHEDbrebxONxCCEQiUScIw8Gg+TBgwdyZGQEyWRSdnV1kVQqJYeGhrC6ugrGGEKhEHp7e3Hy5EmSTCblvXv30NPTg2AwSA6M/vF4HCMjI7b0/yzh8vv9AIBsNrt34aokuQsLC7skt729varkHtqftUFf++FHsrq0QN3eBvp68Tfvf9Mv12oFCYU7G//e9nVuO7dpNbe2W4M//yQr0p8yRvyBo1Zr++lwLcCt7afD/sBRizJGavrB1dDYYh47Htrq+Kb7jBNwxzfdZ44dD201NLaYVUkU7ozQpuAJBkARwnRZpunN5zaa5hJjiXLH05GeiMd7JEM5zzHGNQBGZvk/Iv0yYVWMvK0zKk1Dl6ahW5RQobjqdjy+wEZn9PKF0n2d0csXPL7AhuKq26GECtPQLdPQZVtn1LlB69p7yRVVSEiDEGJwRd12e4+8PR3piRQidnuPvOWKuk0IMSSkwRVV6Np7WVVbSqvGsgSnlKkAFNPQXdrOtuKqcxtcUTUAhmUJnVJmlleJo3CVHmAaOlPUOmYJkxFKibQsSRkXhr4juKIKO2BHVSwcoLrqCVdUYho6K3YYRRWmoUtdey/tgKtK7rUffiQAsLq08MnbNLe2WwBgB/zHzueFyD8nwlIfbvdx8eU0WV1aKD1cVAMs9+F2j9gUPEEKemEJIe3AnXy4XfkBoNKSZHNthWfX31EA69VKttyHVyIOY1wRwmS6tqNsrr31vXo5k/bUu4gT2cp9lhbm0rzCJpeUUrE0vS63+c7/6uXMbDUWl/ssLczNFrVFddUT09AZpUy1LKvO0DVfPrfR9HxqfNbuEe185l9MFX3o6tIC5YpKFLWOfdQQ93Zu49j0+FDCDtjOp1yaOQCYhs4Y40wI05XfWj8yPT40Ua2ey33mEmMTtp2IUEq0nW3FKeJPGPjRp1Iz2QUuLUu66txG9NLVSK3gBZ+C1lcE54oqKOOCK6rm8QU2unu+u1ANuNynvFsBAG1ubbdMQ5eGviMAFDuP0w3sfMpvQEtb24fOQncU1bXl8R7JnOu+ZNv97XxKJwY6+PNPsrm13drObVqUMlMIU5OWpVHOc96Go5lTnV2fzC/VfAozD7HTCa6olBBa1Imlhbmq2lLuQ5xaW6nCPfnln0Yt7bDUhzhps8cfKH5//uTXmvS81OeLdqI/ZoROzSZrHqG/OvOPzxuhK5VgJTvV2bW3EdqJRABwrvvS/kfoSkoZvXT1YEbociHr7vnuYEfogpBFL109HKH/h0fomnXg3Lff79r7/MmvVbWG7gX4QObzc99+Tz7mHKah05KcW6ahQ9feS6cbMCdgt7eBWJagjCuUAC5tZzuouuo0Spm0hElc9R4cbf4bVl8v1p6WUmCuqEwIs34ruxaeeTy4uJVd67As08UVlVmWoG5vA7FLG3WMmHEupVTyW+vh2cn4DADMTsaTuc21LiGEhzHOnQ6gNtMrJSBMCKHkNt999WLi0S7hejEZH81n174WpukiIMw0dKq66p3Bw50RwhUVXFGJKUy28Xal48VkfKrSlWenhsc23q2cEB9SR7iiItwZIbbgHn8AlDFCCMW7laXjqZnHjkNpaubJzNuVpWZCKChjxOMPVH/QlaW0f/G3ZLqWWl6ce/bvlddp7yFD/w8Z+njoX1+GoZMjgzMAMDkyeLAMnRh+uKveJ0YGD4ahEyODFRk6OfrL/hj67GnckaHPng7vjaGzyYmaGDr77KktQ38H8tqx8Wja+WIAAAAASUVORK5CYII=);
}
.emojionearea-button
{
    opacity:0 !important;
}

/*.emojionearea .emojionearea-button.active + .emojionearea-picker-position-left, .emojionearea .emojionearea-button.active + .emojionearea-picker-position-right{
  margin-right: 0px !important;
  top: -280px !important;
}*/
.name__{
	padding: 7px;
    top: 0px;
    color: white;
    background: darkred;
    z-index: 704;
    position: absolute;
    width: 100%;
}
</style>
<script src="https://cdnjs.cloudflare.com/ajax/libs/emojionearea/3.4.1/emojionearea.min.js"></script>
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/emojionearea/3.4.1/emojionearea.css">
<script type="text/javascript">
		
		   
		$(document).on('click','.chatFriend',function(){
			var f_Name=$(this).attr('d-name');
			var f_Id=$(this).attr('d-fNd');
			getConversation(f_Id);

			var parentString = '<div class="chatbox " id="'+f_Id+'"><div class="name__"><span clas="f_Nm">'+f_Name+'</span><span class="menus_ float-right"> <a href="javascript:void(0)" class="text-white minimize"><i class="fa fa-window-minimize" aria-hidden="true"></i></a><span class="m-3 close_chat"><i class="fa fa-times" aria-hidden="true"></i></span></span></div>'+
				 '<div class="chats"><div class="chat_ud">'+
				 '<ul id="f'+f_Id+'"></ul>'+
				 '</div>'+
				 '<div class="sendBox">'+
				 '<input type="text" placeholder="Type Your Message Here..." class="newMs" d-Fr="'+f_Id+'" ></div>';	
				$('#viewport').append(parentString);
				
				$("#emojionearea1").emojioneArea({
	            
	                pickerPosition: "right",
	                tonesStyle: "bullet",
	                events: {
	                    keyup: function (editor, event) {
	                        // console.log(editor.html());
	                        // console.log(this.getText());
	                    }
	                }
	            });
				var chatDiv=$("#f"+f_Id).parent();
				chatDiv.stop().animate({ scrollTop: chatDiv[0].scrollHeight}, 200);
	            	


		});
		$(document).on('click','#divOutside2',function () {
            $('.emojionearea-button').click()
        });  
		$(document).on('keypress','.newMs',function(e){
			var this_element=$(this);
			var message=this_element.val();
			if(e.which == 13) {
				var frd=this_element.attr('d-Fr');
				sendMess(message,frd,this_element);
				this_element.val("");
				var chatDiv=$("#f"+frd).parent();
				chatDiv.stop().animate({ scrollTop: chatDiv[0].scrollHeight}, 1000);
			}
		});
		
		$(document).on("click",".minimize",function(){
			var ele =$(this);
			ele.parent().parent().parent().toggleClass("viewport_ht2");

		})
		$(document).on("click",".close_chat",function(){
			var ele =$(this);
			ele.parent().parent().parent().remove();

		})
	// HELPER FUNCTION
	// function getDateTime (t) {
	// 	var month 	= ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];	
	// 	var d 		= new Date(t/1000),
	// 		 month 	= (month[d.getMonth()]),
	// 		 day 		= d.getDate().toString(),
	// 		 hour 	= d.getHours().toString(),
	// 		 min 		= d.getMinutes().toString();
	// 	(day.length < 2) ? day = '0' + day : '';
	// 	(hour.length < 2) ? hour = '0' + hour : '';
	// 	(min.length < 2) ? min = '0' + min : '';		
	// 	var res = ''+month+' '+day+' '+hour+ ':' + min;
	// 	return res;
	// }
	function getConversation(friend_id){
              $.ajax({
                url:"<?=base_url('Message/getMyConversation')?>",
                type:"post",
                data:{friend:friend_id},
                success:function(response)
                        {
                            // console.log(response);
                            response=JSON.parse(response);
                            if(response.code==1){
                              $('#f'+friend_id).empty();
                              for(let i=0; i<response.msgs.length; i++){
                                
                                msg='';
                                if(response.msgs[i].sent_to!=<?=$_SESSION['logged_in'][0]->user_id?>){

                                	msg+='<li><div class="msg you">';
                                 	msg+='<span class="partner">'+response.msgs[i].full_name+'</span>';
                                 	msg+=response.msgs[i].message_;
                                 	msg+='<span class="time">Jan 18 23:24</span></div></li>';
                                  
                                }else{
                                 	msg+='<li><div class="msg him">';
                                 	msg+='<span class="partner">'+response.msgs[i].full_name+'</span>';
                                 	msg+=response.msgs[i].message_;
                                 	msg+='<span class="time">Jan 18 23:24</span></div></li>';
                                }
                              $('#f'+friend_id).append(msg);
                              }
                            }
                        }
              });
            }
            function sendMess(message,myFd,this_element){
            	$.ajax({
	              url:'<?=base_url('Message/sendMyMessages')?>',
	              type:"post",
	              data:{ message:message,friend:myFd},
	              success:function(response){
	                      // console.log(response);
	                      response=JSON.parse(response);
	                      console.log("Response: "+response.code);
	                      if(response.code==1){
	                        $('#emojionearea1').val("");
	                        $('.emojionearea-editor').html("");
	                        getConversation(myFd);
	                      }
	                    }
	            });
            }
		
</script>

<div id="statusModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <div id="progressTimer"></div>
        <a href="" id="redirecTo"><h4 class="modal-title" id="prod_By"></h4></a>
        <button type="button" class="close" data-dismiss="modal">&times;</button>        
      </div>
      <div class="modal-body" >
      	<div style="display:flex;position: absolute;z-index: 12;width: 93%;" id="stry__e" >
			<div class="s3">
				<div class="loading1"></div>
			</div>
			<div class="s3">
				<div class="loading1"></div>
			</div>
			<div class="s3">
				<div class="loading1"></div>
			</div>
		</div>
		<div id="stry_shw_">
			<div class="pane_img" style="background-color:#F00;"></div>
			<div class="pane_img" style="background-color:#0F0;"></div>
			<div class="pane_img" style="background-color:#00F;"></div>
		</div>

		<div class="mt-3">
			<ul class="list-unstyled m-0 d-flex">
				<li class="ml-2"><a href="#" class="text-dark"><span><i class="fa fa-smile-o" aria-hidden="true"></i></span></a></li>
				<li class="ml-2"><a href="#" class="text-dark"><span><i class="fa fa-paper-plane-o" aria-hidden="true"></i></span></a></li>
			</ul>
		</div>
      	<!-- <div id="stry__e">
      	 	<div class="loading1"></div>
      	</div> -->
<!-- <div class="" id="stry_shw_">
	<div class="pane_img" style="background-color:#F00;"></div>
	<div class="pane_img" style="background-color:#0F0;"></div>
	<div class="pane_img" style="background-color:#00F;"></div>
</div> -->
      <!--   <img src="" class="img-fluid" id="stImg"> -->
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


<div id="postStatus" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h4><?=$MyDetails[0]->full_name?></h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        
      </div>
      <div class="modal-body">
        <img src="" class="img-fluid" id="">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<div id="viewport"></div>


<script>



// var currentIndex = 0;

// function showpanel() {
//     $(".pane_img").hide();
//     $(".pane_img").eq(currentIndex).show();
//     $(".loading1").eq(currentIndex).css("width", "0%");
//  $(".loading1").eq(currentIndex).css("background-color", "green");
//     currentIndex++;
//     if (currentIndex > 2) {
//         currentIndex = 0;
//     }
// console.log(currentIndex);
//     $('.loading1').eq(currentIndex).animate({
//         width: '100%'
//     }, 6000, "linear", showpanel);
// }

// showpanel();
</script>

<script type="text/javascript">
   $(document).ready(function () {
  $('.cmnt_').keyup(function (e) {
    if (e.which == 13) {
      // console.log("dsadnsajnda");
      var text = $(this).closest(".emoji-wysiwyg-editor").html();
 
//console.log(text);
      // $(".ad_cmnt").submit(function (ev) {
      //     ev.preventDefault();
        var form = $('.ad_cmnt')[0];
        console.log(form);
         var formdata = new FormData(form);
         formdata.append("comment",text);
          // for (var value of formdata.values()) {
          //    console.log(value); 
          // }
    
      //    console.log("hello");
          // var comment =$(this).val();
          // var post_id_comnt =$(this).attr("p_d");

          // console.log(comment);
          //  console.log(post_id_comnt);
          // Get input field values
             // var formData= new FormData($(this)[0]);
             $.ajax({
                        url:"<?=base_url()?>APIController/addComment",
                         type:"post",
                         data:formdata,
                         contentType:false,
                         processData:false,
                         cache:false,

                        success:function(response)
                        {
                          console.log(response);
                          response=JSON.parse(response);
                          if(response.code==1){
                            
                         //alert(response.msg);
                            // swal("Success", "Story Successfully", "success");
                           // $('.ad_cmnt').trigger("reset");
                          location.reload();
                            
                          }
                         
                        }
                  });  
         
 
    }
  });

  $(document).on("click",".dlt_post_",function(){
    var ele =$(this);
     var post_id =ele.attr("p_d");
     $.ajax({
            url:"<?=base_url()?>APIController/deletePost",
             type:"post",
             data:{post_id:post_id},
             cache:false,

            success:function(response)
            {
              console.log(response);
              response=JSON.parse(response);
              if(response.code==1){
                  ele.parent().parent().parent().parent().parent().remove();
              } 
            }
      });  
  })

 $(document).on("click",".dlt_comnt_",function(){
    var ele =$(this);
     var c_id =ele.attr("c_d");
     $.ajax({
            url:"<?=base_url()?>APIController/deleteComment",
             type:"post",
             data:{c_id:c_id},
             cache:false,

            success:function(response)
            {
              console.log(response);
              response=JSON.parse(response);
              if(response.code==1){
                  ele.parent().parent().parent().parent().remove();
              } 
            }
      });  
  })

});
</script>


</script>
</body>
</html>