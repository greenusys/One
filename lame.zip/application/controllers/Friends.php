<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Friends extends CI_Controller {


	public function __construct(){	
		parent::__construct();
		$this->load->model('FriendsModel','FRND');
		$this->load->model('ProfileModel','Profile');
		$this->load->model('PostModel','POST');
		$this->load->model('TestModel','Test');
		
	}

	public function index($uId=""){
		$user_id=$_SESSION['logged_in'][0]->user_id;
		if($uId!=""){
			$id=$uId;
		}else{
			$id=$user_id;
		}
		if($id!=$_SESSION['logged_in'][0]->user_id){
			$res=$this->FRND->checkForExistingFriendship($uId,$user_id);
			// print_r($res);
			if(count($res)>0){
				$data['cancelFriend']=1;
			}else{
				$data['cancelFriend']=0;
			}
			$data['myId']=0;
		}else{
			$data['myId']=1;
		}
		$data['user_id']=$id;
		$data['ReqStatus']=$this->FRND->checkFriendRequestStatus($id);
		$data['RandomPeople']=$this->FRND->getRandomUser($id);
		$data['MyFriends']=$this->FRND->getMyFriends($id);
		$data['FriendsActivity']=$this->FRND->getMyFreActivities($id);
		$data['MyDetails']=$this->Profile->getMyDetails($id);
		$data['FriendRequests']=$this->FRND->getFriendRequests($id);
		$data['MyFollowers']=$this->FRND->getMyFollowers($id);
		$data['MyPosts']=$this->POST->getMyPosts($id);
	
		
		$this->load->view('web/template/header',$data);
		$this->load->view('web/template/profileCover');
		$this->load->view('web/template/sideSection');
		$this->load->view('web/profile/friends');
		$this->load->view('web/template/footer');
	}
	public function getFrnd(){
		//echo 'Bla Bla;';
		 $id=$_SESSION['logged_in'][0]->user_id;
		if($id!=$_SESSION['logged_in'][0]->user_id){
			$res=$this->FRND->checkForExistingFriendship($uId,$user_id);
			// print_r($res);
			if(count($res)>0){
				$data['cancelFriend']=1;
			}else{
				$data['cancelFriend']=0;
			}
			$data['myId']=0;
		}else{
			$data['myId']=1;
		}
		
		$data['RandomPeople']=$this->FRND->getRandomUser($id);
		$data['MyFriends']=$this->Test->getRandomUser($id);
		$data['FriendsActivity']=$this->FRND->getMyFreActivities($id);
		$data['MyDetails']=$this->Profile->getMyDetails($id);

	
		$data['FriendRequests']=$this->Test->getRandomUser($id);
		$data['MyFollowers']=$this->Test->getRandomUser($id);
		$data['MyPosts']=$this->POST->getMyPosts($id);
	
		
		$this->load->view('web/template/header',$data);
		$this->load->view('web/template/profileCover');
		// $this->load->view('web/template/sideSection');
		$this->load->view('web/profile/fron_frnd');
		$this->load->view('web/template/footer');
	}

}